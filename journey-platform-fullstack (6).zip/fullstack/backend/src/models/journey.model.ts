import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';
import { WorkflowComment } from './workflow-comment.model';
import { JourneyRun } from './journey-run.model';
// AuditLog is queried directly, not via association
import { AuditLog } from './audit-log.model';

export enum LifecycleStage {
  ACQUIRE = 'ACQUIRE',
  ACTIVATE = 'ACTIVATE',
  ENGAGE = 'ENGAGE',
  GROW = 'GROW',
  RETAIN = 'RETAIN',
  WIN_BACK = 'WIN_BACK',
  ADVOCATE = 'ADVOCATE',
}

export enum JourneyStatus {
  DRAFT = 'draft',
  INTAKE = 'intake',
  DMO_REVIEW = 'dmo_review',
  CX_REVIEW = 'cx_review',
  CONTROL_REVIEW = 'control_review',
  APPROVED = 'approved',
  SCHEDULED = 'scheduled',
  RUNNING = 'running',
  PAUSED = 'paused',
  COMPLETED = 'completed',
  REJECTED = 'rejected',
  ARCHIVED = 'archived',
}

export enum JourneyPriority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical',
}

export interface IJourneyStep {
  id: string;
  name: string;
  type: 'email' | 'sms' | 'push' | 'wait' | 'condition' | 'action';
  config: Record<string, any>;
  nextStepId?: string;
  delay?: number; // in hours
}

export interface IJourneyMetrics {
  totalSent: number;
  delivered: number;
  opened: number;
  clicked: number;
  converted: number;
  bounced: number;
  unsubscribed: number;
  openRate: number;
  clickRate: number;
  conversionRate: number;
  bounceRate: number;
}

export interface IControlGroup {
  enabled: boolean;
  percentage: number;
  description?: string;
}

@Table({
  tableName: 'journeys',
  timestamps: true,
  underscored: true,
})
export class Journey extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @Column(DataType.TEXT)
  description?: string;

  @AllowNull(false)
  @Default(LifecycleStage.ACQUIRE)
  @Column(DataType.ENUM(...Object.values(LifecycleStage)))
  lifecycleStage!: LifecycleStage;

  @AllowNull(false)
  @Default(JourneyStatus.DRAFT)
  @Column(DataType.ENUM(...Object.values(JourneyStatus)))
  status!: JourneyStatus;

  @AllowNull(false)
  @Default(JourneyPriority.MEDIUM)
  @Column(DataType.ENUM(...Object.values(JourneyPriority)))
  priority!: JourneyPriority;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  createdBy!: string;

  @BelongsTo(() => User, 'createdBy')
  creator!: User;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  assignedTo?: string;

  @BelongsTo(() => User, 'assignedTo')
  assignee?: User;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  approvedBy?: string;

  @BelongsTo(() => User, 'approvedBy')
  approver?: User;

  @Column(DataType.DATE)
  approvedAt?: Date;

  @Column(DataType.DATE)
  scheduledAt?: Date;

  @Column(DataType.DATE)
  startedAt?: Date;

  @Column(DataType.DATE)
  completedAt?: Date;

  @Column(DataType.DATE)
  pausedAt?: Date;

  @Column(DataType.JSONB)
  steps?: IJourneyStep[];

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  entryRuleId?: string;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  templateId?: string;

  @Column(DataType.INTEGER)
  estimatedReach?: number;

  @Column(DataType.INTEGER)
  actualReach?: number;

  @Default(0)
  @Column(DataType.INTEGER)
  version!: number;

  @Column(DataType.JSONB)
  controlGroup?: IControlGroup;

  @Column(DataType.JSONB)
  metrics?: IJourneyMetrics;

  @Column(DataType.STRING(50))
  rejectionReason?: string;

  @Column(DataType.TEXT)
  rejectionNotes?: string;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @Column(DataType.DATE)
  lastRunAt?: Date;

  @Column(DataType.DATE)
  nextRunAt?: Date;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  @HasMany(() => WorkflowComment)
  comments!: WorkflowComment[];

  @HasMany(() => JourneyRun)
  runs!: JourneyRun[];



  // Instance methods
  canTransitionTo(newStatus: JourneyStatus): boolean {
    const validTransitions: Record<JourneyStatus, JourneyStatus[]> = {
      [JourneyStatus.DRAFT]: [JourneyStatus.INTAKE, JourneyStatus.ARCHIVED],
      [JourneyStatus.INTAKE]: [JourneyStatus.DMO_REVIEW, JourneyStatus.REJECTED, JourneyStatus.ARCHIVED],
      [JourneyStatus.DMO_REVIEW]: [JourneyStatus.CX_REVIEW, JourneyStatus.REJECTED, JourneyStatus.INTAKE],
      [JourneyStatus.CX_REVIEW]: [JourneyStatus.CONTROL_REVIEW, JourneyStatus.REJECTED, JourneyStatus.DMO_REVIEW],
      [JourneyStatus.CONTROL_REVIEW]: [JourneyStatus.APPROVED, JourneyStatus.REJECTED, JourneyStatus.CX_REVIEW],
      [JourneyStatus.APPROVED]: [JourneyStatus.SCHEDULED, JourneyStatus.RUNNING, JourneyStatus.ARCHIVED],
      [JourneyStatus.SCHEDULED]: [JourneyStatus.RUNNING, JourneyStatus.PAUSED, JourneyStatus.APPROVED],
      [JourneyStatus.RUNNING]: [JourneyStatus.PAUSED, JourneyStatus.COMPLETED, JourneyStatus.ARCHIVED],
      [JourneyStatus.PAUSED]: [JourneyStatus.RUNNING, JourneyStatus.ARCHIVED],
      [JourneyStatus.COMPLETED]: [JourneyStatus.ARCHIVED],
      [JourneyStatus.REJECTED]: [JourneyStatus.INTAKE, JourneyStatus.ARCHIVED],
      [JourneyStatus.ARCHIVED]: [],
    };

    return validTransitions[this.status]?.includes(newStatus) || false;
  }

  async transitionTo(
    newStatus: JourneyStatus,
    userId: string,
    notes?: string
  ): Promise<void> {
    if (!this.canTransitionTo(newStatus)) {
      throw new Error(`Cannot transition from ${this.status} to ${newStatus}`);
    }

    const oldStatus = this.status;
    this.status = newStatus;

    // Update timestamps based on status
    switch (newStatus) {
      case JourneyStatus.APPROVED:
        this.approvedAt = new Date();
        this.approvedBy = userId;
        break;
      case JourneyStatus.RUNNING:
        this.startedAt = new Date();
        break;
      case JourneyStatus.COMPLETED:
        this.completedAt = new Date();
        break;
      case JourneyStatus.PAUSED:
        this.pausedAt = new Date();
        break;
    }

    await this.save();

    // Create audit log entry
    await AuditLog.create({
      entityType: 'journey',
      entityId: this.id,
      action: 'status_change',
      oldValue: oldStatus,
      newValue: newStatus,
      performedBy: userId,
      notes,
    });
  }

  updateMetrics(metrics: Partial<IJourneyMetrics>): Promise<Journey> {
    this.metrics = { ...this.metrics, ...metrics } as IJourneyMetrics;
    return this.save();
  }

  isEditable(): boolean {
    return [
      JourneyStatus.DRAFT,
      JourneyStatus.INTAKE,
      JourneyStatus.REJECTED,
    ].includes(this.status);
  }

  isRunning(): boolean {
    return this.status === JourneyStatus.RUNNING;
  }

  getProgress(): number {
    const stageOrder = [
      JourneyStatus.DRAFT,
      JourneyStatus.INTAKE,
      JourneyStatus.DMO_REVIEW,
      JourneyStatus.CX_REVIEW,
      JourneyStatus.CONTROL_REVIEW,
      JourneyStatus.APPROVED,
      JourneyStatus.SCHEDULED,
      JourneyStatus.RUNNING,
    ];

    const currentIndex = stageOrder.indexOf(this.status);
    if (currentIndex === -1) return 0;
    return Math.round((currentIndex / (stageOrder.length - 1)) * 100);
  }
}

export default Journey;
