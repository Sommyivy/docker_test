import { Sequelize } from 'sequelize-typescript';
import { logger } from '../utils/logger';

// Import all models
import { User } from '../models/user.model';
import { Journey } from '../models/journey.model';
import { Rule } from '../models/rule.model';
import { Template } from '../models/template.model';
import { DataSource } from '../models/datasource.model';
import { JourneyRun } from '../models/journey-run.model';
import { WorkflowComment } from '../models/workflow-comment.model';
import { AuditLog } from '../models/audit-log.model';
import { EmailConfig } from '../models/email-config.model';
import { EmailAlias } from '../models/email-alias.model';
import { ActivityLog } from '../models/activity-log.model';
import { UserSession } from '../models/user-session.model';
import { PasswordHistory } from '../models/password-history.model';

const NODE_ENV = process.env.NODE_ENV || 'development';

// Database configuration
const config = {
  development: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'journey_platform_dev',
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    dialect: 'postgres' as const,
    logging: (msg: string) => logger.debug(msg),
  },
  test: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'journey_platform_test',
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    dialect: 'postgres' as const,
    logging: false,
  },
  production: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'journey_platform',
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '',
    dialect: 'postgres' as const,
    logging: false,
    pool: {
      max: 20,
      min: 5,
      acquire: 60000,
      idle: 10000,
    },
  },
};

const currentConfig = config[NODE_ENV as keyof typeof config] || config.development;

// Initialize Sequelize
export const sequelize = new Sequelize({
  ...currentConfig,
  models: [
    User,
    Journey,
    Rule,
    Template,
    DataSource,
    JourneyRun,
    WorkflowComment,
    AuditLog,
    EmailConfig,
    EmailAlias,
    ActivityLog,
    UserSession,
    PasswordHistory,
  ],
  define: {
    timestamps: true,
    underscored: true,
    freezeTableName: false,
  },
  dialectOptions: {},
});

// Database connection test
export const testConnection = async (): Promise<boolean> => {
  try {
    await sequelize.authenticate();
    logger.info('Database connection has been established successfully.');
    return true;
  } catch (error) {
    logger.error('Unable to connect to the database:', error);
    return false;
  }
};

// Sync database
export const syncDatabase = async (force: boolean = false): Promise<void> => {
  try {
    await sequelize.sync({ force });
    logger.info('Database synchronized successfully.');
  } catch (error) {
    logger.error('Error synchronizing database:', error);
    throw error;
  }
};

export default sequelize;
