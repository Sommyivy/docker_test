-- Access Bank Journey Platform - Database Initialization
-- Safe init script: only creates extensions and schema
-- Tables are created by Sequelize, indexes are added after tables exist

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create schema
CREATE SCHEMA IF NOT EXISTS journey_platform;
