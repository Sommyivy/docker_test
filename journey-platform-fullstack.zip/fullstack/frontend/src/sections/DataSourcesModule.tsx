import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import {
  Plus,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  Copy,
  Play,
  CheckCircle,
  XCircle,
  Database,
  Server,
  Plug,
  AlertTriangle,
  RefreshCw,
  Power,
  Settings,
  Globe,
  Eye,
  EyeOff,
} from 'lucide-react';
import type { DataSource, DataSourceType, SSLMode } from '@/types';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const dataSourceTypes: { value: DataSourceType; label: string; icon: any; color: string }[] = [
  { value: '360_store', label: '360 Data Store', icon: Database, color: 'text-[#F28A1A]' },
  { value: 'mssql', label: 'Microsoft SQL Server', icon: Server, color: 'text-blue-600' },
  { value: 'oracle', label: 'Oracle Database', icon: Database, color: 'text-red-600' },
  { value: 'postgresql', label: 'PostgreSQL', icon: Database, color: 'text-indigo-600' },
  { value: 'mysql', label: 'MySQL', icon: Database, color: 'text-orange-600' },
  { value: 'snowflake', label: 'Snowflake', icon: Database, color: 'text-cyan-600' },
  { value: 'redshift', label: 'AWS Redshift', icon: Database, color: 'text-purple-600' },
  { value: 'api', label: 'REST API', icon: Globe, color: 'text-green-600' },
];

const sslModes: { value: SSLMode; label: string }[] = [
  { value: 'disable', label: 'Disable' },
  { value: 'require', label: 'Require' },
  { value: 'verify-ca', label: 'Verify CA' },
  { value: 'verify-full', label: 'Verify Full' },
];

const statusConfig = {
  connected: { label: 'Connected', className: 'bg-green-100 text-green-700', icon: CheckCircle },
  disconnected: { label: 'Disconnected', className: 'bg-gray-100 text-gray-700', icon: Power },
  error: { label: 'Error', className: 'bg-red-100 text-red-700', icon: XCircle },
  testing: { label: 'Testing...', className: 'bg-yellow-100 text-yellow-700', icon: RefreshCw },
};

export function DataSourcesModule() {
  const { dataSources, addDataSource, updateDataSource, deleteDataSource, testDataSource, toggleDataSource } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<DataSourceType | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'connected' | 'disconnected' | 'error'>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingDataSource, setEditingDataSource] = useState<DataSource | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'mssql' as DataSourceType,
    host: '',
    port: 1433,
    database: '',
    schema: 'dbo',
    username: '',
    password: '',
    sslMode: 'require' as SSLMode,
    timeoutSeconds: 30,
    maxConnections: 50,
    isActive: true,
    tags: '',
    // API specific
    apiEndpoint: '',
    apiKey: '',
    // 360 Store specific
    storeRegion: '',
    storeEnvironment: 'production' as 'production' | 'staging' | 'development',
  });

  const filteredDataSources = dataSources.filter((ds) => {
    const matchesSearch = ds.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ds.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ds.host.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || ds.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || ds.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const getDefaultPort = (type: DataSourceType): number => {
    switch (type) {
      case 'mssql': return 1433;
      case 'oracle': return 1521;
      case 'postgresql': return 5432;
      case 'mysql': return 3306;
      case '360_store': return 1433;
      case 'snowflake': return 443;
      case 'redshift': return 5439;
      case 'api': return 443;
      default: return 1433;
    }
  };

  const handleCreateDataSource = () => {
    const newDataSource = {
      name: formData.name,
      description: formData.description,
      type: formData.type,
      host: formData.host,
      port: formData.port,
      database: formData.database || undefined,
      schema: formData.schema || undefined,
      username: formData.username || undefined,
      password: formData.password || undefined,
      sslMode: formData.sslMode,
      status: 'disconnected' as const,
      timeoutSeconds: formData.timeoutSeconds,
      maxConnections: formData.maxConnections,
      createdBy: 'u1',
      isActive: formData.isActive,
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
      // API specific
      apiEndpoint: formData.type === 'api' ? formData.apiEndpoint : undefined,
      apiKey: formData.type === 'api' ? formData.apiKey : undefined,
      // 360 Store specific
      storeRegion: formData.type === '360_store' ? formData.storeRegion : undefined,
      storeEnvironment: formData.type === '360_store' ? formData.storeEnvironment : undefined,
    };

    addDataSource(newDataSource);
    toast.success('Data source created successfully');
    setIsCreateDialogOpen(false);
    resetForm();
  };

  const handleUpdateDataSource = () => {
    if (!editingDataSource) return;

    updateDataSource(editingDataSource.id, {
      name: formData.name,
      description: formData.description,
      type: formData.type,
      host: formData.host,
      port: formData.port,
      database: formData.database || undefined,
      schema: formData.schema || undefined,
      username: formData.username || undefined,
      password: formData.password || undefined,
      sslMode: formData.sslMode,
      timeoutSeconds: formData.timeoutSeconds,
      maxConnections: formData.maxConnections,
      isActive: formData.isActive,
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
      apiEndpoint: formData.type === 'api' ? formData.apiEndpoint : undefined,
      apiKey: formData.type === 'api' ? formData.apiKey : undefined,
      storeRegion: formData.type === '360_store' ? formData.storeRegion : undefined,
      storeEnvironment: formData.type === '360_store' ? formData.storeEnvironment : undefined,
    });
    toast.success('Data source updated successfully');
    setEditingDataSource(null);
    resetForm();
  };

  const handleDeleteDataSource = (id: string) => {
    if (confirm('Are you sure you want to delete this data source?')) {
      deleteDataSource(id);
      toast.success('Data source deleted successfully');
    }
  };

  const handleDuplicateDataSource = (ds: DataSource) => {
    const duplicated = {
      ...ds,
      name: `${ds.name} (Copy)`,
      status: 'disconnected' as const,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addDataSource(duplicated);
    toast.success('Data source duplicated successfully');
  };

  const handleTest = (id: string) => {
    testDataSource(id);
    toast.info('Testing connection...');
  };

  const handleToggle = (id: string) => {
    toggleDataSource(id);
    const ds = dataSources.find(d => d.id === id);
    toast.success(`Data source ${ds?.isActive ? 'disabled' : 'enabled'}`);
  };

  const openEditDialog = (ds: DataSource) => {
    setEditingDataSource(ds);
    setFormData({
      name: ds.name,
      description: ds.description || '',
      type: ds.type,
      host: ds.host,
      port: ds.port,
      database: ds.database || '',
      schema: ds.schema || 'dbo',
      username: ds.username || '',
      password: ds.password || '',
      sslMode: ds.sslMode || 'require',
      timeoutSeconds: ds.timeoutSeconds,
      maxConnections: ds.maxConnections,
      isActive: ds.isActive,
      tags: ds.tags.join(', '),
      apiEndpoint: ds.apiEndpoint || '',
      apiKey: ds.apiKey || '',
      storeRegion: ds.storeRegion || '',
      storeEnvironment: ds.storeEnvironment || 'production',
    });
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      type: 'mssql',
      host: '',
      port: 1433,
      database: '',
      schema: 'dbo',
      username: '',
      password: '',
      sslMode: 'require',
      timeoutSeconds: 30,
      maxConnections: 50,
      isActive: true,
      tags: '',
      apiEndpoint: '',
      apiKey: '',
      storeRegion: '',
      storeEnvironment: 'production',
    });
    setShowPassword(false);
  };

  const is360Store = formData.type === '360_store';
  const isAPI = formData.type === 'api';
  const isDatabase = !isAPI;

  const stats = {
    total: dataSources.length,
    connected: dataSources.filter(ds => ds.status === 'connected').length,
    disconnected: dataSources.filter(ds => ds.status === 'disconnected').length,
    error: dataSources.filter(ds => ds.status === 'error').length,
    active: dataSources.filter(ds => ds.isActive).length,
  };

  const renderDataSourceCard = (ds: DataSource) => {
    const status = statusConfig[ds.status];
    const StatusIcon = status.icon;
    const typeInfo = dataSourceTypes.find(t => t.value === ds.type);
    const TypeIcon = typeInfo?.icon || Database;

    return (
      <Card key={ds.id} className={cn('card-hover', !ds.isActive && 'opacity-60')}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={cn('p-2 rounded-lg bg-slate-50', typeInfo?.color)}>
                <TypeIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{ds.name}</h3>
                <p className="text-xs text-muted-foreground">{ds.id}</p>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => openEditDialog(ds)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleTest(ds.id)}>
                  <Play className="w-4 h-4 mr-2" />
                  Test Connection
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleToggle(ds.id)}>
                  <Power className="w-4 h-4 mr-2" />
                  {ds.isActive ? 'Disable' : 'Enable'}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleDuplicateDataSource(ds)}>
                  <Copy className="w-4 h-4 mr-2" />
                  Duplicate
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => handleDeleteDataSource(ds.id)}
                  className="text-red-600"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {ds.description && (
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {ds.description}
            </p>
          )}

          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="outline" className={cn('text-xs', status.className)}>
              <StatusIcon className={cn('w-3 h-3 mr-1', ds.status === 'testing' && 'animate-spin')} />
              {status.label}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {typeInfo?.label || ds.type}
            </Badge>
            {!ds.isActive && (
              <Badge variant="outline" className="text-xs bg-gray-100 text-gray-600">
                Disabled
              </Badge>
            )}
          </div>

          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <Server className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">Host:</span>
              <span className="font-medium truncate">{ds.host}:{ds.port}</span>
            </div>
            {ds.database && (
              <div className="flex items-center gap-2 text-sm">
                <Database className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Database:</span>
                <span className="font-medium">{ds.database}</span>
              </div>
            )}
            {ds.type === '360_store' && ds.storeEnvironment && (
              <div className="flex items-center gap-2 text-sm">
                <Settings className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Environment:</span>
                <span className="font-medium capitalize">{ds.storeEnvironment}</span>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-4">
              <span>Timeout: {ds.timeoutSeconds}s</span>
              <span>Max Conn: {ds.maxConnections}</span>
            </div>
            {ds.lastTestedAt && (
              <span>Tested {format(new Date(ds.lastTestedAt), 'MMM d')}</span>
            )}
          </div>

          {ds.lastError && (
            <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
              <AlertTriangle className="w-3 h-3 inline mr-1" />
              {ds.lastError}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Total Sources</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-50 text-green-600">
                <Plug className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.connected}</p>
                <p className="text-xs text-muted-foreground">Connected</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gray-50 text-gray-600">
                <Power className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.disconnected}</p>
                <p className="text-xs text-muted-foreground">Disconnected</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-50 text-red-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.error}</p>
                <p className="text-xs text-muted-foreground">Errors</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.active}</p>
                <p className="text-xs text-muted-foreground">Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Data Sources</h2>
          <p className="text-muted-foreground">Configure SQL connections and API endpoints</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-[#062A78] hover:bg-[#062A78]/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Data Source
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search data sources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as any)}>
                <SelectTrigger className="w-[180px]">
                  <Database className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {dataSourceTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
                <SelectTrigger className="w-[150px]">
                  <Plug className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="connected">Connected</SelectItem>
                  <SelectItem value="disconnected">Disconnected</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Sources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDataSources.map(renderDataSourceCard)}
      </div>

      {filteredDataSources.length === 0 && (
        <Card className="p-12 text-center">
          <Database className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No data sources found</h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || typeFilter !== 'all' || statusFilter !== 'all'
              ? 'Try adjusting your filters'
              : 'Add your first data source to get started'}
          </p>
          {!searchQuery && typeFilter === 'all' && statusFilter === 'all' && (
            <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-[#062A78]">
              <Plus className="w-4 h-4 mr-2" />
              Add Data Source
            </Button>
          )}
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isCreateDialogOpen || !!editingDataSource} onOpenChange={(open) => {
        if (!open) {
          setIsCreateDialogOpen(false);
          setEditingDataSource(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-2xl max-h-[95vh] overflow-y-auto bg-white">
          <DialogHeader>
            <DialogTitle>{editingDataSource ? 'Edit Data Source' : 'Add New Data Source'}</DialogTitle>
            <DialogDescription>
              Configure connection settings for your data source.
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="basic" className="flex-1">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="connection">Connection</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Data Source Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Production Database"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of this data source..."
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Data Source Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(v) => {
                    const newType = v as DataSourceType;
                    setFormData({ 
                      ...formData, 
                      type: newType,
                      port: getDefaultPort(newType)
                    });
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {dataSourceTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <type.icon className={cn('w-4 h-4', type.color)} />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {is360Store && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="storeRegion">360 Store Region</Label>
                    <Input
                      id="storeRegion"
                      value={formData.storeRegion}
                      onChange={(e) => setFormData({ ...formData, storeRegion: e.target.value })}
                      placeholder="e.g., lagos-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="storeEnvironment">Environment</Label>
                    <Select
                      value={formData.storeEnvironment}
                      onValueChange={(v) => setFormData({ ...formData, storeEnvironment: v as any })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="production">Production</SelectItem>
                        <SelectItem value="staging">Staging</SelectItem>
                        <SelectItem value="development">Development</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {isAPI && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="apiEndpoint">API Endpoint *</Label>
                    <Input
                      id="apiEndpoint"
                      value={formData.apiEndpoint}
                      onChange={(e) => setFormData({ ...formData, apiEndpoint: e.target.value })}
                      placeholder="https://api.example.com/v1/"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="apiKey">API Key</Label>
                    <Input
                      id="apiKey"
                      type="password"
                      value={formData.apiKey}
                      onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                      placeholder="Enter API key"
                    />
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input
                  id="tags"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  placeholder="e.g., production, primary, customer-data"
                />
              </div>
            </TabsContent>

            <TabsContent value="connection" className="space-y-4 py-4">
              {isDatabase && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="host">Host *</Label>
                      <Input
                        id="host"
                        value={formData.host}
                        onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                        placeholder="e.g., db.example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="port">Port *</Label>
                      <Input
                        id="port"
                        type="number"
                        value={formData.port}
                        onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="database">Database</Label>
                      <Input
                        id="database"
                        value={formData.database}
                        onChange={(e) => setFormData({ ...formData, database: e.target.value })}
                        placeholder="Database name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="schema">Schema</Label>
                      <Input
                        id="schema"
                        value={formData.schema}
                        onChange={(e) => setFormData({ ...formData, schema: e.target.value })}
                        placeholder="e.g., dbo, public"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                        placeholder="Database username"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          placeholder="Database password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sslMode">SSL Mode</Label>
                    <Select
                      value={formData.sslMode}
                      onValueChange={(v) => setFormData({ ...formData, sslMode: v as SSLMode })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {sslModes.map((mode) => (
                          <SelectItem key={mode.value} value={mode.value}>
                            {mode.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {isAPI && (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-2 space-y-2">
                      <Label htmlFor="apiHost">Host *</Label>
                      <Input
                        id="apiHost"
                        value={formData.host}
                        onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                        placeholder="e.g., api.example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="apiPort">Port</Label>
                      <Input
                        id="apiPort"
                        type="number"
                        value={formData.port}
                        onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) || 443 })}
                      />
                    </div>
                  </div>
                </>
              )}
            </TabsContent>

            <TabsContent value="advanced" className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="timeout">Connection Timeout (seconds)</Label>
                  <Input
                    id="timeout"
                    type="number"
                    value={formData.timeoutSeconds}
                    onChange={(e) => setFormData({ ...formData, timeoutSeconds: parseInt(e.target.value) || 30 })}
                    min={1}
                    max={300}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxConnections">Max Connections</Label>
                  <Input
                    id="maxConnections"
                    type="number"
                    value={formData.maxConnections}
                    onChange={(e) => setFormData({ ...formData, maxConnections: parseInt(e.target.value) || 50 })}
                    min={1}
                    max={500}
                  />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Power className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Active</p>
                    <p className="text-sm text-muted-foreground">Enable this data source for use</p>
                  </div>
                </div>
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                />
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsCreateDialogOpen(false);
              setEditingDataSource(null);
              resetForm();
            }}>
              Cancel
            </Button>
            {editingDataSource ? (
              <Button 
                onClick={handleUpdateDataSource}
                className="bg-[#062A78] hover:bg-[#062A78]/90"
                disabled={!formData.name || !formData.host}
              >
                Save Changes
              </Button>
            ) : (
              <Button 
                onClick={handleCreateDataSource}
                className="bg-[#062A78] hover:bg-[#062A78]/90"
                disabled={!formData.name || !formData.host}
              >
                Add Data Source
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
