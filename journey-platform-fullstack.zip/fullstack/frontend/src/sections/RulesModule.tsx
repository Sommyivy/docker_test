import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import Editor from '@monaco-editor/react';
import {
  Plus,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  Copy,
  Play,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
  Database,
  FileCode,
  Table,
  Clock,
  Users,
  Shield,
  Check,
  X,
} from 'lucide-react';
import type { Rule, RuleType, SafetyPolicy } from '@/types';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const ruleTypes: { value: RuleType; label: string }[] = [
  { value: 'entry', label: 'Entry Rule' },
  { value: 'exit', label: 'Exit Rule' },
  { value: 'trigger', label: 'Trigger Rule' },
  { value: 'segment', label: 'Segment Rule' },
  { value: 'validation', label: 'Validation Rule' },
];

const statusConfig = {
  active: { label: 'Active', className: 'bg-green-100 text-green-700' },
  inactive: { label: 'Inactive', className: 'bg-gray-100 text-gray-700' },
  draft: { label: 'Draft', className: 'bg-yellow-100 text-yellow-700' },
  error: { label: 'Error', className: 'bg-red-100 text-red-700' },
};

// Sample SQL for new rules
const sampleSQL = `-- Select customers who meet specific criteria
SELECT DISTINCT 
  c.customer_id,
  c.email,
  c.first_name,
  c.last_name,
  c.phone
FROM customers c
WHERE c.status = 'ACTIVE'
  AND c.email IS NOT NULL
  AND c.consent_marketing = 1
  -- Add your conditions here
LIMIT 100000;`;

export function RulesModule() {
  const { rules, dataSources, addRule, updateRule, deleteRule, validateRule } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<RuleType | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'draft' | 'error'>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<any>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'entry' as RuleType,
    dataSourceId: '',
    sqlQuery: sampleSQL,
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly' as const, enabled: true },
      { id: 'sp2', name: 'Row Limit', type: 'rowlimit' as const, enabled: true, config: { maxRows: 100000 } },
      { id: 'sp3', name: 'No UPDATE', type: 'noupdate' as const, enabled: true },
      { id: 'sp4', name: 'No DELETE', type: 'nodelete' as const, enabled: true },
    ] as SafetyPolicy[],
    tags: '',
  });

  const filteredRules = rules.filter((rule) => {
    const matchesSearch = rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         rule.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || rule.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || rule.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleCreateRule = () => {
    const newRule = {
      name: formData.name,
      description: formData.description,
      type: formData.type,
      status: 'draft' as const,
      dataSourceId: formData.dataSourceId,
      sqlQuery: formData.sqlQuery,
      createdBy: 'u1',
      isSafe: formData.isSafe,
      safetyPolicies: formData.safetyPolicies.filter(p => p.enabled),
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
    };

    addRule(newRule);
    toast.success('Rule created successfully');
    setIsCreateDialogOpen(false);
    resetForm();
  };

  const handleUpdateRule = () => {
    if (!editingRule) return;

    updateRule(editingRule.id, {
      name: formData.name,
      description: formData.description,
      type: formData.type,
      dataSourceId: formData.dataSourceId,
      sqlQuery: formData.sqlQuery,
      isSafe: formData.isSafe,
      safetyPolicies: formData.safetyPolicies.filter(p => p.enabled),
      tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
    });
    toast.success('Rule updated successfully');
    setEditingRule(null);
    resetForm();
  };

  const handleDeleteRule = (id: string) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      deleteRule(id);
      toast.success('Rule deleted successfully');
    }
  };

  const handleDuplicateRule = (rule: Rule) => {
    const duplicated = {
      ...rule,
      name: `${rule.name} (Copy)`,
      status: 'draft' as const,
      validatedAt: undefined,
      validatedBy: undefined,
      validationResult: undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addRule(duplicated);
    toast.success('Rule duplicated successfully');
  };

  const handleValidate = async () => {
    setIsValidating(true);
    setValidationResult(null);

    // Simulate validation
    await new Promise(resolve => setTimeout(resolve, 2000));

    const result = {
      valid: true,
      recordCount: Math.floor(Math.random() * 50000) + 1000,
      sampleData: [
        { customer_id: 'C100001', email: 'customer1@email.com', first_name: 'John', last_name: 'Doe' },
        { customer_id: 'C100002', email: 'customer2@email.com', first_name: 'Jane', last_name: 'Smith' },
        { customer_id: 'C100003', email: 'customer3@email.com', first_name: 'Mike', last_name: 'Johnson' },
      ],
      columns: ['customer_id', 'email', 'first_name', 'last_name'],
      executionTimeMs: Math.floor(Math.random() * 3000) + 500,
      warnings: [],
    };

    setValidationResult(result);
    setIsValidating(false);
    toast.success('Rule validated successfully');
  };

  const handleSaveValidation = () => {
    if (editingRule) {
      validateRule(editingRule.id, 'u1');
      updateRule(editingRule.id, {
        validationResult,
        estimatedRecordCount: validationResult?.recordCount,
        executionTimeMs: validationResult?.executionTimeMs,
      });
    }
  };

  const openEditDialog = (rule: Rule) => {
    setEditingRule(rule);
    setFormData({
      name: rule.name,
      description: rule.description,
      type: rule.type,
      dataSourceId: rule.dataSourceId,
      sqlQuery: rule.sqlQuery,
      isSafe: rule.isSafe,
      safetyPolicies: rule.safetyPolicies.length > 0 ? rule.safetyPolicies : [
        { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
        { id: 'sp2', name: 'Row Limit', type: 'rowlimit', enabled: true, config: { maxRows: 100000 } },
        { id: 'sp3', name: 'No UPDATE', type: 'noupdate', enabled: true },
        { id: 'sp4', name: 'No DELETE', type: 'nodelete', enabled: true },
      ],
      tags: rule.tags.join(', '),
    });
    setValidationResult(rule.validationResult);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      type: 'entry',
      dataSourceId: '',
      sqlQuery: sampleSQL,
      isSafe: true,
      safetyPolicies: [
        { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
        { id: 'sp2', name: 'Row Limit', type: 'rowlimit', enabled: true, config: { maxRows: 100000 } },
        { id: 'sp3', name: 'No UPDATE', type: 'noupdate', enabled: true },
        { id: 'sp4', name: 'No DELETE', type: 'nodelete', enabled: true },
      ] as SafetyPolicy[],
      tags: '',
    });
    setValidationResult(null);
  };

  const getDataSourceName = (id: string) => {
    return dataSources.find(ds => ds.id === id)?.name || 'Unknown';
  };

  const renderRuleCard = (rule: Rule) => {
    const status = statusConfig[rule.status];

    return (
      <Card key={rule.id} className="card-hover">
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{rule.name}</h3>
                <p className="text-xs text-muted-foreground">{rule.id}</p>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => openEditDialog(rule)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleDuplicateRule(rule)}>
                  <Copy className="w-4 h-4 mr-2" />
                  Duplicate
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => handleDeleteRule(rule.id)}
                  className="text-red-600"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {rule.description}
          </p>

          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="outline" className={cn('text-xs', status.className)}>
              {status.label}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {rule.type}
            </Badge>
            {rule.isSafe && (
              <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                <Shield className="w-3 h-3 mr-1" />
                Safe
              </Badge>
            )}
          </div>

          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-sm">
              <Database className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">Data Source:</span>
              <span className="font-medium">{getDataSourceName(rule.dataSourceId)}</span>
            </div>
            {rule.estimatedRecordCount && (
              <div className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Est. Records:</span>
                <span className="font-medium">{rule.estimatedRecordCount.toLocaleString()}</span>
              </div>
            )}
            {rule.executionTimeMs && (
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Exec Time:</span>
                <span className="font-medium">{(rule.executionTimeMs / 1000).toFixed(2)}s</span>
              </div>
            )}
          </div>

          {rule.validatedAt && (
            <div className="flex items-center gap-2 text-sm text-green-600 mb-3">
              <CheckCircle className="w-4 h-4" />
              <span>Validated {format(new Date(rule.validatedAt), 'MMM d, yyyy')}</span>
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            Created {format(new Date(rule.createdAt), 'MMM d, yyyy')}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Rules</h2>
          <p className="text-muted-foreground">Manage SQL rules for customer segmentation</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-[#062A78] hover:bg-[#062A78]/90">
          <Plus className="w-4 h-4 mr-2" />
          Create Rule
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search rules..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as any)}>
                <SelectTrigger className="w-[150px]">
                  <FileCode className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {ruleTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
                <SelectTrigger className="w-[150px]">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {Object.entries(statusConfig).map(([key, config]) => (
                    <SelectItem key={key} value={key}>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRules.map(renderRuleCard)}
      </div>

      {filteredRules.length === 0 && (
        <Card className="p-12 text-center">
          <FileCode className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No rules found</h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || typeFilter !== 'all' || statusFilter !== 'all'
              ? 'Try adjusting your filters'
              : 'Create your first rule to get started'}
          </p>
          {!searchQuery && typeFilter === 'all' && statusFilter === 'all' && (
            <Button onClick={() => setIsCreateDialogOpen(true)} className="bg-[#062A78]">
              <Plus className="w-4 h-4 mr-2" />
              Create Rule
            </Button>
          )}
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isCreateDialogOpen || !!editingRule} onOpenChange={(open) => {
        if (!open) {
          setIsCreateDialogOpen(false);
          setEditingRule(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-5xl max-h-[95vh] overflow-hidden bg-white">
          <DialogHeader>
            <DialogTitle>{editingRule ? 'Edit Rule' : 'Create New Rule'}</DialogTitle>
            <DialogDescription>
              Define SQL rules to segment your customer base.
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="basic" className="flex-1">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="sql">SQL Query</TabsTrigger>
              <TabsTrigger value="safety">Safety Policies</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Rule Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., New Account Holders"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe what this rule does..."
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Rule Type *</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(v) => setFormData({ ...formData, type: v as RuleType })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ruleTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataSource">Data Source *</Label>
                  <Select
                    value={formData.dataSourceId}
                    onValueChange={(v) => setFormData({ ...formData, dataSourceId: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select data source" />
                    </SelectTrigger>
                    <SelectContent>
                      {dataSources.filter(ds => ds.isActive).map((ds) => (
                        <SelectItem key={ds.id} value={ds.id}>
                          {ds.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input
                  id="tags"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  placeholder="e.g., onboarding, new-customers"
                />
              </div>
            </TabsContent>

            <TabsContent value="sql" className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <Label>SQL Query</Label>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleValidate}
                    disabled={isValidating || !formData.sqlQuery}
                  >
                    {isValidating ? (
                      <>
                        <Clock className="w-4 h-4 mr-2 animate-spin" />
                        Validating...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Validate
                      </>
                    )}
                  </Button>
                </div>
              </div>
              <div className="border rounded-md overflow-hidden">
                <Editor
                  height="300px"
                  defaultLanguage="sql"
                  value={formData.sqlQuery}
                  onChange={(value) => setFormData({ ...formData, sqlQuery: value || '' })}
                  options={{
                    minimap: { enabled: false },
                    lineNumbers: 'on',
                    roundedSelection: false,
                    scrollBeyondLastLine: false,
                    readOnly: false,
                    fontSize: 14,
                  }}
                  theme="vs-light"
                />
              </div>

              {validationResult && (
                <Card className={cn(
                  'border',
                  validationResult.valid ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                )}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-3">
                      {validationResult.valid ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-red-600" />
                      )}
                      <span className={cn(
                        'font-medium',
                        validationResult.valid ? 'text-green-700' : 'text-red-700'
                      )}>
                        {validationResult.valid ? 'Validation Successful' : 'Validation Failed'}
                      </span>
                    </div>
                    
                    {validationResult.valid && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-3 gap-4">
                          <div className="text-center p-3 bg-white rounded-lg">
                            <Users className="w-5 h-5 mx-auto mb-1 text-blue-600" />
                            <p className="text-lg font-bold">{validationResult.recordCount.toLocaleString()}</p>
                            <p className="text-xs text-muted-foreground">Records</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded-lg">
                            <Table className="w-5 h-5 mx-auto mb-1 text-purple-600" />
                            <p className="text-lg font-bold">{validationResult.columns.length}</p>
                            <p className="text-xs text-muted-foreground">Columns</p>
                          </div>
                          <div className="text-center p-3 bg-white rounded-lg">
                            <Clock className="w-5 h-5 mx-auto mb-1 text-orange-600" />
                            <p className="text-lg font-bold">{(validationResult.executionTimeMs / 1000).toFixed(2)}s</p>
                            <p className="text-xs text-muted-foreground">Exec Time</p>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium mb-2">Sample Data:</p>
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs bg-white rounded-lg">
                              <thead>
                                <tr className="border-b">
                                  {validationResult.columns.map((col: string) => (
                                    <th key={col} className="px-3 py-2 text-left font-medium">{col}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {validationResult.sampleData.map((row: any, idx: number) => (
                                  <tr key={idx} className="border-b">
                                    {validationResult.columns.map((col: string) => (
                                      <td key={col} className="px-3 py-2">{row[col]}</td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        {editingRule && (
                          <Button 
                            onClick={handleSaveValidation}
                            className="w-full bg-green-600 hover:bg-green-700"
                          >
                            <Check className="w-4 h-4 mr-2" />
                            Save Validation Results
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="safety" className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-600" />
                  <Label>Enable Safety Policies</Label>
                </div>
                <Switch
                  checked={formData.isSafe}
                  onCheckedChange={(checked) => setFormData({ ...formData, isSafe: checked })}
                />
              </div>

              {formData.isSafe && (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Safety policies protect your data by restricting potentially dangerous operations.
                  </p>
                  
                  {formData.safetyPolicies.map((policy, idx) => (
                    <Card key={policy.id} className="border">
                      <CardContent className="p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Switch
                            checked={policy.enabled}
                            onCheckedChange={(checked) => {
                              const newPolicies = [...formData.safetyPolicies];
                              newPolicies[idx].enabled = checked;
                              setFormData({ ...formData, safetyPolicies: newPolicies });
                            }}
                          />
                          <div>
                            <p className="font-medium">{policy.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {policy.type === 'readonly' && 'Prevents any data modification'}
                              {policy.type === 'rowlimit' && `Limits results to ${policy.config?.maxRows || 100000} rows`}
                              {policy.type === 'noupdate' && 'Blocks UPDATE statements'}
                              {policy.type === 'nodelete' && 'Blocks DELETE statements'}
                              {policy.type === 'noinsert' && 'Blocks INSERT statements'}
                            </p>
                          </div>
                        </div>
                        {policy.enabled ? (
                          <Check className="w-5 h-5 text-green-600" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400" />
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsCreateDialogOpen(false);
              setEditingRule(null);
              resetForm();
            }}>
              Cancel
            </Button>
            {editingRule ? (
              <Button 
                onClick={handleUpdateRule}
                className="bg-[#062A78] hover:bg-[#062A78]/90"
                disabled={!formData.name || !formData.dataSourceId}
              >
                Save Changes
              </Button>
            ) : (
              <Button 
                onClick={handleCreateRule}
                className="bg-[#062A78] hover:bg-[#062A78]/90"
                disabled={!formData.name || !formData.dataSourceId}
              >
                Create Rule
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
