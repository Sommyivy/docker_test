import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  Plus,
  Search,
  Filter,
  Play,
  Pause,
  CheckCircle,
  XCircle,
  Clock,
  Send,
  Route,
  Users,
  BarChart3,
  MessageSquare,
  History,
  ChevronRight,
  FileText,
  User,
  ArrowRight,
  RotateCcw,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { workflowStages } from '@/data/mockData';
import type { Journey, WorkflowStage, WorkflowAction, WorkflowComment, AuditEntry } from '@/types';

// Workflow Stage Visualizer Component
function WorkflowStageVisualizer({ 
  currentStage, 
  stages 
}: { 
  currentStage: WorkflowStage; 
  stages: typeof workflowStages;
}) {
  const stageOrder: WorkflowStage[] = ['intake', 'dmo_review', 'cx_review', 'control_review', 'approved', 'live'];
  const currentIndex = stageOrder.indexOf(currentStage);

  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-2">
      {stageOrder.map((stage, index) => {
        const stageConfig = stages.find(s => s.stage === stage);
        const isCompleted = index < currentIndex;
        const isCurrent = stage === currentStage;
        const isPending = index > currentIndex;

        return (
          <div key={stage} className="flex items-center">
            <div
              className={cn(
                "flex flex-col items-center px-3 py-2 rounded-lg min-w-[100px] text-center",
                isCompleted && "bg-green-100 text-green-700",
                isCurrent && "bg-blue-100 text-blue-700 ring-2 ring-blue-500",
                isPending && "bg-gray-100 text-gray-500"
              )}
            >
              <span className="text-xs font-medium uppercase tracking-wider">
                {stageConfig?.label}
              </span>
              {isCompleted && <CheckCircle className="w-4 h-4 mt-1" />}
              {isCurrent && <Clock className="w-4 h-4 mt-1 animate-pulse" />}
              {isPending && <div className="w-4 h-4 mt-1 rounded-full border-2 border-gray-300" />}
            </div>
            {index < stageOrder.length - 1 && (
              <ChevronRight className={cn(
                "w-4 h-4 mx-1",
                isCompleted ? "text-green-500" : "text-gray-300"
              )} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// Comments Panel Component
function CommentsPanel({ 
  comments, 
  onAddComment,
  canComment 
}: { 
  comments: WorkflowComment[]; 
  onAddComment: (comment: string) => void;
  canComment: boolean;
}) {
  const [newComment, setNewComment] = useState('');

  const handleSubmit = () => {
    if (newComment.trim()) {
      onAddComment(newComment.trim());
      setNewComment('');
    }
  };

  return (
    <div className="space-y-4">
      {canComment && (
        <div className="space-y-2">
          <Textarea
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="min-h-[80px]"
          />
          <Button onClick={handleSubmit} size="sm" className="bg-[#062A78]">
            <MessageSquare className="w-4 h-4 mr-2" />
            Add Comment
          </Button>
        </div>
      )}
      
      <ScrollArea className="h-[300px]">
        <div className="space-y-3">
          {[...comments].reverse().map((comment) => (
            <div key={comment.id} className="p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#062A78] flex items-center justify-center text-white text-xs font-medium">
                    {comment.userName.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{comment.userName}</p>
                    <p className="text-xs text-muted-foreground">{comment.userRole}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="text-xs">
                    {workflowStages.find(s => s.stage === comment.stage)?.label}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(comment.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
              <p className="text-sm text-slate-700">{comment.comment}</p>
            </div>
          ))}
          {comments.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No comments yet</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

// Audit History Panel Component
function AuditHistoryPanel({ auditHistory }: { auditHistory: AuditEntry[] }) {
  return (
    <ScrollArea className="h-[400px]">
      <div className="space-y-3">
        {[...auditHistory].reverse().map((entry) => (
          <div key={entry.id} className="flex gap-3 p-3 bg-slate-50 rounded-lg">
            <div className="mt-1">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center",
                entry.action === 'approve' ? "bg-green-100 text-green-600" :
                entry.action === 'reject' ? "bg-red-100 text-red-600" :
                entry.action === 'submit' ? "bg-blue-100 text-blue-600" :
                "bg-gray-100 text-gray-600"
              )}>
                {entry.action === 'approve' ? <CheckCircle className="w-4 h-4" /> :
                 entry.action === 'reject' ? <XCircle className="w-4 h-4" /> :
                 entry.action === 'submit' ? <Send className="w-4 h-4" /> :
                 <History className="w-4 h-4" />}
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{entry.userName}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(entry.timestamp).toLocaleString()}
                </p>
              </div>
              <p className="text-xs text-muted-foreground">{entry.userRole}</p>
              <div className="flex items-center gap-2 mt-1">
                {entry.fromStage && (
                  <>
                    <Badge variant="outline" className="text-xs">
                      {workflowStages.find(s => s.stage === entry.fromStage)?.label}
                    </Badge>
                    <ArrowRight className="w-3 h-3 text-muted-foreground" />
                  </>
                )}
                <Badge className="text-xs bg-[#062A78]">
                  {workflowStages.find(s => s.stage === entry.toStage)?.label}
                </Badge>
              </div>
              {entry.comment && (
                <p className="text-sm text-slate-600 mt-2 italic">"{entry.comment}"</p>
              )}
            </div>
          </div>
        ))}
        {auditHistory.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No audit history yet</p>
          </div>
        )}
      </div>
    </ScrollArea>
  );
}

// Workflow Actions Panel
function WorkflowActionsPanel({
  journey,
  onAction,
}: {
  journey: Journey;
  onAction: (action: WorkflowAction, comment?: string) => void;
}) {
  const { getAvailableWorkflowActions } = useAppStore();
  const [comment, setComment] = useState('');
  const [showCommentInput, setShowCommentInput] = useState<WorkflowAction | null>(null);

  const availableActions = getAvailableWorkflowActions(journey);
  const stageConfig = workflowStages.find(s => s.stage === journey.workflowStage);

  const handleAction = (action: WorkflowAction) => {
    if (action === 'reject' || action === 'request_changes') {
      setShowCommentInput(action);
    } else {
      onAction(action, comment || undefined);
      setComment('');
    }
  };

  const handleActionWithComment = () => {
    if (showCommentInput) {
      onAction(showCommentInput, comment);
      setComment('');
      setShowCommentInput(null);
    }
  };

  if (availableActions.length === 0) {
    return (
      <div className="p-4 bg-gray-50 rounded-lg text-center">
        <Clock className="w-6 h-6 mx-auto mb-2 text-gray-400" />
        <p className="text-sm text-muted-foreground">
          Waiting for {stageConfig?.role.replace('_', ' ')} review
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {showCommentInput && (
        <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
          <Label className="text-amber-800">
            {showCommentInput === 'reject' ? 'Reason for Rejection' : 'Changes Requested'}
          </Label>
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Please provide details..."
            className="mt-2 bg-white"
          />
          <div className="flex gap-2 mt-3">
            <Button 
              onClick={handleActionWithComment}
              variant={showCommentInput === 'reject' ? 'destructive' : 'default'}
              size="sm"
            >
              {showCommentInput === 'reject' ? 'Reject' : 'Request Changes'}
            </Button>
            <Button 
              onClick={() => { setShowCommentInput(null); setComment(''); }}
              variant="outline"
              size="sm"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}

      {!showCommentInput && (
        <div className="flex flex-wrap gap-2">
          {availableActions.includes('submit') && (
            <Button onClick={() => handleAction('submit')} className="bg-[#062A78]">
              <Send className="w-4 h-4 mr-2" />
              Submit for Review
            </Button>
          )}
          {availableActions.includes('approve') && (
            <Button onClick={() => handleAction('approve')} className="bg-green-600 hover:bg-green-700">
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve
            </Button>
          )}
          {availableActions.includes('request_changes') && (
            <Button onClick={() => handleAction('request_changes')} variant="outline">
              <RotateCcw className="w-4 h-4 mr-2" />
              Request Changes
            </Button>
          )}
          {availableActions.includes('reject') && (
            <Button onClick={() => handleAction('reject')} variant="destructive">
              <XCircle className="w-4 h-4 mr-2" />
              Reject
            </Button>
          )}
          {availableActions.includes('pause') && (
            <Button onClick={() => handleAction('pause')} variant="outline">
              <Pause className="w-4 h-4 mr-2" />
              Pause
            </Button>
          )}
          {availableActions.includes('resume') && (
            <Button onClick={() => handleAction('resume')} className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-2" />
              Resume
            </Button>
          )}
          {availableActions.includes('archive') && (
            <Button onClick={() => handleAction('archive')} variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              Archive
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

// Journey Detail Dialog
function JourneyDetailDialog({
  journey,
  isOpen,
  onClose,
}: {
  journey: Journey | null;
  isOpen: boolean;
  onClose: () => void;
}) {
  const { transitionJourney, addJourneyComment } = useAppStore();
  const [activeTab, setActiveTab] = useState('overview');

  if (!journey) return null;

  const handleWorkflowAction = (action: WorkflowAction, comment?: string) => {
    transitionJourney(journey.id, action, comment);
    toast.success(`Journey ${action} successful`);
  };

  const handleAddComment = (comment: string) => {
    addJourneyComment(journey.id, comment, 'submit');
    toast.success('Comment added');
  };

  const stageConfig = workflowStages.find(s => s.stage === journey.workflowStage);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-hidden bg-white">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl">{journey.name}</DialogTitle>
              <DialogDescription>{journey.description}</DialogDescription>
            </div>
            <div className="flex gap-2">
              <Badge className={cn(
                journey.workflowStage === 'live' && "bg-green-100 text-green-700",
                journey.workflowStage === 'approved' && "bg-blue-100 text-blue-700",
                journey.workflowStage === 'rejected' && "bg-red-100 text-red-700",
                journey.workflowStage === 'paused' && "bg-amber-100 text-amber-700",
              )}>
                {stageConfig?.label}
              </Badge>
              <Badge variant="outline">{journey.lifecycleStage}</Badge>
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden">
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="workflow">Workflow</TabsTrigger>
            <TabsTrigger value="comments">
              Comments ({journey.comments.length})
            </TabsTrigger>
            <TabsTrigger value="audit">Audit History</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <WorkflowStageVisualizer currentStage={journey.workflowStage} stages={workflowStages} />
            
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Journey Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Created By</span>
                    <span className="text-sm font-medium">{journey.createdByName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Created At</span>
                    <span className="text-sm">{new Date(journey.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Priority</span>
                    <Badge variant="outline" className="capitalize">{journey.priority}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Template</span>
                    <span className="text-sm">{journey.templateName || 'Not assigned'}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Performance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Estimated Reach</span>
                    <span className="text-sm font-medium">{journey.estimatedReach.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Actual Reach</span>
                    <span className="text-sm font-medium">{journey.actualReach.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Conversion Rate</span>
                    <span className="text-sm font-medium">{journey.conversionRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Control Group</span>
                    <span className="text-sm">{journey.controlGroup?.enabled ? `${journey.controlGroup.percentage}%` : 'None'}</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Workflow Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <WorkflowActionsPanel 
                  journey={journey} 
                  onAction={handleWorkflowAction}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workflow" className="mt-4">
            <div className="space-y-4">
              <WorkflowStageVisualizer currentStage={journey.workflowStage} stages={workflowStages} />
              
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Current Stage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-lg font-semibold">{stageConfig?.label}</p>
                    <p className="text-sm text-muted-foreground mt-1">{stageConfig?.description}</p>
                    <div className="mt-4">
                      <p className="text-xs text-muted-foreground">Responsible Role</p>
                      <p className="text-sm font-medium capitalize">{stageConfig?.role.replace('_', ' ')}</p>
                    </div>
                    {stageConfig?.slaHours && (
                      <div className="mt-2">
                        <p className="text-xs text-muted-foreground">SLA</p>
                        <p className="text-sm">{stageConfig.slaHours} hours</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Available Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {stageConfig?.actions.map(action => (
                        <Badge key={action} variant="outline" className="capitalize">
                          {action.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="comments" className="mt-4">
            <CommentsPanel 
              comments={journey.comments}
              onAddComment={handleAddComment}
              canComment={true}
            />
          </TabsContent>

          <TabsContent value="audit" className="mt-4">
            <AuditHistoryPanel auditHistory={journey.auditHistory} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// Create Journey Dialog
function CreateJourneyDialog({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const { addJourney, templates, rules, user } = useAppStore();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    lifecycleStage: 'ACQUIRE' as const,
    priority: 'medium' as const,
    templateId: '',
    entryRuleId: '',
    estimatedReach: 1000,
  });

  const handleSubmit = () => {
    if (!formData.name || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    const template = templates.find(t => t.id === formData.templateId);

    addJourney({
      ...formData,
      workflowStage: 'intake',
      status: 'draft',
      createdBy: user?.id || '',
      createdByName: user?.name || '',
      templateName: template?.name,
      controlGroup: { enabled: false, percentage: 0, description: '' },
      approvalStatus: 'pending_dev',
      approvalHistory: [],
      comments: [],
      auditHistory: [{
        id: `ae${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user?.id || '',
        userName: user?.name || '',
        userRole: user?.role || 'viewer',
        action: 'submit',
        toStage: 'intake',
        comment: 'Journey request submitted',
      }],
      actualReach: 0,
      conversionRate: 0,
      tags: [],
    });

    toast.success('Journey created successfully');
    onClose();
    setFormData({
      name: '',
      description: '',
      lifecycleStage: 'ACQUIRE',
      priority: 'medium',
      templateId: '',
      entryRuleId: '',
      estimatedReach: 1000,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white">
        <DialogHeader>
          <DialogTitle>Create New Journey</DialogTitle>
          <DialogDescription>
            Submit a new journey request for review and approval
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Journey Name *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., New Account Welcome Series"
            />
          </div>

          <div className="space-y-2">
            <Label>Description *</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe the journey objectives and target audience..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Lifecycle Stage</Label>
              <Select
                value={formData.lifecycleStage}
                onValueChange={(v) => setFormData({ ...formData, lifecycleStage: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACQUIRE">Acquire</SelectItem>
                  <SelectItem value="ACTIVATE">Activate</SelectItem>
                  <SelectItem value="ENGAGE">Engage</SelectItem>
                  <SelectItem value="GROW">Grow</SelectItem>
                  <SelectItem value="RETAIN">Retain</SelectItem>
                  <SelectItem value="WIN_BACK">Win Back</SelectItem>
                  <SelectItem value="ADVOCATE">Advocate</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Priority</Label>
              <Select
                value={formData.priority}
                onValueChange={(v) => setFormData({ ...formData, priority: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Email Template</Label>
            <Select
              value={formData.templateId}
              onValueChange={(v) => setFormData({ ...formData, templateId: v })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a template" />
              </SelectTrigger>
              <SelectContent>
                {templates.filter(t => t.status === 'active' || t.status === 'approved').map(template => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Entry Rule (Customer Segment)</Label>
            <Select
              value={formData.entryRuleId}
              onValueChange={(v) => setFormData({ ...formData, entryRuleId: v })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a rule" />
              </SelectTrigger>
              <SelectContent>
                {rules.filter(r => r.status === 'active').map(rule => (
                  <SelectItem key={rule.id} value={rule.id}>
                    {rule.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Estimated Reach</Label>
            <Input
              type="number"
              value={formData.estimatedReach}
              onChange={(e) => setFormData({ ...formData, estimatedReach: parseInt(e.target.value) || 0 })}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} className="bg-[#062A78]">
            <Send className="w-4 h-4 mr-2" />
            Submit for Review
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Main Journeys Module
export function JourneysModule() {
  const { journeys } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [selectedJourney, setSelectedJourney] = useState<Journey | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredJourneys = journeys.filter(journey => {
    const matchesSearch = journey.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         journey.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStage = filterStage === 'all' || journey.workflowStage === filterStage;
    return matchesSearch && matchesStage;
  });

  const handleViewJourney = (journey: Journey) => {
    setSelectedJourney(journey);
    setIsDetailOpen(true);
  };

  const getStageBadgeColor = (stage: WorkflowStage) => {
    switch (stage) {
      case 'live': return 'bg-green-100 text-green-700';
      case 'approved': return 'bg-blue-100 text-blue-700';
      case 'control_review': return 'bg-purple-100 text-purple-700';
      case 'cx_review': return 'bg-orange-100 text-orange-700';
      case 'dmo_review': return 'bg-cyan-100 text-cyan-700';
      case 'intake': return 'bg-gray-100 text-gray-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      case 'paused': return 'bg-amber-100 text-amber-700';
      case 'archived': return 'bg-slate-100 text-slate-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Journeys</h2>
          <p className="text-muted-foreground">Manage customer lifecycle journeys</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)} className="bg-[#062A78]">
          <Plus className="w-4 h-4 mr-2" />
          Create Journey
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search journeys..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterStage} onValueChange={setFilterStage}>
          <SelectTrigger className="w-[180px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter by stage" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stages</SelectItem>
            <SelectItem value="intake">Intake</SelectItem>
            <SelectItem value="dmo_review">DMO Review</SelectItem>
            <SelectItem value="cx_review">CX Review</SelectItem>
            <SelectItem value="control_review">Control Review</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="live">Live</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Journey Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredJourneys.map((journey) => {
          const stageConfig = workflowStages.find(s => s.stage === journey.workflowStage);
          
          return (
            <Card 
              key={journey.id} 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => handleViewJourney(journey)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">{journey.name}</CardTitle>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {journey.description}
                    </p>
                  </div>
                  <Badge className={cn("ml-2 shrink-0", getStageBadgeColor(journey.workflowStage))}>
                    {stageConfig?.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    <span>{journey.createdByName}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{new Date(journey.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span>{journey.estimatedReach.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <BarChart3 className="w-4 h-4 text-muted-foreground" />
                    <span>{journey.conversionRate}%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4 text-muted-foreground" />
                    <span>{journey.comments.length}</span>
                  </div>
                </div>

                {journey.workflowStage === 'intake' && (
                  <div className="mt-3 p-2 bg-blue-50 rounded text-xs text-blue-700">
                    Waiting for DMO team review
                  </div>
                )}
                {journey.workflowStage === 'rejected' && (
                  <div className="mt-3 p-2 bg-red-50 rounded text-xs text-red-700">
                    Revision required
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredJourneys.length === 0 && (
        <div className="text-center py-12">
          <Route className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No journeys found</h3>
          <p className="text-muted-foreground">Create a new journey to get started</p>
        </div>
      )}

      {/* Dialogs */}
      <JourneyDetailDialog
        journey={selectedJourney}
        isOpen={isDetailOpen}
        onClose={() => { setIsDetailOpen(false); setSelectedJourney(null); }}
      />

      <CreateJourneyDialog
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />
    </div>
  );
}
