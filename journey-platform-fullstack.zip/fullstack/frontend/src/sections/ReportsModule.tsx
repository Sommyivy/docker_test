import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Download,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Calendar,
  Mail,
  Users,
  Target,
  Activity,
  FileText,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  PieChart as RePieChart,
  Pie,
  Cell,
} from 'recharts';
import { reportMetrics, journeyPerformance } from '@/data/mockData';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const stageColors = {
  ACQUIRE: '#06b6d4',
  ACTIVATE: '#3b82f6',
  ENGAGE: '#6366f1',
  GROW: '#8b5cf6',
  RETAIN: '#a855f7',
  WIN_BACK: '#f59e0b',
  ADVOCATE: '#10b981',
};

export function ReportsModule() {
  const { dashboardStats, journeys } = useAppStore();
  const [dateRange, setDateRange] = useState('30');

  const handleExport = (format: string) => {
    toast.success(`Report exported as ${format.toUpperCase()}`);
  };

  const stats = [
    {
      title: 'Total Emails Sent',
      value: dashboardStats.emailsSent.toLocaleString(),
      change: '+12.5%',
      trend: 'up',
      icon: Mail,
    },
    {
      title: 'Average Open Rate',
      value: `${dashboardStats.openRate}%`,
      change: '+2.1%',
      trend: 'up',
      icon: Activity,
    },
    {
      title: 'Average Click Rate',
      value: `${dashboardStats.clickRate}%`,
      change: '-0.5%',
      trend: 'down',
      icon: Target,
    },
    {
      title: 'Delivery Rate',
      value: `${dashboardStats.deliveryRate}%`,
      change: '+0.3%',
      trend: 'up',
      icon: Users,
    },
  ];

  const journeyStageData = Object.entries(
    journeys.reduce((acc, j) => {
      acc[j.lifecycleStage] = (acc[j.lifecycleStage] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  ).map(([stage, count]) => ({ name: stage, value: count, color: stageColors[stage as keyof typeof stageColors] }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Reports & Analytics</h2>
          <p className="text-muted-foreground">View performance metrics and generate reports</p>
        </div>
        <div className="flex gap-2">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[150px]">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => handleExport('csv')}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className={cn('p-2 rounded-lg', stat.trend === 'up' ? 'bg-green-50' : 'bg-red-50')}>
                  <stat.icon className={cn('w-5 h-5', stat.trend === 'up' ? 'text-green-600' : 'text-red-600')} />
                </div>
                <div className={cn(
                  'flex items-center gap-1 text-xs font-medium',
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                )}>
                  {stat.trend === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {stat.change}
                </div>
              </div>
              <div className="mt-3">
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="performance">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">
            <BarChart3 className="w-4 h-4 mr-2" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="journeys">
            <PieChart className="w-4 h-4 mr-2" />
            Journeys
          </TabsTrigger>
          <TabsTrigger value="trends">
            <Activity className="w-4 h-4 mr-2" />
            Trends
          </TabsTrigger>
          <TabsTrigger value="detailed">
            <FileText className="w-4 h-4 mr-2" />
            Detailed
          </TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Journey Performance Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={journeyPerformance} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="journeyName" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="totalSent" name="Total Sent" fill="#3b82f6" />
                    <Bar dataKey="delivered" name="Delivered" fill="#10b981" />
                    <Bar dataKey="opened" name="Opened" fill="#06b6d4" />
                    <Bar dataKey="clicked" name="Clicked" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>ROI by Journey</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={journeyPerformance} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="journeyName" type="category" width={150} />
                      <Tooltip />
                      <Bar dataKey="roi" name="ROI" fill="#F28A1A" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Conversion Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {journeyPerformance.map((j) => (
                    <div key={j.journeyId}>
                      <div className="flex justify-between text-sm mb-1">
                        <span>{j.journeyName}</span>
                        <span className="font-medium">
                          {j.totalSent > 0 ? ((j.converted / j.totalSent) * 100).toFixed(1) : 0}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-[#062A78] h-2 rounded-full" 
                          style={{ width: `${j.totalSent > 0 ? (j.converted / j.totalSent) * 100 : 0}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="journeys" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Journey Stages Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={journeyStageData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {journeyStageData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Journey Status Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {['running', 'scheduled', 'draft', 'paused', 'completed'].map((status) => {
                    const count = journeys.filter(j => j.status === status).length;
                    const total = journeys.length;
                    const percentage = total > 0 ? (count / total) * 100 : 0;
                    return (
                      <div key={status} className="flex items-center gap-4">
                        <span className="w-24 text-sm capitalize">{status}</span>
                        <div className="flex-1">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={cn(
                                'h-2 rounded-full',
                                status === 'running' ? 'bg-green-500' :
                                status === 'scheduled' ? 'bg-purple-500' :
                                status === 'draft' ? 'bg-gray-500' :
                                status === 'paused' ? 'bg-orange-500' :
                                'bg-blue-500'
                              )}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                        <span className="w-12 text-right text-sm font-medium">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Email Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={reportMetrics}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(d) => format(new Date(d), 'MMM d')} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="openRate" name="Open Rate %" stroke="#06b6d4" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="clickRate" name="Click Rate %" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="bounceRate" name="Bounce Rate %" stroke="#ef4444" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Volume Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={reportMetrics}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(d) => format(new Date(d), 'MMM d')} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="emailsSent" name="Emails Sent" fill="#3b82f6" />
                    <Bar dataKey="emailsDelivered" name="Delivered" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Detailed Metrics</CardTitle>
              <Button variant="outline" size="sm" onClick={() => handleExport('pdf')}>
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
            </CardHeader>
            <CardContent>
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Date</th>
                    <th className="text-right py-3 px-4">Journeys Run</th>
                    <th className="text-right py-3 px-4">Emails Sent</th>
                    <th className="text-right py-3 px-4">Delivered</th>
                    <th className="text-right py-3 px-4">Open Rate</th>
                    <th className="text-right py-3 px-4">Click Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {reportMetrics.slice(-10).reverse().map((metric, idx) => (
                    <tr key={idx} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4">{format(new Date(metric.date), 'MMM d, yyyy')}</td>
                      <td className="text-right py-3 px-4">{metric.journeysRun}</td>
                      <td className="text-right py-3 px-4">{metric.emailsSent.toLocaleString()}</td>
                      <td className="text-right py-3 px-4">{metric.emailsDelivered.toLocaleString()}</td>
                      <td className="text-right py-3 px-4">{metric.openRate.toFixed(1)}%</td>
                      <td className="text-right py-3 px-4">{metric.clickRate.toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
