import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  Plus,
  Search,
  MoreVertical,
  Edit,
  Trash2,
  Shield,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import type { User as UserType, UserRole, Permission } from '@/types';
import { format } from 'date-fns';

const roles: { value: UserRole; label: string }[] = [
  { value: 'super_admin', label: 'Super Admin' },
  { value: 'admin', label: 'Admin' },
  { value: 'developer', label: 'Developer' },
  { value: 'comms', label: 'Communications' },
  { value: 'compliance', label: 'Compliance' },
  { value: 'viewer', label: 'Viewer' },
];

const allPermissions: { value: Permission; label: string; category: string }[] = [
  { value: 'journeys:read', label: 'View Journeys', category: 'Journeys' },
  { value: 'journeys:create', label: 'Create Journeys', category: 'Journeys' },
  { value: 'journeys:edit', label: 'Edit Journeys', category: 'Journeys' },
  { value: 'journeys:delete', label: 'Delete Journeys', category: 'Journeys' },
  { value: 'journeys:approve', label: 'Approve Journeys', category: 'Journeys' },
  { value: 'rules:read', label: 'View Rules', category: 'Rules' },
  { value: 'rules:create', label: 'Create Rules', category: 'Rules' },
  { value: 'rules:edit', label: 'Edit Rules', category: 'Rules' },
  { value: 'rules:delete', label: 'Delete Rules', category: 'Rules' },
  { value: 'rules:validate', label: 'Validate Rules', category: 'Rules' },
  { value: 'templates:read', label: 'View Templates', category: 'Templates' },
  { value: 'templates:create', label: 'Create Templates', category: 'Templates' },
  { value: 'templates:edit', label: 'Edit Templates', category: 'Templates' },
  { value: 'templates:delete', label: 'Delete Templates', category: 'Templates' },
  { value: 'datasources:read', label: 'View Data Sources', category: 'Data Sources' },
  { value: 'datasources:create', label: 'Create Data Sources', category: 'Data Sources' },
  { value: 'datasources:edit', label: 'Edit Data Sources', category: 'Data Sources' },
  { value: 'datasources:delete', label: 'Delete Data Sources', category: 'Data Sources' },
  { value: 'datasources:test', label: 'Test Data Sources', category: 'Data Sources' },
  { value: 'runs:read', label: 'View Runs', category: 'Runs' },
  { value: 'runs:control', label: 'Control Runs', category: 'Runs' },
  { value: 'runs:monitor', label: 'Monitor Runs', category: 'Runs' },
  { value: 'admin:config', label: 'Admin Configuration', category: 'Admin' },
  { value: 'users:read', label: 'View Users', category: 'Users' },
  { value: 'users:create', label: 'Create Users', category: 'Users' },
  { value: 'users:edit', label: 'Edit Users', category: 'Users' },
  { value: 'users:delete', label: 'Delete Users', category: 'Users' },
  { value: 'users:manage_roles', label: 'Manage Roles', category: 'Users' },
  { value: 'reports:read', label: 'View Reports', category: 'Reports' },
  { value: 'reports:export', label: 'Export Reports', category: 'Reports' },
];

const rolePermissions: Record<UserRole, Permission[]> = {
  super_admin: allPermissions.map(p => p.value),
  admin: ['journeys:read', 'journeys:create', 'journeys:edit', 'rules:read', 'rules:create', 'rules:edit', 
          'templates:read', 'templates:create', 'templates:edit', 'datasources:read', 'datasources:test',
          'runs:read', 'runs:control', 'admin:config', 'users:read', 'reports:read', 'reports:export'],
  developer: ['journeys:read', 'journeys:create', 'journeys:edit', 'rules:read', 'rules:create', 'rules:edit', 'rules:validate',
              'templates:read', 'templates:create', 'templates:edit', 'datasources:read', 'runs:read'],
  comms: ['journeys:read', 'journeys:approve', 'templates:read', 'templates:edit', 'runs:read'],
  compliance: ['journeys:read', 'journeys:approve', 'rules:read', 'reports:read'],
  viewer: ['journeys:read', 'runs:read', 'reports:read'],
};

export function UsersModule() {
  const { users, addUser, updateUser, deleteUser } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'all'>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserType | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'developer' as UserRole,
    department: '',
    isActive: true,
    permissions: [] as Permission[],
  });

  const filteredUsers = users.filter((user) => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.department.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleSave = () => {
    const permissions = formData.permissions.length > 0 ? formData.permissions : rolePermissions[formData.role];
    
    if (editingUser) {
      updateUser(editingUser.id, { ...formData, permissions });
      toast.success('User updated successfully');
    } else {
      // Generate a temporary password for new users
      const tempPassword = 'Temp' + Math.random().toString(36).substring(2, 8) + '!';
      const expiryDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      
      addUser({ 
        ...formData, 
        permissions,
        passwordHash: 'temp_hash',
        isTemporaryPassword: true,
        passwordExpiresAt: expiryDate.toISOString(),
        failedLoginAttempts: 0,
      });
      
      toast.success(`User created successfully. Temporary password: ${tempPassword}`);
    }
    setIsDialogOpen(false);
    setEditingUser(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this user?')) {
      deleteUser(id);
      toast.success('User deleted successfully');
    }
  };

  const openEditDialog = (user: UserType) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      isActive: user.isActive,
      permissions: user.permissions,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      role: 'developer',
      department: '',
      isActive: true,
      permissions: [],
    });
  };

  const togglePermission = (permission: Permission) => {
    setFormData(prev => ({
      ...prev,
      permissions: prev.permissions.includes(permission)
        ? prev.permissions.filter(p => p !== permission)
        : [...prev.permissions, permission]
    }));
  };

  const permissionsByCategory = allPermissions.reduce((acc, perm) => {
    if (!acc[perm.category]) acc[perm.category] = [];
    acc[perm.category].push(perm);
    return acc;
  }, {} as Record<string, typeof allPermissions>);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">User Management</h2>
          <p className="text-muted-foreground">Manage users and their permissions</p>
        </div>
        <Button onClick={() => { setEditingUser(null); resetForm(); setIsDialogOpen(true); }} className="bg-[#062A78]">
          <Plus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={roleFilter} onValueChange={(v) => setRoleFilter(v as any)}>
              <SelectTrigger className="w-[180px]">
                <Shield className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                {roles.map((role) => (
                  <SelectItem key={role.value} value={role.value}>{role.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left py-3 px-4 font-medium">User</th>
                <th className="text-left py-3 px-4 font-medium">Role</th>
                <th className="text-left py-3 px-4 font-medium">Department</th>
                <th className="text-left py-3 px-4 font-medium">Status</th>
                <th className="text-left py-3 px-4 font-medium">Last Login</th>
                <th className="text-right py-3 px-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id} className="border-b hover:bg-muted/50">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#062A78] flex items-center justify-center text-white text-xs font-medium">
                        {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </div>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <Badge variant="outline">{user.role.replace('_', ' ')}</Badge>
                  </td>
                  <td className="py-3 px-4">{user.department}</td>
                  <td className="py-3 px-4">
                    {user.isActive ? (
                      <Badge className="bg-green-100 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    ) : (
                      <Badge className="bg-gray-100 text-gray-700">
                        <XCircle className="w-3 h-3 mr-1" />
                        Inactive
                      </Badge>
                    )}
                  </td>
                  <td className="py-3 px-4 text-muted-foreground">
                    {user.lastLogin ? format(new Date(user.lastLogin), 'MMM d, yyyy') : 'Never'}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditDialog(user)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDelete(user.id)} className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* User Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) { setIsDialogOpen(false); setEditingUser(null); resetForm(); } }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden bg-white">
          <DialogHeader>
            <DialogTitle>{editingUser ? 'Edit User' : 'Add New User'}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[60vh]">
            <div className="space-y-4 py-4 pr-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Role</Label>
                  <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v as UserRole, permissions: rolePermissions[v as UserRole] })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map((role) => (
                        <SelectItem key={role.value} value={role.value}>{role.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Input value={formData.department} onChange={(e) => setFormData({ ...formData, department: e.target.value })} />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Active</p>
                    <p className="text-sm text-muted-foreground">User can access the platform</p>
                  </div>
                </div>
                <Switch checked={formData.isActive} onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })} />
              </div>

              <div>
                <Label className="mb-3 block">Permissions</Label>
                <div className="space-y-4">
                  {Object.entries(permissionsByCategory).map(([category, perms]) => (
                    <div key={category} className="border rounded-lg p-4">
                      <h4 className="font-medium mb-3">{category}</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {perms.map((perm) => (
                          <div key={perm.value} className="flex items-center gap-2">
                            <Checkbox 
                              checked={formData.permissions.includes(perm.value)}
                              onCheckedChange={() => togglePermission(perm.value)}
                            />
                            <span className="text-sm">{perm.label}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollArea>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-[#062A78]" disabled={!formData.name || !formData.email}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
