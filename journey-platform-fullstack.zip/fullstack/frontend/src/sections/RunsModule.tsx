import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Play,
  Pause,
  Square,
  Search,
  Clock,
  CheckCircle,
  XCircle,
  RotateCw,
  Send,
  Eye,
  MousePointer,
  Ban,
  Activity,
} from 'lucide-react';
import type { JourneyRun, RunStatus } from '@/types';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';

const statusConfig: Record<RunStatus, { label: string; className: string; icon: any }> = {
  pending: { label: 'Pending', className: 'bg-gray-100 text-gray-700', icon: Clock },
  queued: { label: 'Queued', className: 'bg-blue-100 text-blue-700', icon: RotateCw },
  running: { label: 'Running', className: 'bg-green-100 text-green-700', icon: Play },
  paused: { label: 'Paused', className: 'bg-yellow-100 text-yellow-700', icon: Pause },
  completed: { label: 'Completed', className: 'bg-gray-100 text-gray-700', icon: CheckCircle },
  failed: { label: 'Failed', className: 'bg-red-100 text-red-700', icon: XCircle },
  cancelled: { label: 'Cancelled', className: 'bg-orange-100 text-orange-700', icon: Square },
};

export function RunsModule() {
  const { journeyRuns } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<RunStatus | 'all'>('all');
  const [selectedRun, setSelectedRun] = useState<JourneyRun | null>(null);

  const filteredRuns = journeyRuns.filter((run) => {
    const matchesSearch = run.journeyName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || run.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getProgress = (run: JourneyRun) => {
    if (run.totalRecords === 0) return 0;
    return Math.round((run.processedRecords / run.totalRecords) * 100);
  };

  const getDeliveryRate = (run: JourneyRun) => {
    if (run.successfulSends + run.failedSends === 0) return 0;
    return Math.round((run.successfulSends / (run.successfulSends + run.failedSends)) * 100);
  };

  const getOpenRate = (run: JourneyRun) => {
    if (run.successfulSends === 0) return 0;
    return Math.round((run.opened / run.successfulSends) * 100);
  };

  const getClickRate = (run: JourneyRun) => {
    if (run.successfulSends === 0) return 0;
    return Math.round((run.clicked / run.successfulSends) * 100);
  };

  const renderRunCard = (run: JourneyRun) => {
    const status = statusConfig[run.status];
    const StatusIcon = status.icon;
    const progress = getProgress(run);

    return (
      <Card key={run.id} className="card-hover cursor-pointer" onClick={() => setSelectedRun(run)}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={cn('p-2 rounded-lg', status.className.replace('text-', 'bg-opacity-20 bg-'))}>
                <StatusIcon className={cn('w-5 h-5', status.className.split(' ')[1])} />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{run.journeyName}</h3>
                <p className="text-xs text-muted-foreground">{run.id}</p>
              </div>
            </div>
            <Badge variant="outline" className={cn('text-xs', status.className)}>
              {status.label}
            </Badge>
          </div>

          {run.status === 'running' && (
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">
                {run.processedRecords.toLocaleString()} of {run.totalRecords.toLocaleString()} records
              </p>
            </div>
          )}

          <div className="grid grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <Send className="w-4 h-4 mx-auto mb-1 text-blue-600" />
              <p className="text-lg font-semibold">{run.successfulSends.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Sent</p>
            </div>
            <div className="text-center">
              <Eye className="w-4 h-4 mx-auto mb-1 text-cyan-600" />
              <p className="text-lg font-semibold">{getOpenRate(run)}%</p>
              <p className="text-xs text-muted-foreground">Open Rate</p>
            </div>
            <div className="text-center">
              <MousePointer className="w-4 h-4 mx-auto mb-1 text-purple-600" />
              <p className="text-lg font-semibold">{getClickRate(run)}%</p>
              <p className="text-xs text-muted-foreground">Click Rate</p>
            </div>
            <div className="text-center">
              <Ban className="w-4 h-4 mx-auto mb-1 text-red-600" />
              <p className="text-lg font-semibold">{run.bounced}</p>
              <p className="text-xs text-muted-foreground">Bounced</p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Started {formatDistanceToNow(new Date(run.startedAt), { addSuffix: true })}</span>
            <span>By {run.triggeredBy}</span>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Runs & Monitoring</h2>
          <p className="text-muted-foreground">Monitor journey execution and performance</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search runs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
              <SelectTrigger className="w-[150px]">
                <Activity className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {Object.entries(statusConfig).map(([key, config]) => (
                  <SelectItem key={key} value={key}>
                    {config.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Runs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRuns.map(renderRunCard)}
      </div>

      {filteredRuns.length === 0 && (
        <Card className="p-12 text-center">
          <Activity className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No runs found</h3>
          <p className="text-muted-foreground">
            {searchQuery || statusFilter !== 'all'
              ? 'Try adjusting your filters'
              : 'Journey runs will appear here'}
          </p>
        </Card>
      )}

      {/* Run Details Dialog */}
      <Dialog open={!!selectedRun} onOpenChange={() => setSelectedRun(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          {selectedRun && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedRun.journeyName}</DialogTitle>
                <DialogDescription>
                  Run ID: {selectedRun.id} • Started {format(new Date(selectedRun.startedAt), 'PPp')}
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="overview" className="flex-1">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="metrics">Metrics</TabsTrigger>
                  <TabsTrigger value="logs">Logs</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4 py-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Send className="w-5 h-5 mx-auto mb-2 text-blue-600" />
                        <p className="text-2xl font-bold">{selectedRun.successfulSends.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">Successful Sends</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Eye className="w-5 h-5 mx-auto mb-2 text-cyan-600" />
                        <p className="text-2xl font-bold">{selectedRun.opened.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">Opened</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <MousePointer className="w-5 h-5 mx-auto mb-2 text-purple-600" />
                        <p className="text-2xl font-bold">{selectedRun.clicked.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">Clicked</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <Ban className="w-5 h-5 mx-auto mb-2 text-red-600" />
                        <p className="text-2xl font-bold">{selectedRun.bounced.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">Bounced</p>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Delivery Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Delivery Rate</span>
                          <span className="font-medium">{getDeliveryRate(selectedRun)}%</span>
                        </div>
                        <Progress value={getDeliveryRate(selectedRun)} className="h-2" />
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Records:</span>
                          <span className="font-medium">{selectedRun.totalRecords.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Processed:</span>
                          <span className="font-medium">{selectedRun.processedRecords.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Failed:</span>
                          <span className="font-medium text-red-600">{selectedRun.failedSends.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Unsubscribed:</span>
                          <span className="font-medium">{selectedRun.unsubscribed.toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="metrics" className="space-y-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground mb-2">Open Rate</p>
                        <p className="text-3xl font-bold text-cyan-600">{getOpenRate(selectedRun)}%</p>
                        <p className="text-xs text-muted-foreground">
                          {selectedRun.opened.toLocaleString()} of {selectedRun.successfulSends.toLocaleString()} recipients
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground mb-2">Click Rate</p>
                        <p className="text-3xl font-bold text-purple-600">{getClickRate(selectedRun)}%</p>
                        <p className="text-xs text-muted-foreground">
                          {selectedRun.clicked.toLocaleString()} of {selectedRun.successfulSends.toLocaleString()} recipients
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground mb-2">Complaint Rate</p>
                        <p className="text-3xl font-bold text-red-600">
                          {selectedRun.successfulSends > 0 
                            ? ((selectedRun.complained / selectedRun.successfulSends) * 100).toFixed(3)
                            : 0}%
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {selectedRun.complained.toLocaleString()} complaints
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground mb-2">Unsubscribe Rate</p>
                        <p className="text-3xl font-bold text-orange-600">
                          {selectedRun.successfulSends > 0 
                            ? ((selectedRun.unsubscribed / selectedRun.successfulSends) * 100).toFixed(2)
                            : 0}%
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {selectedRun.unsubscribed.toLocaleString()} unsubscribed
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="logs" className="py-4">
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      {selectedRun.executionLogs.map((log, idx) => (
                        <div 
                          key={idx} 
                          className={cn(
                            'p-3 rounded-lg text-sm',
                            log.level === 'error' ? 'bg-red-50 text-red-700' :
                            log.level === 'warning' ? 'bg-yellow-50 text-yellow-700' :
                            'bg-slate-50 text-slate-700'
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(log.timestamp), 'HH:mm:ss')}
                            </span>
                            <Badge 
                              variant="outline" 
                              className={cn(
                                'text-[10px]',
                                log.level === 'error' ? 'border-red-300' :
                                log.level === 'warning' ? 'border-yellow-300' :
                                'border-slate-300'
                              )}
                            >
                              {log.level}
                            </Badge>
                          </div>
                          <p>{log.message}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
