import { useAppStore } from '@/store/appStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Route,
  FileCode,
  Mail,
  Database,
  PlayCircle,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  AlertCircle,
  Activity,
  Eye,
  MousePointer,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { reportMetrics, journeyPerformance, activityLogs } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const stageColors = {
  ACQUIRE: '#06b6d4',
  ACTIVATE: '#3b82f6',
  ENGAGE: '#6366f1',
  GROW: '#8b5cf6',
  RETAIN: '#a855f7',
  WIN_BACK: '#f59e0b',
  ADVOCATE: '#10b981',
};

const statusConfig = {
  draft: { label: 'Draft', className: 'bg-slate-100 text-slate-700' },
  pending_approval: { label: 'Pending Approval', className: 'bg-yellow-100 text-yellow-700' },
  approved: { label: 'Approved', className: 'bg-blue-100 text-blue-700' },
  scheduled: { label: 'Scheduled', className: 'bg-purple-100 text-purple-700' },
  running: { label: 'Running', className: 'bg-green-100 text-green-700' },
  paused: { label: 'Paused', className: 'bg-orange-100 text-orange-700' },
  completed: { label: 'Completed', className: 'bg-gray-100 text-gray-700' },
  cancelled: { label: 'Cancelled', className: 'bg-red-100 text-red-700' },
};

export function OverviewModule() {
  const { dashboardStats, journeys, dataSources, rules } = useAppStore();

  const statsCards = [
    {
      title: 'Total Journeys',
      value: dashboardStats.totalJourneys,
      change: '+12%',
      trend: 'up',
      icon: Route,
      color: 'bg-blue-500',
    },
    {
      title: 'Active Journeys',
      value: dashboardStats.activeJourneys,
      change: '+5%',
      trend: 'up',
      icon: PlayCircle,
      color: 'bg-green-500',
    },
    {
      title: 'Emails Sent',
      value: dashboardStats.emailsSent.toLocaleString(),
      change: '+23%',
      trend: 'up',
      icon: Mail,
      color: 'bg-purple-500',
    },
    {
      title: 'Delivery Rate',
      value: `${dashboardStats.deliveryRate}%`,
      change: '+1.2%',
      trend: 'up',
      icon: CheckCircle2,
      color: 'bg-emerald-500',
    },
    {
      title: 'Open Rate',
      value: `${dashboardStats.openRate}%`,
      change: '-2.1%',
      trend: 'down',
      icon: Eye,
      color: 'bg-cyan-500',
    },
    {
      title: 'Click Rate',
      value: `${dashboardStats.clickRate}%`,
      change: '+0.8%',
      trend: 'up',
      icon: MousePointer,
      color: 'bg-orange-500',
    },
  ];

  const recentJourneys = journeys.slice(0, 5);

  const stageDistribution = Object.entries(
    journeys.reduce((acc, j) => {
      acc[j.lifecycleStage] = (acc[j.lifecycleStage] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  ).map(([stage, count]) => ({ name: stage, value: count }));

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {statsCards.map((stat) => (
          <Card key={stat.title} className="card-hover">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className={cn('p-2 rounded-lg', stat.color.replace('bg-', 'bg-opacity-10 bg-'))}>
                  <stat.icon className={cn('w-5 h-5', stat.color.replace('bg-', 'text-'))} />
                </div>
                <div className={cn(
                  'flex items-center gap-1 text-xs font-medium',
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                )}>
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {stat.change}
                </div>
              </div>
              <div className="mt-3">
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email Performance Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Email Performance (Last 30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={reportMetrics}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(date) => format(new Date(date), 'MMM d')}
                    stroke="#64748b"
                    fontSize={12}
                  />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="openRate" 
                    name="Open Rate %" 
                    stroke="#06b6d4" 
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="clickRate" 
                    name="Click Rate %" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="bounceRate" 
                    name="Bounce Rate %" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Journey Stages Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Journey Stages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stageDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {stageDistribution.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={stageColors[entry.name as keyof typeof stageColors] || '#94a3b8'} 
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {stageDistribution.map((stage) => (
                <div key={stage.name} className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: stageColors[stage.name as keyof typeof stageColors] }}
                  />
                  <span className="text-xs text-muted-foreground">{stage.name}</span>
                  <span className="text-xs font-medium">{stage.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Second Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Journeys */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Recent Journeys</CardTitle>
            <Badge variant="outline">{journeys.length} Total</Badge>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">Name</th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">Stage</th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">Reach</th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground">Conversion</th>
                  </tr>
                </thead>
                <tbody>
                  {recentJourneys.map((journey) => (
                    <tr key={journey.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4">
                        <div>
                          <p className="font-medium">{journey.name}</p>
                          <p className="text-xs text-muted-foreground">{journey.description.slice(0, 50)}...</p>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge 
                          variant="outline" 
                          className={cn('text-xs', `stage-${journey.lifecycleStage.toLowerCase()}`)}
                        >
                          {journey.lifecycleStage}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <Badge 
                          variant="outline" 
                          className={cn('text-xs', statusConfig[journey.status]?.className)}
                        >
                          {statusConfig[journey.status]?.label || journey.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        {journey.actualReach > 0 
                          ? journey.actualReach.toLocaleString() 
                          : journey.estimatedReach.toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        {journey.conversionRate > 0 ? (
                          <div className="flex items-center gap-2">
                            <Progress value={journey.conversionRate} className="w-16 h-2" />
                            <span className="text-xs">{journey.conversionRate}%</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Data Sources */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">Data Sources</span>
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  {dataSources.filter(ds => ds.status === 'connected').length}/{dataSources.length} Connected
                </Badge>
              </div>
              <div className="space-y-1">
                {dataSources.slice(0, 4).map((ds) => (
                  <div key={ds.id} className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground truncate max-w-[150px]">{ds.name}</span>
                    <div className="flex items-center gap-1.5">
                      <div className={cn(
                        'w-2 h-2 rounded-full',
                        ds.status === 'connected' ? 'bg-green-500' : 
                        ds.status === 'error' ? 'bg-red-500' : 'bg-gray-400'
                      )} />
                      <span className={cn(
                        ds.status === 'connected' ? 'text-green-600' : 
                        ds.status === 'error' ? 'text-red-600' : 'text-gray-500'
                      )}>
                        {ds.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Active Rules */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Active Rules</span>
              </div>
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                {rules.filter(r => r.status === 'active').length}
              </Badge>
            </div>

            {/* Pending Approvals */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">Pending Approvals</span>
              </div>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                {dashboardStats.pendingApprovals}
              </Badge>
            </div>

            <Separator />

            {/* Activity Log */}
            <div>
              <p className="text-sm font-medium mb-3">Recent Activity</p>
              <ScrollArea className="h-40">
                <div className="space-y-3">
                  {activityLogs.slice(0, 10).map((log) => (
                    <div key={log.id} className="flex items-start gap-2 text-xs">
                      <Activity className="w-3 h-3 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-foreground">{log.action}</p>
                        <p className="text-muted-foreground">
                          {log.userName} • {format(new Date(log.timestamp), 'MMM d, HH:mm')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Journey Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Journey Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={journeyPerformance} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="journeyName" stroke="#64748b" fontSize={12} />
                <YAxis stroke="#64748b" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar dataKey="totalSent" name="Total Sent" fill="#3b82f6" />
                <Bar dataKey="delivered" name="Delivered" fill="#10b981" />
                <Bar dataKey="opened" name="Opened" fill="#06b6d4" />
                <Bar dataKey="clicked" name="Clicked" fill="#8b5cf6" />
                <Bar dataKey="converted" name="Converted" fill="#f59e0b" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
