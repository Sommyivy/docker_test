import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  Plus,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  Send,
  Mail,
  MessageSquare,
  History,
  FileText,
  User,
  ArrowRight,
  RotateCcw,
  Smartphone,
  Bell,
  MessageCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Template, WorkflowStage, WorkflowAction, WorkflowComment, AuditEntry } from '@/types';

// Template Workflow Stages (simplified for templates)
const templateWorkflowStages = [
  { stage: 'intake', role: 'business_user', label: 'Draft', description: 'Template being created', actions: ['submit'], canEdit: true, canComment: true },
  { stage: 'cx_review', role: 'cx_team', label: 'CX Review', description: 'CX team reviews content', actions: ['approve', 'request_changes', 'reject'], canEdit: true, canComment: true },
  { stage: 'control_review', role: 'control_team', label: 'Legal Review', description: 'Legal/Compliance review', actions: ['approve', 'request_changes', 'reject'], canEdit: false, canComment: true },
  { stage: 'approved', role: 'system', label: 'Approved', description: 'Template approved for use', actions: [], canEdit: false, canComment: true },
  { stage: 'active', role: 'system', label: 'Active', description: 'Template is live', actions: [], canEdit: false, canComment: false },
];

// Comments Panel Component
function CommentsPanel({ 
  comments, 
  onAddComment,
  canComment 
}: { 
  comments: WorkflowComment[]; 
  onAddComment: (comment: string) => void;
  canComment: boolean;
}) {
  const [newComment, setNewComment] = useState('');

  const handleSubmit = () => {
    if (newComment.trim()) {
      onAddComment(newComment.trim());
      setNewComment('');
    }
  };

  return (
    <div className="space-y-4">
      {canComment && (
        <div className="space-y-2">
          <Textarea
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="min-h-[80px]"
          />
          <Button onClick={handleSubmit} size="sm" className="bg-[#062A78]">
            <MessageSquare className="w-4 h-4 mr-2" />
            Add Comment
          </Button>
        </div>
      )}
      
      <ScrollArea className="h-[300px]">
        <div className="space-y-3">
          {[...comments].reverse().map((comment) => (
            <div key={comment.id} className="p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#062A78] flex items-center justify-center text-white text-xs font-medium">
                    {comment.userName.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{comment.userName}</p>
                    <p className="text-xs text-muted-foreground">{comment.userRole}</p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  {new Date(comment.timestamp).toLocaleString()}
                </p>
              </div>
              <p className="text-sm text-slate-700">{comment.comment}</p>
            </div>
          ))}
          {comments.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No comments yet</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

// Template Preview Component
function TemplatePreview({ template }: { template: Template }) {
  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="bg-[#062A78] p-4 text-white">
        <p className="text-sm opacity-75">Subject</p>
        <p className="font-medium">{template.subject}</p>
      </div>
      <div 
        className="p-6 bg-white"
        dangerouslySetInnerHTML={{ __html: template.htmlContent }}
      />
    </div>
  );
}

// Template Detail Dialog
function TemplateDetailDialog({
  template,
  isOpen,
  onClose,
}: {
  template: Template | null;
  isOpen: boolean;
  onClose: () => void;
}) {
  const { user, updateTemplate } = useAppStore();
  const [activeTab, setActiveTab] = useState('preview');
  const [comment, setComment] = useState('');
  const [showCommentInput, setShowCommentInput] = useState<WorkflowAction | null>(null);

  if (!template) return null;

  const stageConfig = templateWorkflowStages.find(s => s.stage === template.workflowStage);

  const getAvailableActions = () => {
    if (!user) return [];
    const actions = stageConfig?.actions || [];
    
    // Filter based on user role
    const roleMatches = 
      user.role === 'super_admin' ||
      (stageConfig?.role === 'cx_team' && user.role === 'comms') ||
      (stageConfig?.role === 'control_team' && user.role === 'compliance');

    return roleMatches ? actions : [];
  };

  const handleWorkflowAction = (action: WorkflowAction) => {
    const now = new Date().toISOString();
    let nextStage: WorkflowStage = template.workflowStage;

    switch (action) {
      case 'submit':
        nextStage = 'cx_review';
        break;
      case 'approve':
        if (template.workflowStage === 'cx_review') nextStage = 'control_review';
        else if (template.workflowStage === 'control_review') nextStage = 'approved';
        break;
      case 'reject':
        nextStage = 'intake';
        break;
      case 'request_changes':
        nextStage = 'intake';
        break;
    }

    const auditEntry: AuditEntry = {
      id: `ae${Date.now()}`,
      timestamp: now,
      userId: user?.id || '',
      userName: user?.name || '',
      userRole: user?.role || 'viewer',
      action,
      fromStage: template.workflowStage,
      toStage: nextStage,
      comment: comment || undefined,
    };

    let newComment: WorkflowComment | undefined;
    if (comment) {
      newComment = {
        id: `wc${Date.now()}`,
        stage: template.workflowStage,
        userId: user?.id || '',
        userName: user?.name || '',
        userRole: user?.role || 'viewer',
        comment,
        timestamp: now,
        action,
      };
    }

    updateTemplate(template.id, {
      workflowStage: nextStage,
      status: nextStage === 'approved' ? 'approved' : nextStage === 'intake' ? 'draft' : 'pending_review',
      auditHistory: [...template.auditHistory, auditEntry],
      comments: newComment ? [...template.comments, newComment] : template.comments,
    });

    toast.success(`Template ${action} successful`);
    setComment('');
    setShowCommentInput(null);
  };

  const handleAddComment = (commentText: string) => {
    const newComment: WorkflowComment = {
      id: `wc${Date.now()}`,
      stage: template.workflowStage,
      userId: user?.id || '',
      userName: user?.name || '',
      userRole: user?.role || 'viewer',
      comment: commentText,
      timestamp: new Date().toISOString(),
      action: 'submit',
    };

    updateTemplate(template.id, {
      comments: [...template.comments, newComment],
    });

    toast.success('Comment added');
  };

  const availableActions = getAvailableActions();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-hidden bg-white">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl">{template.name}</DialogTitle>
              <DialogDescription>{template.description}</DialogDescription>
            </div>
            <div className="flex gap-2">
              <Badge className={cn(
                template.workflowStage === 'approved' && "bg-green-100 text-green-700",
                template.workflowStage === 'cx_review' && "bg-orange-100 text-orange-700",
                template.workflowStage === 'control_review' && "bg-purple-100 text-purple-700",
                template.workflowStage === 'intake' && "bg-gray-100 text-gray-700",
              )}>
                {stageConfig?.label}
              </Badge>
              <Badge variant="outline" className="capitalize">{template.type}</Badge>
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden">
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="preview">Preview</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="comments">Comments ({template.comments.length})</TabsTrigger>
            <TabsTrigger value="audit">Audit History</TabsTrigger>
          </TabsList>

          <TabsContent value="preview" className="mt-4">
            <TemplatePreview template={template} />
          </TabsContent>

          <TabsContent value="details" className="mt-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Template Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Created By</span>
                    <span className="text-sm font-medium">{template.createdByName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Created At</span>
                    <span className="text-sm">{new Date(template.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Category</span>
                    <Badge variant="outline">{template.category}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Variables</span>
                    <span className="text-sm">{template.variables.length}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Compliance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Brand Guidelines</span>
                    <CheckCircle className={cn(
                      "w-4 h-4",
                      template.brandGuidelinesCompliant ? "text-green-500" : "text-gray-300"
                    )} />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Legal Approved</span>
                    <CheckCircle className={cn(
                      "w-4 h-4",
                      template.legalApproved ? "text-green-500" : "text-gray-300"
                    )} />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Workflow Actions */}
            {availableActions.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Workflow Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  {showCommentInput && (
                    <div className="mb-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
                      <Label className="text-amber-800">
                        {showCommentInput === 'reject' ? 'Reason for Rejection' : 'Changes Requested'}
                      </Label>
                      <Textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Please provide details..."
                        className="mt-2 bg-white"
                      />
                      <div className="flex gap-2 mt-3">
                        <Button 
                          onClick={() => handleWorkflowAction(showCommentInput)}
                          variant={showCommentInput === 'reject' ? 'destructive' : 'default'}
                          size="sm"
                        >
                          {showCommentInput === 'reject' ? 'Reject' : 'Request Changes'}
                        </Button>
                        <Button 
                          onClick={() => { setShowCommentInput(null); setComment(''); }}
                          variant="outline"
                          size="sm"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}

                  {!showCommentInput && (
                    <div className="flex flex-wrap gap-2">
                      {availableActions.includes('submit') && (
                        <Button onClick={() => handleWorkflowAction('submit')} className="bg-[#062A78]">
                          <Send className="w-4 h-4 mr-2" />
                          Submit for Review
                        </Button>
                      )}
                      {availableActions.includes('approve') && (
                        <Button onClick={() => handleWorkflowAction('approve')} className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Approve
                        </Button>
                      )}
                      {availableActions.includes('request_changes') && (
                        <Button onClick={() => setShowCommentInput('request_changes')} variant="outline">
                          <RotateCcw className="w-4 h-4 mr-2" />
                          Request Changes
                        </Button>
                      )}
                      {availableActions.includes('reject') && (
                        <Button onClick={() => setShowCommentInput('reject')} variant="destructive">
                          <XCircle className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="comments" className="mt-4">
            <CommentsPanel 
              comments={template.comments}
              onAddComment={handleAddComment}
              canComment={true}
            />
          </TabsContent>

          <TabsContent value="audit" className="mt-4">
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {[...template.auditHistory].reverse().map((entry) => (
                  <div key={entry.id} className="flex gap-3 p-3 bg-slate-50 rounded-lg">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center",
                      entry.action === 'approve' ? "bg-green-100 text-green-600" :
                      entry.action === 'reject' ? "bg-red-100 text-red-600" :
                      entry.action === 'submit' ? "bg-blue-100 text-blue-600" :
                      "bg-gray-100 text-gray-600"
                    )}>
                      {entry.action === 'approve' ? <CheckCircle className="w-4 h-4" /> :
                       entry.action === 'reject' ? <XCircle className="w-4 h-4" /> :
                       entry.action === 'submit' ? <Send className="w-4 h-4" /> :
                       <History className="w-4 h-4" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{entry.userName}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(entry.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        {entry.fromStage && (
                          <>
                            <Badge variant="outline" className="text-xs">
                              {templateWorkflowStages.find(s => s.stage === entry.fromStage)?.label}
                            </Badge>
                            <ArrowRight className="w-3 h-3 text-muted-foreground" />
                          </>
                        )}
                        <Badge className="text-xs bg-[#062A78]">
                          {templateWorkflowStages.find(s => s.stage === entry.toStage)?.label}
                        </Badge>
                      </div>
                      {entry.comment && (
                        <p className="text-sm text-slate-600 mt-2 italic">"{entry.comment}"</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// Create Template Dialog
function CreateTemplateDialog({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const { addTemplate, user } = useAppStore();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'email' as const,
    subject: '',
    htmlContent: '',
    category: '',
  });

  const handleSubmit = () => {
    if (!formData.name || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    addTemplate({
      ...formData,
      workflowStage: 'intake',
      status: 'draft',
      createdBy: user?.id || '',
      createdByName: user?.name || '',
      htmlContent: formData.htmlContent || '<p>Template content</p>',
      variables: [],
      comments: [],
      auditHistory: [{
        id: `ae${Date.now()}`,
        timestamp: new Date().toISOString(),
        userId: user?.id || '',
        userName: user?.name || '',
        userRole: user?.role || 'viewer',
        action: 'submit',
        toStage: 'intake',
        comment: 'Template created',
      }],
      tags: [],
      brandGuidelinesCompliant: false,
      legalApproved: false,
    });

    toast.success('Template created successfully');
    onClose();
    setFormData({
      name: '',
      description: '',
      type: 'email',
      subject: '',
      htmlContent: '',
      category: '',
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white">
        <DialogHeader>
          <DialogTitle>Create New Template</DialogTitle>
          <DialogDescription>
            Create a new communication template for review
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Template Name *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Welcome Email - New Customers"
            />
          </div>

          <div className="space-y-2">
            <Label>Description *</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe the purpose of this template..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select
                value={formData.type}
                onValueChange={(v) => setFormData({ ...formData, type: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="push">Push Notification</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={formData.category}
                onValueChange={(v) => setFormData({ ...formData, category: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Onboarding">Onboarding</SelectItem>
                  <SelectItem value="Transactional">Transactional</SelectItem>
                  <SelectItem value="Marketing">Marketing</SelectItem>
                  <SelectItem value="Retention">Retention</SelectItem>
                  <SelectItem value="VIP">VIP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {formData.type === 'email' && (
            <div className="space-y-2">
              <Label>Subject Line</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="e.g., Welcome to Access Bank!"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label>HTML Content</Label>
            <Textarea
              value={formData.htmlContent}
              onChange={(e) => setFormData({ ...formData, htmlContent: e.target.value })}
              placeholder="<p>Your template content here...</p>"
              className="min-h-[200px] font-mono text-sm"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} className="bg-[#062A78]">
            <Send className="w-4 h-4 mr-2" />
            Save as Draft
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Main Templates Module
export function TemplatesModule() {
  const { templates } = useAppStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || template.type === filterType;
    const matchesStage = filterStage === 'all' || template.workflowStage === filterStage;
    return matchesSearch && matchesType && matchesStage;
  });

  const handleViewTemplate = (template: Template) => {
    setSelectedTemplate(template);
    setIsDetailOpen(true);
  };

  const getStageBadgeColor = (stage: WorkflowStage) => {
    switch (stage) {
      case 'approved': return 'bg-green-100 text-green-700';
      case 'cx_review': return 'bg-orange-100 text-orange-700';
      case 'control_review': return 'bg-purple-100 text-purple-700';
      case 'intake': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email': return <Mail className="w-4 h-4" />;
      case 'sms': return <MessageCircle className="w-4 h-4" />;
      case 'push': return <Bell className="w-4 h-4" />;
      case 'whatsapp': return <Smartphone className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Templates</h2>
          <p className="text-muted-foreground">Manage communication templates</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)} className="bg-[#062A78]">
          <Plus className="w-4 h-4 mr-2" />
          Create Template
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-[150px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="email">Email</SelectItem>
            <SelectItem value="sms">SMS</SelectItem>
            <SelectItem value="push">Push</SelectItem>
            <SelectItem value="whatsapp">WhatsApp</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterStage} onValueChange={setFilterStage}>
          <SelectTrigger className="w-[150px]">
            <Clock className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Stage" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stages</SelectItem>
            <SelectItem value="intake">Draft</SelectItem>
            <SelectItem value="cx_review">CX Review</SelectItem>
            <SelectItem value="control_review">Legal Review</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Template Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map((template) => {
          const stageConfig = templateWorkflowStages.find(s => s.stage === template.workflowStage);
          
          return (
            <Card 
              key={template.id} 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => handleViewTemplate(template)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-slate-100">
                      {getTypeIcon(template.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate">{template.name}</CardTitle>
                      <p className="text-xs text-muted-foreground">{template.category}</p>
                    </div>
                  </div>
                  <Badge className={cn("shrink-0", getStageBadgeColor(template.workflowStage))}>
                    {stageConfig?.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                  {template.description}
                </p>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    <span>{template.createdByName}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-3 h-3" />
                      <span>{template.comments.length}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(template.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-12">
          <Mail className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">No templates found</h3>
          <p className="text-muted-foreground">Create a new template to get started</p>
        </div>
      )}

      {/* Dialogs */}
      <TemplateDetailDialog
        template={selectedTemplate}
        isOpen={isDetailOpen}
        onClose={() => { setIsDetailOpen(false); setSelectedTemplate(null); }}
      />

      <CreateTemplateDialog
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />
    </div>
  );
}
