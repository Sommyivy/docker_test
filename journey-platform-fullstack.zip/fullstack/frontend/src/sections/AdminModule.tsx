import { useState, useEffect } from 'react';
import { useAppStore } from '@/store/appStore';
import api from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import {
  Plus,
  Mail,
  Server,
  MoreVertical,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Send,
  RefreshCw,
  Shield,
  Eye,
  EyeOff,
  RotateCw,
  Settings,
  AlertTriangle,
  Clock,
  Users,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function AdminModule() {
  const { user } = useAppStore();
  const [smtpConfigs, setSmtpConfigs] = useState<any[]>([]);
  const [emailAliases, setEmailAliases] = useState<any[]>([]);

  useEffect(() => {
    api.admin.getEmailConfigs().then((r: any) => setSmtpConfigs(r.data || [])).catch(() => {});
    api.admin.getEmailAliases().then((r: any) => setEmailAliases(r.data || [])).catch(() => {});
  }, []);

  const addSmtpConfig = async (data: any) => { const r = await api.admin.createEmailConfig(data); if (r.success) setSmtpConfigs((prev: any[]) => [...prev, r.data]); };
  const updateSmtpConfig = async (id: string, data: any) => { const r = await api.admin.updateEmailConfig(id, data); if (r.success) setSmtpConfigs((prev: any[]) => prev.map((c: any) => c.id === id ? r.data : c)); };
  const deleteSmtpConfig = async (id: string) => { await api.admin.deleteEmailConfig(id); setSmtpConfigs((prev: any[]) => prev.filter((c: any) => c.id !== id)); };
  const testSmtpConfig = async (id: string) => { const r = await api.admin.testEmailConfig(id); return r.data; };
  const setDefaultSmtpConfig = async (id: string) => { await api.admin.setDefaultEmailConfig(id); setSmtpConfigs((prev: any[]) => prev.map((c: any) => ({ ...c, isDefault: c.id === id }))); };
  const addEmailAlias = async (data: any) => { const r = await api.admin.createEmailAlias(data); if (r.success) setEmailAliases((prev: any[]) => [...prev, r.data]); };
  const updateEmailAlias = async (id: string, data: any) => { const r = await api.admin.updateEmailAlias(id, data); if (r.success) setEmailAliases((prev: any[]) => prev.map((a: any) => a.id === id ? r.data : a)); };
  const deleteEmailAlias = async (id: string) => { await api.admin.deleteEmailAlias(id); setEmailAliases((prev: any[]) => prev.filter((a: any) => a.id !== id)); };
  const mailboxes: any[] = [];
  const emailRotationConfigs: any[] = [];
  const addMailbox = async (_d: any) => {};
  const updateMailbox = async (_id: string, _d: any) => {};
  const deleteMailbox = async (_id: string) => {};
  const addRotationConfig = async (_d: any) => {};
  const updateRotationConfig = async (_id: string, _d: any) => {};
  const deleteRotationConfig = async (_id: string) => {};
  const toggleRotationConfig = async (_id: string) => {};
  const getRotationPoolMailboxes = (_id: string) => [];
  const resetMailboxDailyCounts = async () => {};

  const [activeTab, setActiveTab] = useState('smtp');
  const [isSmtpDialogOpen, setIsSmtpDialogOpen] = useState(false);
  const [isMailboxDialogOpen, setIsMailboxDialogOpen] = useState(false);
  const [isAliasDialogOpen, setIsAliasDialogOpen] = useState(false);
  const [isRotationDialogOpen, setIsRotationDialogOpen] = useState(false);
  const [editingSmtp, setEditingSmtp] = useState<SMTPConfig | null>(null);
  const [editingMailbox, setEditingMailbox] = useState<Mailbox | null>(null);
  const [editingAlias, setEditingAlias] = useState<EmailAlias | null>(null);
  const [editingRotation, setEditingRotation] = useState<EmailRotationConfig | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [selectedMailboxIds, setSelectedMailboxIds] = useState<string[]>([]);

  // Form states
  const [smtpForm, setSmtpForm] = useState({
    name: '',
    host: '',
    port: 587,
    username: '',
    password: '',
    encryption: 'tls' as 'none' | 'tls' | 'ssl',
    fromEmail: '',
    fromName: '',
    isDefault: false,
    isActive: true,
  });

  const [mailboxForm, setMailboxForm] = useState({
    email: '',
    name: '',
    department: '',
    smtpConfigId: '',
    dailyLimit: 10000,
    sentToday: 0,
    isActive: true,
    inRotationPool: true,
    rotationPriority: 1,
  });

  const [aliasForm, setAliasForm] = useState({
    alias: '',
    targetEmail: '',
    description: '',
    isActive: true,
  });

  const [rotationForm, setRotationForm] = useState({
    name: '',
    description: '',
    enabled: true,
    rotationThreshold: 10000,
    rotationStrategy: 'round_robin' as 'round_robin' | 'least_used' | 'priority_based' | 'random',
    batchSize: 1000,
    cooldownMinutes: 5,
    mailboxIds: [] as string[],
    maxEmailsPerMailboxPerHour: 2000,
    maxEmailsPerMailboxPerDay: 10000,
    pauseOnHighBounceRate: true,
    bounceRateThreshold: 5,
    pauseOnHighComplaintRate: true,
    complaintRateThreshold: 0.1,
    activeHoursStart: '08:00',
    activeHoursEnd: '20:00',
    respectMailboxLimits: true,
  });

  const handleSaveSmtp = () => {
    if (editingSmtp) {
      updateSmtpConfig(editingSmtp.id, smtpForm);
      toast.success('SMTP configuration updated');
    } else {
      addSmtpConfig(smtpForm);
      toast.success('SMTP configuration added');
    }
    setIsSmtpDialogOpen(false);
    setEditingSmtp(null);
    resetSmtpForm();
  };

  const handleSaveMailbox = () => {
    if (editingMailbox) {
      updateMailbox(editingMailbox.id, mailboxForm);
      toast.success('Mailbox updated');
    } else {
      addMailbox(mailboxForm);
      toast.success('Mailbox added');
    }
    setIsMailboxDialogOpen(false);
    setEditingMailbox(null);
    resetMailboxForm();
  };

  const handleSaveAlias = () => {
    if (editingAlias) {
      updateEmailAlias(editingAlias.id, aliasForm);
      toast.success('Email alias updated');
    } else {
      addEmailAlias(aliasForm);
      toast.success('Email alias added');
    }
    setIsAliasDialogOpen(false);
    setEditingAlias(null);
    resetAliasForm();
  };

  const handleSaveRotation = () => {
    const formData = { ...rotationForm, mailboxIds: selectedMailboxIds };
    if (editingRotation) {
      updateRotationConfig(editingRotation.id, formData);
      toast.success('Rotation configuration updated');
    } else {
      addRotationConfig({ ...formData, createdBy: 'current-user' });
      toast.success('Rotation configuration added');
    }
    setIsRotationDialogOpen(false);
    setEditingRotation(null);
    resetRotationForm();
  };

  const handleDeleteRotation = (id: string) => {
    if (confirm('Are you sure you want to delete this rotation configuration?')) {
      deleteRotationConfig(id);
      toast.success('Rotation configuration deleted');
    }
  };

  const handleToggleRotation = (id: string) => {
    toggleRotationConfig(id);
    const config = emailRotationConfigs.find(c => c.id === id);
    toast.success(`Rotation ${config?.enabled ? 'disabled' : 'enabled'}`);
  };

  const handleResetMailboxCounts = () => {
    if (confirm('Are you sure you want to reset all mailbox daily send counts?')) {
      resetMailboxDailyCounts();
      toast.success('Mailbox daily counts reset');
    }
  };

  const handleTestSmtp = (id: string) => {
    testSmtpConfig(id);
    toast.info('Testing SMTP connection...');
  };

  const handleSetDefault = (id: string) => {
    setDefaultSmtpConfig(id);
    toast.success('Default SMTP configuration updated');
  };

  const handleDeleteSmtp = (id: string) => {
    if (confirm('Are you sure you want to delete this SMTP configuration?')) {
      deleteSmtpConfig(id);
      toast.success('SMTP configuration deleted');
    }
  };

  const handleDeleteMailbox = (id: string) => {
    if (confirm('Are you sure you want to delete this mailbox?')) {
      deleteMailbox(id);
      toast.success('Mailbox deleted');
    }
  };

  const handleDeleteAlias = (id: string) => {
    if (confirm('Are you sure you want to delete this alias?')) {
      deleteEmailAlias(id);
      toast.success('Email alias deleted');
    }
  };

  const openEditSmtp = (config: SMTPConfig) => {
    setEditingSmtp(config);
    setSmtpForm({
      name: config.name,
      host: config.host,
      port: config.port,
      username: config.username,
      password: config.password,
      encryption: config.encryption,
      fromEmail: config.fromEmail,
      fromName: config.fromName,
      isDefault: config.isDefault,
      isActive: config.isActive,
    });
    setIsSmtpDialogOpen(true);
  };

  const openEditMailbox = (mailbox: Mailbox) => {
    setEditingMailbox(mailbox);
    setMailboxForm({
      email: mailbox.email,
      name: mailbox.name,
      department: mailbox.department,
      smtpConfigId: mailbox.smtpConfigId,
      dailyLimit: mailbox.dailyLimit,
      sentToday: mailbox.sentToday || 0,
      isActive: mailbox.isActive,
      inRotationPool: mailbox.inRotationPool ?? true,
      rotationPriority: mailbox.rotationPriority ?? 1,
    });
    setIsMailboxDialogOpen(true);
  };

  const openEditAlias = (alias: EmailAlias) => {
    setEditingAlias(alias);
    setAliasForm({
      alias: alias.alias,
      targetEmail: alias.targetEmail,
      description: alias.description || '',
      isActive: alias.isActive,
    });
    setIsAliasDialogOpen(true);
  };

  const resetSmtpForm = () => {
    setSmtpForm({
      name: '',
      host: '',
      port: 587,
      username: '',
      password: '',
      encryption: 'tls',
      fromEmail: '',
      fromName: '',
      isDefault: false,
      isActive: true,
    });
    setShowPassword(false);
  };

  const resetMailboxForm = () => {
    setMailboxForm({
      email: '',
      name: '',
      department: '',
      smtpConfigId: '',
      dailyLimit: 10000,
      sentToday: 0,
      isActive: true,
      inRotationPool: true,
      rotationPriority: 1,
    });
  };

  const resetAliasForm = () => {
    setAliasForm({
      alias: '',
      targetEmail: '',
      description: '',
      isActive: true,
    });
  };

  const openEditRotation = (config: EmailRotationConfig) => {
    setEditingRotation(config);
    setRotationForm({
      name: config.name,
      description: config.description || '',
      enabled: config.enabled,
      rotationThreshold: config.rotationThreshold,
      rotationStrategy: config.rotationStrategy,
      batchSize: config.batchSize,
      cooldownMinutes: config.cooldownMinutes,
      mailboxIds: config.mailboxIds,
      maxEmailsPerMailboxPerHour: config.maxEmailsPerMailboxPerHour,
      maxEmailsPerMailboxPerDay: config.maxEmailsPerMailboxPerDay,
      pauseOnHighBounceRate: config.pauseOnHighBounceRate,
      bounceRateThreshold: config.bounceRateThreshold,
      pauseOnHighComplaintRate: config.pauseOnHighComplaintRate,
      complaintRateThreshold: config.complaintRateThreshold,
      activeHoursStart: config.activeHoursStart || '08:00',
      activeHoursEnd: config.activeHoursEnd || '20:00',
      respectMailboxLimits: config.respectMailboxLimits,
    });
    setSelectedMailboxIds(config.mailboxIds);
    setIsRotationDialogOpen(true);
  };

  const resetRotationForm = () => {
    setRotationForm({
      name: '',
      description: '',
      enabled: true,
      rotationThreshold: 10000,
      rotationStrategy: 'round_robin',
      batchSize: 1000,
      cooldownMinutes: 5,
      mailboxIds: [],
      maxEmailsPerMailboxPerHour: 2000,
      maxEmailsPerMailboxPerDay: 10000,
      pauseOnHighBounceRate: true,
      bounceRateThreshold: 5,
      pauseOnHighComplaintRate: true,
      complaintRateThreshold: 0.1,
      activeHoursStart: '08:00',
      activeHoursEnd: '20:00',
      respectMailboxLimits: true,
    });
    setSelectedMailboxIds([]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Admin Settings</h2>
        <p className="text-muted-foreground">Configure SMTP, mailboxes, and email aliases</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="smtp">
            <Server className="w-4 h-4 mr-2" />
            SMTP Config
          </TabsTrigger>
          <TabsTrigger value="mailboxes">
            <Mail className="w-4 h-4 mr-2" />
            Mailboxes
          </TabsTrigger>
          <TabsTrigger value="aliases">
            <Send className="w-4 h-4 mr-2" />
            Aliases
          </TabsTrigger>
          <TabsTrigger value="rotation">
            <RotateCw className="w-4 h-4 mr-2" />
            Rotation
          </TabsTrigger>
        </TabsList>

        {/* SMTP Configurations */}
        <TabsContent value="smtp" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">SMTP Configurations</h3>
            <Button onClick={() => { setEditingSmtp(null); resetSmtpForm(); setIsSmtpDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Add SMTP
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {smtpConfigs.map((config) => (
              <Card key={config.id} className={cn(!config.isActive && 'opacity-60')}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                        <Server className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{config.name}</h4>
                        <p className="text-xs text-muted-foreground">{config.host}:{config.port}</p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditSmtp(config)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleTestSmtp(config.id)}>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Test
                        </DropdownMenuItem>
                        {!config.isDefault && (
                          <DropdownMenuItem onClick={() => handleSetDefault(config.id)}>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Set as Default
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => handleDeleteSmtp(config.id)} className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">From:</span>
                      <span>{config.fromEmail}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Shield className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Encryption:</span>
                      <span className="uppercase">{config.encryption}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {config.isDefault && (
                      <Badge className="bg-green-100 text-green-700">Default</Badge>
                    )}
                    {!config.isActive && (
                      <Badge variant="outline">Inactive</Badge>
                    )}
                    {config.testStatus === 'success' && (
                      <Badge className="bg-green-100 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Test OK
                      </Badge>
                    )}
                    {config.testStatus === 'failed' && (
                      <Badge className="bg-red-100 text-red-700">
                        <XCircle className="w-3 h-3 mr-1" />
                        Failed
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Mailboxes */}
        <TabsContent value="mailboxes" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Mailboxes</h3>
            <Button onClick={() => { setEditingMailbox(null); resetMailboxForm(); setIsMailboxDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Mailbox
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mailboxes.map((mailbox) => (
              <Card key={mailbox.id} className={cn(!mailbox.isActive && 'opacity-60')}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                        <Mail className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{mailbox.name}</h4>
                        <p className="text-xs text-muted-foreground">{mailbox.email}</p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditMailbox(mailbox)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDeleteMailbox(mailbox.id)} className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="space-y-2 mb-3">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">Department:</span>
                      <span>{mailbox.department}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">Daily Limit:</span>
                      <span>{mailbox.dailyLimit.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    {mailbox.inRotationPool && (
                      <Badge className="bg-purple-100 text-purple-700 text-xs">
                        <RotateCw className="w-3 h-3 mr-1" />
                        Rotation Pool
                      </Badge>
                    )}
                    {mailbox.rotationPriority && mailbox.inRotationPool && (
                      <Badge variant="outline" className="text-xs">Priority {mailbox.rotationPriority}</Badge>
                    )}
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Usage Today</span>
                      <span>{Math.round(((mailbox.sentToday || 0) / mailbox.dailyLimit) * 100)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={cn(
                          "h-2 rounded-full",
                          ((mailbox.sentToday || 0) / mailbox.dailyLimit) > 0.9 ? "bg-red-600" :
                          ((mailbox.sentToday || 0) / mailbox.dailyLimit) > 0.7 ? "bg-yellow-600" : "bg-blue-600"
                        )}
                        style={{ width: `${Math.min(((mailbox.sentToday || 0) / mailbox.dailyLimit) * 100, 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {(mailbox.sentToday || 0).toLocaleString()} of {mailbox.dailyLimit.toLocaleString()} sent
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Email Aliases */}
        <TabsContent value="aliases" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Email Aliases</h3>
            <Button onClick={() => { setEditingAlias(null); resetAliasForm(); setIsAliasDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Alias
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {emailAliases.map((alias) => (
              <Card key={alias.id} className={cn(!alias.isActive && 'opacity-60')}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-orange-50 text-orange-600">
                        <Send className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{alias.alias}</h4>
                        <p className="text-xs text-muted-foreground">
                          → {alias.targetEmail}
                        </p>
                        {alias.description && (
                          <p className="text-xs text-muted-foreground mt-1">{alias.description}</p>
                        )}
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openEditAlias(alias)}>
                          <Edit className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDeleteAlias(alias.id)} className="text-red-600">
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Email Rotation */}
        <TabsContent value="rotation" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold">Email Rotation Configuration</h3>
              <p className="text-sm text-muted-foreground">
                Distribute high-volume sends across multiple mailboxes to prevent flagging
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleResetMailboxCounts}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset Counts
              </Button>
              <Button onClick={() => { setEditingRotation(null); resetRotationForm(); setIsRotationDialogOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" />
                Add Config
              </Button>
            </div>
          </div>

          {/* Rotation Pool Summary */}
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-5">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-blue-100 text-blue-600">
                  <RotateCw className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-blue-900">Rotation Pool Status</h4>
                  <p className="text-sm text-blue-700">
                    {getRotationPoolMailboxes().length} mailboxes in rotation pool
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-900">
                    {getRotationPoolMailboxes().reduce((sum, m) => sum + (m.dailyLimit - (m.sentToday || 0)), 0).toLocaleString()}
                  </p>
                  <p className="text-xs text-blue-600">Total Daily Capacity Remaining</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rotation Configs */}
          <div className="space-y-4">
            {emailRotationConfigs.map((config) => (
              <Card key={config.id} className={cn(!config.enabled && 'opacity-60')}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-green-50 text-green-600">
                        <Settings className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{config.name}</h4>
                          {config.enabled ? (
                            <Badge className="bg-green-100 text-green-700">Active</Badge>
                          ) : (
                            <Badge variant="outline">Disabled</Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{config.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={config.enabled}
                        onCheckedChange={() => handleToggleRotation(config.id)}
                      />
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEditRotation(config)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDeleteRotation(config.id)} className="text-red-600">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Rotation Threshold</p>
                      <p className="font-semibold">{config.rotationThreshold.toLocaleString()} emails</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Strategy</p>
                      <p className="font-semibold capitalize">{config.rotationStrategy.replace('_', ' ')}</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Batch Size</p>
                      <p className="font-semibold">{config.batchSize.toLocaleString()}</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-1">Mailboxes</p>
                      <p className="font-semibold">{config.mailboxIds.length}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Cooldown:</span>
                      <span>{config.cooldownMinutes} min</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Pause on bounce &gt;</span>
                      <span>{config.bounceRateThreshold}%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Max/hour:</span>
                      <span>{config.maxEmailsPerMailboxPerHour.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {emailRotationConfigs.length === 0 && (
            <Card className="p-12 text-center">
              <RotateCw className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No rotation configurations</h3>
              <p className="text-muted-foreground mb-4">
                Add a rotation configuration to distribute high-volume sends across multiple mailboxes
              </p>
              <Button onClick={() => { setEditingRotation(null); resetRotationForm(); setIsRotationDialogOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" />
                Add Configuration
              </Button>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* SMTP Dialog */}
      <Dialog open={isSmtpDialogOpen} onOpenChange={setIsSmtpDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingSmtp ? 'Edit SMTP Configuration' : 'Add SMTP Configuration'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input value={smtpForm.name} onChange={(e) => setSmtpForm({ ...smtpForm, name: e.target.value })} />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-2">
                <Label>Host</Label>
                <Input value={smtpForm.host} onChange={(e) => setSmtpForm({ ...smtpForm, host: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Port</Label>
                <Input type="number" value={smtpForm.port} onChange={(e) => setSmtpForm({ ...smtpForm, port: parseInt(e.target.value) })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input value={smtpForm.username} onChange={(e) => setSmtpForm({ ...smtpForm, username: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <div className="relative">
                  <Input 
                    type={showPassword ? 'text' : 'password'} 
                    value={smtpForm.password} 
                    onChange={(e) => setSmtpForm({ ...smtpForm, password: e.target.value })} 
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Encryption</Label>
                <Select value={smtpForm.encryption} onValueChange={(v) => setSmtpForm({ ...smtpForm, encryption: v as any })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="tls">TLS</SelectItem>
                    <SelectItem value="ssl">SSL</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>From Email</Label>
                <Input value={smtpForm.fromEmail} onChange={(e) => setSmtpForm({ ...smtpForm, fromEmail: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>From Name</Label>
              <Input value={smtpForm.fromName} onChange={(e) => setSmtpForm({ ...smtpForm, fromName: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSmtpDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveSmtp} className="bg-[#062A78]">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mailbox Dialog */}
      <Dialog open={isMailboxDialogOpen} onOpenChange={setIsMailboxDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingMailbox ? 'Edit Mailbox' : 'Add Mailbox'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input value={mailboxForm.email} onChange={(e) => setMailboxForm({ ...mailboxForm, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Display Name</Label>
              <Input value={mailboxForm.name} onChange={(e) => setMailboxForm({ ...mailboxForm, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Department</Label>
              <Input value={mailboxForm.department} onChange={(e) => setMailboxForm({ ...mailboxForm, department: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>SMTP Configuration</Label>
              <Select value={mailboxForm.smtpConfigId} onValueChange={(v) => setMailboxForm({ ...mailboxForm, smtpConfigId: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {smtpConfigs.map((config) => (
                    <SelectItem key={config.id} value={config.id}>{config.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Daily Send Limit</Label>
              <Input type="number" value={mailboxForm.dailyLimit} onChange={(e) => setMailboxForm({ ...mailboxForm, dailyLimit: parseInt(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between pt-2">
              <div className="space-y-0.5">
                <Label>Include in Rotation Pool</Label>
                <p className="text-xs text-muted-foreground">Use this mailbox in email rotation</p>
              </div>
              <Switch 
                checked={mailboxForm.inRotationPool} 
                onCheckedChange={(checked) => setMailboxForm({ ...mailboxForm, inRotationPool: checked })} 
              />
            </div>
            {mailboxForm.inRotationPool && (
              <div className="space-y-2">
                <Label>Rotation Priority (lower = higher priority)</Label>
                <Input 
                  type="number" 
                  min={1} 
                  max={100}
                  value={mailboxForm.rotationPriority} 
                  onChange={(e) => setMailboxForm({ ...mailboxForm, rotationPriority: parseInt(e.target.value) || 1 })} 
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsMailboxDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveMailbox} className="bg-[#062A78]">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Alias Dialog */}
      <Dialog open={isAliasDialogOpen} onOpenChange={setIsAliasDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingAlias ? 'Edit Email Alias' : 'Add Email Alias'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Alias Email</Label>
              <Input value={aliasForm.alias} onChange={(e) => setAliasForm({ ...aliasForm, alias: e.target.value })} placeholder="e.g., info@company.com" />
            </div>
            <div className="space-y-2">
              <Label>Target Email</Label>
              <Input value={aliasForm.targetEmail} onChange={(e) => setAliasForm({ ...aliasForm, targetEmail: e.target.value })} placeholder="e.g., admin@company.com" />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input value={aliasForm.description} onChange={(e) => setAliasForm({ ...aliasForm, description: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAliasDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveAlias} className="bg-[#062A78]">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rotation Config Dialog */}
      <Dialog open={isRotationDialogOpen} onOpenChange={setIsRotationDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingRotation ? 'Edit Rotation Configuration' : 'Add Rotation Configuration'}</DialogTitle>
            <DialogDescription>
              Configure how emails are rotated across mailboxes for high-volume sends
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Basic Settings */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Basic Settings</h4>
              <div className="space-y-2">
                <Label>Name</Label>
                <Input 
                  value={rotationForm.name} 
                  onChange={(e) => setRotationForm({ ...rotationForm, name: e.target.value })} 
                  placeholder="e.g., High Volume Journey Rotation"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input 
                  value={rotationForm.description} 
                  onChange={(e) => setRotationForm({ ...rotationForm, description: e.target.value })} 
                  placeholder="Description of this rotation configuration"
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enabled</Label>
                  <p className="text-xs text-muted-foreground">Enable this rotation configuration</p>
                </div>
                <Switch 
                  checked={rotationForm.enabled} 
                  onCheckedChange={(checked) => setRotationForm({ ...rotationForm, enabled: checked })} 
                />
              </div>
            </div>

            <Separator />

            {/* Rotation Settings */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Rotation Settings</h4>
              <div className="space-y-2">
                <Label>Rotation Threshold (emails)</Label>
                <p className="text-xs text-muted-foreground">Start rotating when estimated emails exceed this number</p>
                <Input 
                  type="number" 
                  value={rotationForm.rotationThreshold} 
                  onChange={(e) => setRotationForm({ ...rotationForm, rotationThreshold: parseInt(e.target.value) || 10000 })} 
                />
              </div>
              <div className="space-y-2">
                <Label>Rotation Strategy</Label>
                <Select 
                  value={rotationForm.rotationStrategy} 
                  onValueChange={(v) => setRotationForm({ ...rotationForm, rotationStrategy: v as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="round_robin">Round Robin (cycle through mailboxes)</SelectItem>
                    <SelectItem value="least_used">Least Used (lowest send count)</SelectItem>
                    <SelectItem value="priority_based">Priority Based (by priority setting)</SelectItem>
                    <SelectItem value="random">Random (random selection)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Batch Size: {rotationForm.batchSize.toLocaleString()} emails</Label>
                <p className="text-xs text-muted-foreground">Number of emails to send before switching mailboxes</p>
                <Slider 
                  value={[rotationForm.batchSize]} 
                  onValueChange={([v]) => setRotationForm({ ...rotationForm, batchSize: v })} 
                  min={100} 
                  max={5000} 
                  step={100} 
                />
              </div>
              <div className="space-y-2">
                <Label>Cooldown Between Switches: {rotationForm.cooldownMinutes} minutes</Label>
                <p className="text-xs text-muted-foreground">Wait time before switching to next mailbox</p>
                <Slider 
                  value={[rotationForm.cooldownMinutes]} 
                  onValueChange={([v]) => setRotationForm({ ...rotationForm, cooldownMinutes: v })} 
                  min={0} 
                  max={30} 
                  step={1} 
                />
              </div>
            </div>

            <Separator />

            {/* Mailbox Selection */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Rotation Pool Mailboxes</h4>
              <p className="text-xs text-muted-foreground">Select mailboxes to include in the rotation pool</p>
              <div className="space-y-2 max-h-48 overflow-y-auto border rounded-lg p-3">
                {mailboxes.filter(m => m.isActive).map((mailbox) => (
                  <div key={mailbox.id} className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded">
                    <input
                      type="checkbox"
                      id={`mb-${mailbox.id}`}
                      checked={selectedMailboxIds.includes(mailbox.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedMailboxIds([...selectedMailboxIds, mailbox.id]);
                        } else {
                          setSelectedMailboxIds(selectedMailboxIds.filter(id => id !== mailbox.id));
                        }
                      }}
                      className="w-4 h-4"
                    />
                    <label htmlFor={`mb-${mailbox.id}`} className="flex-1 cursor-pointer">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{mailbox.name}</p>
                          <p className="text-xs text-muted-foreground">{mailbox.email}</p>
                        </div>
                        <div className="text-right text-xs">
                          <p className="text-muted-foreground">Limit: {mailbox.dailyLimit.toLocaleString()}</p>
                          <p className="text-muted-foreground">Sent: {(mailbox.sentToday || 0).toLocaleString()}</p>
                        </div>
                      </div>
                    </label>
                  </div>
                ))}
              </div>
              {selectedMailboxIds.length > 0 && (
                <p className="text-sm text-green-600">
                  <CheckCircle className="w-4 h-4 inline mr-1" />
                  {selectedMailboxIds.length} mailboxes selected
                </p>
              )}
            </div>

            <Separator />

            {/* Limits */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Per-Mailbox Limits</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Max Emails Per Hour</Label>
                  <Input 
                    type="number" 
                    value={rotationForm.maxEmailsPerMailboxPerHour} 
                    onChange={(e) => setRotationForm({ ...rotationForm, maxEmailsPerMailboxPerHour: parseInt(e.target.value) || 2000 })} 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Max Emails Per Day</Label>
                  <Input 
                    type="number" 
                    value={rotationForm.maxEmailsPerMailboxPerDay} 
                    onChange={(e) => setRotationForm({ ...rotationForm, maxEmailsPerMailboxPerDay: parseInt(e.target.value) || 10000 })} 
                  />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Respect Mailbox Limits</Label>
                  <p className="text-xs text-muted-foreground">Don't exceed individual mailbox daily limits</p>
                </div>
                <Switch 
                  checked={rotationForm.respectMailboxLimits} 
                  onCheckedChange={(checked) => setRotationForm({ ...rotationForm, respectMailboxLimits: checked })} 
                />
              </div>
            </div>

            <Separator />

            {/* Safety Settings */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Safety Settings</h4>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Pause on High Bounce Rate</Label>
                  <p className="text-xs text-muted-foreground">Automatically pause if bounce rate exceeds threshold</p>
                </div>
                <Switch 
                  checked={rotationForm.pauseOnHighBounceRate} 
                  onCheckedChange={(checked) => setRotationForm({ ...rotationForm, pauseOnHighBounceRate: checked })} 
                />
              </div>
              {rotationForm.pauseOnHighBounceRate && (
                <div className="space-y-2">
                  <Label>Bounce Rate Threshold: {rotationForm.bounceRateThreshold}%</Label>
                  <Slider 
                    value={[rotationForm.bounceRateThreshold]} 
                    onValueChange={([v]) => setRotationForm({ ...rotationForm, bounceRateThreshold: v })} 
                    min={1} 
                    max={20} 
                    step={0.5} 
                  />
                </div>
              )}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Pause on High Complaint Rate</Label>
                  <p className="text-xs text-muted-foreground">Automatically pause if spam complaint rate exceeds threshold</p>
                </div>
                <Switch 
                  checked={rotationForm.pauseOnHighComplaintRate} 
                  onCheckedChange={(checked) => setRotationForm({ ...rotationForm, pauseOnHighComplaintRate: checked })} 
                />
              </div>
              {rotationForm.pauseOnHighComplaintRate && (
                <div className="space-y-2">
                  <Label>Complaint Rate Threshold: {rotationForm.complaintRateThreshold}%</Label>
                  <Slider 
                    value={[rotationForm.complaintRateThreshold]} 
                    onValueChange={([v]) => setRotationForm({ ...rotationForm, complaintRateThreshold: v })} 
                    min={0.05} 
                    max={1} 
                    step={0.05} 
                  />
                </div>
              )}
            </div>

            <Separator />

            {/* Active Hours */}
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-muted-foreground uppercase">Active Hours</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Time</Label>
                  <Input 
                    type="time" 
                    value={rotationForm.activeHoursStart} 
                    onChange={(e) => setRotationForm({ ...rotationForm, activeHoursStart: e.target.value })} 
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Time</Label>
                  <Input 
                    type="time" 
                    value={rotationForm.activeHoursEnd} 
                    onChange={(e) => setRotationForm({ ...rotationForm, activeHoursEnd: e.target.value })} 
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRotationDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleSaveRotation} 
              className="bg-[#062A78]"
              disabled={!rotationForm.name || selectedMailboxIds.length === 0}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
