import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api, { setTokens, clearTokens, getAccessToken } from '@/lib/api';

export interface AppUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  name: string;
  role: string;
  status: string;
  department?: string;
  jobTitle?: string;
  phone?: string;
  avatarUrl?: string;
  permissions: any;
  isTemporaryPassword: boolean;
  lastLoginAt?: string;
  createdAt: string;
}

interface LoginResult {
  success: boolean;
  user?: AppUser;
  error?: string;
  requiresPasswordChange?: boolean;
}

interface AppState {
  user: AppUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  activeModule: string;
  showPasswordChangeDialog: boolean;
  users: any[];
  journeys: any[];
  rules: any[];
  templates: any[];
  dataSources: any[];
  journeyRuns: any[];
  dashboardStats: any;
  login: (email: string, password: string) => Promise<LoginResult>;
  logout: () => Promise<void>;
  setUser: (user: AppUser | null) => void;
  setActiveModule: (module: string) => void;
  setShowPasswordChangeDialog: (show: boolean) => void;
  changePassword: (userId: string, oldPassword: string, newPassword: string) => Promise<boolean>;
  resetPassword: (email: string) => Promise<boolean>;
  hasPermission: (module: string, action: string) => boolean;
  canAccessModule: (moduleId: string) => boolean;
  refreshCurrentUser: () => Promise<void>;
  fetchUsers: () => Promise<void>;
  addUser: (data: any) => Promise<void>;
  updateUser: (id: string, data: any) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  unlockAccount: (id: string) => Promise<void>;
  fetchJourneys: () => Promise<void>;
  addJourney: (data: any) => Promise<void>;
  updateJourney: (id: string, data: any) => Promise<void>;
  deleteJourney: (id: string) => Promise<void>;
  submitForApproval: (id: string) => Promise<void>;
  approveJourney: (id: string, notes?: string) => Promise<void>;
  rejectJourney: (id: string, reason: string) => Promise<void>;
  fetchRules: () => Promise<void>;
  addRule: (data: any) => Promise<void>;
  updateRule: (id: string, data: any) => Promise<void>;
  deleteRule: (id: string) => Promise<void>;
  validateRule: (id: string) => Promise<void>;
  fetchTemplates: () => Promise<void>;
  addTemplate: (data: any) => Promise<void>;
  updateTemplate: (id: string, data: any) => Promise<void>;
  deleteTemplate: (id: string) => Promise<void>;
  fetchDataSources: () => Promise<void>;
  addDataSource: (data: any) => Promise<void>;
  updateDataSource: (id: string, data: any) => Promise<void>;
  deleteDataSource: (id: string) => Promise<void>;
  testDataSource: (id: string) => Promise<any>;
  fetchJourneyRuns: () => Promise<void>;
  fetchDashboardStats: () => Promise<void>;
}

const MODULE_ACCESS: Record<string, string[]> = {
  super_admin: ['overview','journeys','rules','templates','datasources','runs','admin','users','reports'],
  admin: ['overview','journeys','rules','templates','datasources','runs','admin','users','reports'],
  business_user: ['overview','journeys','templates','reports'],
  dmo_team: ['overview','journeys','rules','datasources','reports'],
  cx_team: ['overview','journeys','templates','reports'],
  control_team: ['overview','journeys','templates','reports','admin'],
  journey_developer: ['overview','journeys','rules','templates','datasources','runs','reports'],
  developer: ['overview','journeys','rules','templates','datasources','runs','reports'],
  comms: ['overview','journeys','templates','reports'],
  compliance: ['overview','journeys','reports'],
  viewer: ['overview','reports'],
};

function normalizeUser(u: any): AppUser {
  const full = u.fullName || `${u.firstName||''} ${u.lastName||''}`.trim();
  return { ...u, fullName: full, name: full };
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null, isAuthenticated: false, isLoading: false,
      activeModule: 'overview', showPasswordChangeDialog: false,
      users: [], journeys: [], rules: [], templates: [],
      dataSources: [], journeyRuns: [], dashboardStats: {},

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const data = await api.auth.login(email, password);
          if (!data.success) { set({ isLoading: false }); return { success: false, error: data.message || 'Login failed' }; }
          const { user, tokens } = data.data;
          if (tokens) setTokens(tokens);
          const norm = normalizeUser(user);
          const requiresPasswordChange = user.isTemporaryPassword || user.status === 'pending_password_change';
          set({ user: norm, isAuthenticated: true, isLoading: false, showPasswordChangeDialog: requiresPasswordChange });
          return { success: true, user: norm, requiresPasswordChange };
        } catch (err: any) { set({ isLoading: false }); return { success: false, error: err.message || 'Login failed' }; }
      },

      logout: async () => {
        await api.auth.logout().catch(() => {});
        clearTokens();
        set({ user: null, isAuthenticated: false, activeModule: 'overview', users: [], journeys: [], rules: [], templates: [], dataSources: [], journeyRuns: [] });
      },

      setUser: (user) => set({ user }),
      setActiveModule: (module) => set({ activeModule: module }),
      setShowPasswordChangeDialog: (show) => set({ showPasswordChangeDialog: show }),

      changePassword: async (_u, oldPassword, newPassword) => {
        try {
          const data = await api.auth.changePassword(oldPassword, newPassword);
          if (data.success) { const me = await api.auth.me(); if (me.data) set({ user: normalizeUser(me.data), showPasswordChangeDialog: false }); return true; }
          return false;
        } catch { return false; }
      },

      resetPassword: async (email) => { try { const d = await api.auth.forgotPassword(email); return d.success; } catch { return false; } },

      refreshCurrentUser: async () => {
        try { if (!getAccessToken()) return; const d = await api.auth.me(); if (d.data) set({ user: normalizeUser(d.data) }); } catch {}
      },

      hasPermission: (module, action) => {
        const { user } = get(); if (!user) return false;
        if (user.role === 'super_admin') return true;
        return user.permissions?.[module]?.[action] === true;
      },

      canAccessModule: (moduleId) => {
        const { user } = get(); if (!user) return false;
        if (user.role === 'super_admin') return true;
        return (MODULE_ACCESS[user.role] || []).includes(moduleId);
      },

      fetchUsers: async () => { try { const r = await api.users.getAll({ limit: 100 }); set({ users: r.data || [] }); } catch {} },
      addUser: async (data) => { const r = await api.users.create(data); if (r.success) set((s) => ({ users: [...s.users, r.data] })); },
      updateUser: async (id, data) => { const r = await api.users.update(id, data); if (r.success) set((s) => ({ users: s.users.map((u) => u.id === id ? r.data : u) })); },
      deleteUser: async (id) => { await api.users.delete(id); set((s) => ({ users: s.users.filter((u) => u.id !== id) })); },
      unlockAccount: async (id) => { await api.users.unlock(id); await get().fetchUsers(); },

      fetchJourneys: async () => { try { const r = await api.journeys.getAll({ limit: 100 }); set({ journeys: r.data || [] }); } catch {} },
      addJourney: async (data) => { const r = await api.journeys.create(data); if (r.success) set((s) => ({ journeys: [...s.journeys, r.data] })); },
      updateJourney: async (id, data) => { const r = await api.journeys.update(id, data); if (r.success) set((s) => ({ journeys: s.journeys.map((j) => j.id === id ? r.data : j) })); },
      deleteJourney: async (id) => { await api.journeys.delete(id); set((s) => ({ journeys: s.journeys.filter((j) => j.id !== id) })); },
      submitForApproval: async (id) => { await api.workflow.submit(id); await get().fetchJourneys(); },
      approveJourney: async (id, notes) => { await api.workflow.approve(id, notes); await get().fetchJourneys(); },
      rejectJourney: async (id, reason) => { await api.workflow.reject(id, reason); await get().fetchJourneys(); },

      fetchRules: async () => { try { const r = await api.rules.getAll({ limit: 100 }); set({ rules: r.data || [] }); } catch {} },
      addRule: async (data) => { const r = await api.rules.create(data); if (r.success) set((s) => ({ rules: [...s.rules, r.data] })); },
      updateRule: async (id, data) => { const r = await api.rules.update(id, data); if (r.success) set((s) => ({ rules: s.rules.map((x) => x.id === id ? r.data : x) })); },
      deleteRule: async (id) => { await api.rules.delete(id); set((s) => ({ rules: s.rules.filter((x) => x.id !== id) })); },
      validateRule: async (id) => { await api.rules.test(id); await get().fetchRules(); },

      fetchTemplates: async () => { try { const r = await api.templates.getAll({ limit: 100 }); set({ templates: r.data || [] }); } catch {} },
      addTemplate: async (data) => { const r = await api.templates.create(data); if (r.success) set((s) => ({ templates: [...s.templates, r.data] })); },
      updateTemplate: async (id, data) => { const r = await api.templates.update(id, data); if (r.success) set((s) => ({ templates: s.templates.map((t) => t.id === id ? r.data : t) })); },
      deleteTemplate: async (id) => { await api.templates.delete(id); set((s) => ({ templates: s.templates.filter((t) => t.id !== id) })); },

      fetchDataSources: async () => { try { const r = await api.dataSources.getAll({ limit: 100 }); set({ dataSources: r.data || [] }); } catch {} },
      addDataSource: async (data) => { const r = await api.dataSources.create(data); if (r.success) set((s) => ({ dataSources: [...s.dataSources, r.data] })); },
      updateDataSource: async (id, data) => { const r = await api.dataSources.update(id, data); if (r.success) set((s) => ({ dataSources: s.dataSources.map((d) => d.id === id ? r.data : d) })); },
      deleteDataSource: async (id) => { await api.dataSources.delete(id); set((s) => ({ dataSources: s.dataSources.filter((d) => d.id !== id) })); },
      testDataSource: async (id) => { const r = await api.dataSources.test(id); return r.data; },

      fetchJourneyRuns: async () => {
        try {
          const jr = await api.journeys.getAll({ limit: 50 }); const js = jr.data || []; const runs: any[] = [];
          for (const j of js.slice(0, 20)) { try { const rr = await api.journeys.getRuns(j.id); if (rr.data) runs.push(...rr.data.map((r: any) => ({ ...r, journeyName: j.name }))); } catch {} }
          set({ journeyRuns: runs });
        } catch {}
      },

      fetchDashboardStats: async () => {
        try { const r = await api.reports.getOverview(); set({ dashboardStats: r.data || {} }); } catch {}
      },
    }),
    {
      name: 'journey-platform-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated, activeModule: state.activeModule }),
    }
  )
);

export default useAppStore;
