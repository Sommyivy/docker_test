import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  User,
  Journey,
  Rule,
  Template,
  DataSource,
  JourneyRun,
  SMTPConfig,
  Mailbox,
  EmailAlias,
  ActivityLog,
  DashboardStats,
  EmailRotationConfig,
  LoginAttempt,
  WorkflowStage,
  WorkflowAction,
  WorkflowComment,
  AuditEntry,
} from '@/types';
import {
  users as initialUsers,
  journeys as initialJourneys,
  rules as initialRules,
  templates as initialTemplates,
  dataSources as initialDataSources,
  journeyRuns as initialJourneyRuns,
  smtpConfigs as initialSmtpConfigs,
  mailboxes as initialMailboxes,
  emailAliases as initialEmailAliases,
  activityLogs as initialActivityLogs,
  dashboardStats as initialDashboardStats,
  emailRotationConfigs as initialRotationConfigs,
  userCredentials,
  moduleAccessMatrix,
  workflowStages,
  stageTransitions,
} from '@/data/mockData';

// Login result type
interface LoginResult {
  success: boolean;
  user?: User;
  error?: string;
  requiresPasswordChange?: boolean;
  accountLocked?: boolean;
  lockoutMinutes?: number;
}

// Auth State
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loginAttempts: LoginAttempt[];
  login: (email: string, password: string) => Promise<LoginResult>;
  logout: () => void;
  setUser: (user: User | null) => void;
  changePassword: (userId: string, oldPassword: string, newPassword: string) => Promise<boolean>;
  resetPassword: (email: string) => Promise<boolean>;
  unlockAccount: (userId: string) => void;
  hasPermission: (permission: string) => boolean;
  canAccessModule: (moduleId: string) => boolean;
}

// App State
interface AppState extends AuthState {
  // Data
  users: User[];
  journeys: Journey[];
  rules: Rule[];
  templates: Template[];
  dataSources: DataSource[];
  journeyRuns: JourneyRun[];
  smtpConfigs: SMTPConfig[];
  mailboxes: Mailbox[];
  emailAliases: EmailAlias[];
  activityLogs: ActivityLog[];
  dashboardStats: DashboardStats;
  emailRotationConfigs: EmailRotationConfig[];

  // UI State
  activeModule: string;
  setActiveModule: (module: string) => void;
  showPasswordChangeDialog: boolean;
  setShowPasswordChangeDialog: (show: boolean) => void;

  // User CRUD
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Journey CRUD
  addJourney: (journey: Omit<Journey, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateJourney: (id: string, updates: Partial<Journey>) => void;
  deleteJourney: (id: string) => void;
  
  // Legacy approval actions
  submitForApproval: (id: string) => void;
  approveJourney: (id: string, notes?: string) => void;
  rejectJourney: (id: string, notes?: string) => void;
  scheduleJourney: (id: string, scheduledAt: string) => void;
  startJourney: (id: string) => void;
  pauseJourney: (id: string) => void;
  cancelJourney: (id: string) => void;
  
  // Workflow Actions
  transitionJourney: (id: string, action: WorkflowAction, comment?: string) => void;
  addJourneyComment: (id: string, comment: string, action: WorkflowAction) => void;
  getJourneyWorkflowStage: (journey: Journey) => typeof workflowStages[0];
  canPerformWorkflowAction: (journey: Journey, action: WorkflowAction) => boolean;
  getAvailableWorkflowActions: (journey: Journey) => WorkflowAction[];

  // Rule CRUD
  addRule: (rule: Omit<Rule, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateRule: (id: string, updates: Partial<Rule>) => void;
  deleteRule: (id: string) => void;
  validateRule: (id: string, userId: string) => void;

  // Template CRUD
  addTemplate: (template: Omit<Template, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTemplate: (id: string, updates: Partial<Template>) => void;
  deleteTemplate: (id: string) => void;

  // DataSource CRUD
  addDataSource: (dataSource: Omit<DataSource, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateDataSource: (id: string, updates: Partial<DataSource>) => void;
  deleteDataSource: (id: string) => void;
  testDataSource: (id: string) => void;
  toggleDataSource: (id: string) => void;

  // SMTP Config CRUD
  addSmtpConfig: (config: Omit<SMTPConfig, 'id'>) => void;
  updateSmtpConfig: (id: string, updates: Partial<SMTPConfig>) => void;
  deleteSmtpConfig: (id: string) => void;
  testSmtpConfig: (id: string) => void;
  setDefaultSmtpConfig: (id: string) => void;

  // Mailbox CRUD
  addMailbox: (mailbox: Omit<Mailbox, 'id' | 'createdAt'>) => void;
  updateMailbox: (id: string, updates: Partial<Mailbox>) => void;
  deleteMailbox: (id: string) => void;

  // Email Alias CRUD
  addEmailAlias: (alias: Omit<EmailAlias, 'id' | 'createdAt'>) => void;
  updateEmailAlias: (id: string, updates: Partial<EmailAlias>) => void;
  deleteEmailAlias: (id: string) => void;

  // Email Rotation CRUD
  addRotationConfig: (config: Omit<EmailRotationConfig, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateRotationConfig: (id: string, updates: Partial<EmailRotationConfig>) => void;
  deleteRotationConfig: (id: string) => void;
  toggleRotationConfig: (id: string) => void;

  // Email Rotation Logic
  getNextMailboxForSending: (estimatedEmailCount: number) => Mailbox | null;
  getRotationPoolMailboxes: () => Mailbox[];
  incrementMailboxSentCount: (mailboxId: string, count: number) => void;
  resetMailboxDailyCounts: () => void;

  // Activity Log
  addActivityLog: (log: Omit<ActivityLog, 'id' | 'timestamp'>) => void;

  // Stats
  updateDashboardStats: (updates: Partial<DashboardStats>) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial Auth State
      user: null,
      isAuthenticated: false,
      loginAttempts: [],
      showPasswordChangeDialog: false,

      // Initial Data
      users: initialUsers,
      journeys: initialJourneys,
      rules: initialRules,
      templates: initialTemplates,
      dataSources: initialDataSources,
      journeyRuns: initialJourneyRuns,
      smtpConfigs: initialSmtpConfigs,
      mailboxes: initialMailboxes,
      emailAliases: initialEmailAliases,
      activityLogs: initialActivityLogs,
      dashboardStats: initialDashboardStats,
      emailRotationConfigs: initialRotationConfigs,

      // Initial UI State
      activeModule: 'overview',

      // Auth Actions
      login: async (email: string, password: string) => {
        await new Promise(resolve => setTimeout(resolve, 800));
        
        const now = new Date().toISOString();
        const { users } = get();
        
        const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        
        const attempt: LoginAttempt = {
          email,
          timestamp: now,
          success: false,
          ipAddress: '127.0.0.1',
        };
        
        if (!user) {
          set(state => ({ 
            loginAttempts: [attempt, ...state.loginAttempts].slice(0, 50) 
          }));
          return { success: false, error: 'Invalid email or password' };
        }
        
        if (!user.isActive) {
          set(state => ({ 
            loginAttempts: [{ ...attempt, errorMessage: 'Account inactive' }, ...state.loginAttempts].slice(0, 50) 
          }));
          return { 
            success: false, 
            error: 'Your account has been deactivated. Please contact your administrator.' 
          };
        }
        
        if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
          const lockoutMinutes = Math.ceil((new Date(user.lockedUntil).getTime() - new Date().getTime()) / 60000);
          set(state => ({ 
            loginAttempts: [{ ...attempt, errorMessage: 'Account locked' }, ...state.loginAttempts].slice(0, 50) 
          }));
          return { 
            success: false, 
            accountLocked: true,
            lockoutMinutes,
            error: `Account locked due to too many failed attempts. Please try again in ${lockoutMinutes} minutes.` 
          };
        }
        
        const credentials = userCredentials[user.email.toLowerCase()];
        if (!credentials || credentials.password !== password) {
          const updatedFailedAttempts = (user.failedLoginAttempts || 0) + 1;
          const maxAttempts = 5;
          
          set(state => ({
            users: state.users.map(u => 
              u.id === user.id 
                ? { 
                    ...u, 
                    failedLoginAttempts: updatedFailedAttempts,
                    lockedUntil: updatedFailedAttempts >= maxAttempts 
                      ? new Date(Date.now() + 30 * 60000).toISOString() 
                      : u.lockedUntil
                  } 
                : u
            ),
            loginAttempts: [{ ...attempt, errorMessage: 'Invalid password' }, ...state.loginAttempts].slice(0, 50)
          }));
          
          const remainingAttempts = maxAttempts - updatedFailedAttempts;
          if (remainingAttempts <= 0) {
            return { 
              success: false, 
              accountLocked: true,
              lockoutMinutes: 30,
              error: 'Account locked due to too many failed attempts. Please try again in 30 minutes.' 
            };
          }
          
          return { 
            success: false, 
            error: `Invalid email or password. ${remainingAttempts} attempts remaining.` 
          };
        }
        
        if (user.isTemporaryPassword && user.passwordExpiresAt && new Date(user.passwordExpiresAt) < new Date()) {
          set(state => ({ 
            loginAttempts: [{ ...attempt, errorMessage: 'Temporary password expired' }, ...state.loginAttempts].slice(0, 50) 
          }));
          return { 
            success: false, 
            error: 'Your temporary password has expired. Please contact your administrator to reset your password.' 
          };
        }
        
        const updatedUser = { 
          ...user, 
          lastLogin: now,
          failedLoginAttempts: 0,
          lockedUntil: undefined
        };
        
        set(state => ({ 
          user: updatedUser,
          isAuthenticated: true,
          showPasswordChangeDialog: user.isTemporaryPassword,
          users: state.users.map(u => u.id === user.id ? updatedUser : u),
          loginAttempts: [{ ...attempt, success: true }, ...state.loginAttempts].slice(0, 50)
        }));
        
        get().addActivityLog({
          userId: user.id,
          userName: user.name,
          action: 'User logged in',
          entityType: 'user',
          entityId: user.id,
          entityName: user.name,
        });
        
        return { 
          success: true, 
          user: updatedUser,
          requiresPasswordChange: user.isTemporaryPassword 
        };
      },

      logout: () => {
        const user = get().user;
        if (user) {
          get().addActivityLog({
            userId: user.id,
            userName: user.name,
            action: 'User logged out',
            entityType: 'user',
            entityId: user.id,
            entityName: user.name,
          });
        }
        set({ 
          user: null, 
          isAuthenticated: false,
          showPasswordChangeDialog: false,
          activeModule: 'overview'
        });
      },

      setUser: (user) => set({ user, isAuthenticated: !!user }),

      setShowPasswordChangeDialog: (show) => set({ showPasswordChangeDialog: show }),

      changePassword: async (userId: string, oldPassword: string, newPassword: string) => {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const { users, user: currentUser } = get();
        const user = users.find(u => u.id === userId);
        
        if (!user) return false;
        
        const credentials = userCredentials[user.email.toLowerCase()];
        if (!credentials || credentials.password !== oldPassword) {
          return false;
        }
        
        const now = new Date().toISOString();
        
        set(state => ({
          users: state.users.map(u => 
            u.id === userId 
              ? { 
                  ...u, 
                  isTemporaryPassword: false,
                  passwordChangedAt: now,
                  passwordExpiresAt: undefined,
                  failedLoginAttempts: 0
                } 
              : u
          ),
          user: currentUser?.id === userId 
            ? { 
                ...currentUser, 
                isTemporaryPassword: false,
                passwordChangedAt: now,
                passwordExpiresAt: undefined 
              } 
            : currentUser,
          showPasswordChangeDialog: false
        }));
        
        userCredentials[user.email.toLowerCase()] = {
          password: newPassword,
          isTemporary: false
        };
        
        get().addActivityLog({
          userId: user.id,
          userName: user.name,
          action: 'Password changed',
          entityType: 'user',
          entityId: user.id,
          entityName: user.name,
        });
        
        return true;
      },

      resetPassword: async (email: string) => {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const { users } = get();
        const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        
        if (!user) return false;
        
        const tempPassword = 'Temp' + Math.random().toString(36).substring(2, 8) + '!';
        
        const now = new Date();
        const expiryDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        
        set(state => ({
          users: state.users.map(u => 
            u.id === user.id 
              ? { 
                  ...u, 
                  isTemporaryPassword: true,
                  passwordExpiresAt: expiryDate.toISOString(),
                  failedLoginAttempts: 0,
                  lockedUntil: undefined
                } 
              : u
          )
        }));
        
        userCredentials[user.email.toLowerCase()] = {
          password: tempPassword,
          isTemporary: true
        };
        
        get().addActivityLog({
          userId: user.id,
          userName: user.name,
          action: 'Password reset initiated',
          entityType: 'user',
          entityId: user.id,
          entityName: user.name,
        });
        
        console.log(`Temporary password for ${email}: ${tempPassword}`);
        
        return true;
      },

      unlockAccount: (userId: string) => {
        set(state => ({
          users: state.users.map(u => 
            u.id === userId 
              ? { ...u, failedLoginAttempts: 0, lockedUntil: undefined } 
              : u
          )
        }));
      },

      hasPermission: (permission: string) => {
        const { user } = get();
        if (!user) return false;
        return user.permissions.includes(permission as any);
      },

      canAccessModule: (moduleId: string) => {
        const { user } = get();
        if (!user) return false;
        
        if (user.role === 'super_admin') return true;
        
        const allowedModules = moduleAccessMatrix[user.role] || [];
        return allowedModules.includes(moduleId);
      },

      setActiveModule: (module) => set({ activeModule: module }),

      // User CRUD
      addUser: (userData) => {
        const now = new Date().toISOString();
        const newUser: User = {
          ...userData,
          id: `u${Date.now()}`,
          createdAt: now,
        };
        set(state => ({ users: [...state.users, newUser] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created user',
          entityType: 'user',
          entityId: newUser.id,
          entityName: newUser.name,
        });
      },

      updateUser: (id, updates) => {
        set(state => ({
          users: state.users.map(u => u.id === id ? { ...u, ...updates } : u)
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated user',
          entityType: 'user',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteUser: (id) => {
        const user = get().users.find(u => u.id === id);
        set(state => ({ users: state.users.filter(u => u.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted user',
          entityType: 'user',
          entityId: id,
          entityName: user?.name || id,
        });
      },

      // Journey CRUD
      addJourney: (journeyData) => {
        const now = new Date().toISOString();
        const newJourney: Journey = {
          ...journeyData,
          id: `j${Date.now()}`,
          createdAt: now,
          updatedAt: now,
        };
        set(state => ({ journeys: [...state.journeys, newJourney] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created journey',
          entityType: 'journey',
          entityId: newJourney.id,
          entityName: newJourney.name,
        });
      },

      updateJourney: (id, updates) => {
        set(state => ({
          journeys: state.journeys.map(j => 
            j.id === id ? { ...j, ...updates, updatedAt: new Date().toISOString() } : j
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated journey',
          entityType: 'journey',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteJourney: (id) => {
        const journey = get().journeys.find(j => j.id === id);
        set(state => ({ journeys: state.journeys.filter(j => j.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted journey',
          entityType: 'journey',
          entityId: id,
          entityName: journey?.name || id,
        });
      },

      submitForApproval: (id) => {
        get().updateJourney(id, { 
          status: 'pending_approval', 
          approvalStatus: 'pending_dev' 
        });
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Submitted journey for approval',
          entityType: 'journey',
          entityId: id,
          entityName: get().journeys.find(j => j.id === id)?.name || id,
        });
      },

      approveJourney: (id, _notes) => {
        const journey = get().journeys.find(j => j.id === id);
        let newApprovalStatus = journey?.approvalStatus;
        
        if (journey?.approvalStatus === 'pending_dev') {
          newApprovalStatus = 'pending_comms';
        } else if (journey?.approvalStatus === 'pending_comms') {
          newApprovalStatus = 'pending_compliance';
        } else if (journey?.approvalStatus === 'pending_compliance') {
          newApprovalStatus = 'approved';
        }

        get().updateJourney(id, { approvalStatus: newApprovalStatus });
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Approved journey',
          entityType: 'journey',
          entityId: id,
          entityName: journey?.name || id,
        });
      },

      rejectJourney: (id, _notes) => {
        const journey = get().journeys.find(j => j.id === id);
        get().updateJourney(id, { 
          status: 'draft', 
          approvalStatus: 'rejected' 
        });
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Rejected journey',
          entityType: 'journey',
          entityId: id,
          entityName: journey?.name || id,
        });
      },

      scheduleJourney: (id, scheduledAt) => {
        get().updateJourney(id, { 
          status: 'scheduled', 
          scheduledAt,
          approvalStatus: 'approved'
        });
      },

      startJourney: (id) => {
        get().updateJourney(id, { 
          status: 'running', 
          startedAt: new Date().toISOString() 
        });
      },

      pauseJourney: (id) => {
        get().updateJourney(id, { status: 'paused' });
      },

      cancelJourney: (id) => {
        get().updateJourney(id, { status: 'cancelled' });
      },

      // Workflow Actions
      transitionJourney: (id: string, action: WorkflowAction, comment?: string) => {
        const { user, journeys } = get();
        const journey = journeys.find(j => j.id === id);
        if (!journey || !user) return;

        const currentStage = journey.workflowStage;
        const transitions = stageTransitions[currentStage];
        
        let nextStage: WorkflowStage | undefined;
        
        // Determine next stage based on action
        switch (action) {
          case 'submit':
            if (currentStage === 'rejected') {
              nextStage = 'intake';
            } else if (transitions?.next && transitions.next.length > 0) {
              nextStage = transitions.next[0];
            }
            break;
          case 'approve':
            if (transitions?.next && transitions.next.length > 0) {
              nextStage = transitions.next[0];
            }
            break;
          case 'reject':
            nextStage = 'rejected';
            break;
          case 'request_changes':
            // Go back to previous stage
            if (transitions?.prev) {
              nextStage = transitions.prev;
            }
            break;
          case 'pause':
            if (currentStage === 'live') {
              nextStage = 'paused';
            }
            break;
          case 'resume':
            if (currentStage === 'paused') {
              nextStage = 'live';
            }
            break;
          case 'archive':
            nextStage = 'archived';
            break;
        }

        if (!nextStage) return;

        const now = new Date().toISOString();

        // Create audit entry
        const auditEntry: AuditEntry = {
          id: `ae${Date.now()}`,
          timestamp: now,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          action,
          fromStage: currentStage,
          toStage: nextStage,
          comment,
        };

        // Create comment if provided
        let newComment: WorkflowComment | undefined;
        if (comment) {
          newComment = {
            id: `wc${Date.now()}`,
            stage: currentStage,
            userId: user.id,
            userName: user.name,
            userRole: user.role,
            comment,
            timestamp: now,
            action,
          };
        }

        // Update journey
        set(state => ({
          journeys: state.journeys.map(j => 
            j.id === id 
              ? { 
                  ...j, 
                  workflowStage: nextStage!,
                  status: nextStage === 'live' ? 'running' : 
                          nextStage === 'paused' ? 'paused' : 
                          nextStage === 'approved' ? 'approved' : 
                          nextStage === 'rejected' ? 'draft' : j.status,
                  updatedAt: now,
                  stageEnteredAt: now,
                  auditHistory: [...j.auditHistory, auditEntry],
                  comments: newComment ? [...j.comments, newComment] : j.comments,
                } 
              : j
          )
        }));

        get().addActivityLog({
          userId: user.id,
          userName: user.name,
          action: `Journey ${action}: ${currentStage} → ${nextStage}`,
          entityType: 'journey',
          entityId: id,
          entityName: journey.name,
        });
      },

      addJourneyComment: (id: string, commentText: string, action: WorkflowAction) => {
        const { user, journeys } = get();
        const journey = journeys.find(j => j.id === id);
        if (!journey || !user) return;

        const now = new Date().toISOString();
        
        const newComment: WorkflowComment = {
          id: `wc${Date.now()}`,
          stage: journey.workflowStage,
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          comment: commentText,
          timestamp: now,
          action,
        };

        set(state => ({
          journeys: state.journeys.map(j => 
            j.id === id 
              ? { ...j, comments: [...j.comments, newComment] }
              : j
          )
        }));
      },

      getJourneyWorkflowStage: (journey: Journey) => {
        return workflowStages.find(s => s.stage === journey.workflowStage) || workflowStages[0];
      },

      canPerformWorkflowAction: (journey: Journey, action: WorkflowAction) => {
        const { user } = get();
        if (!user) return false;

        const stageConfig = workflowStages.find(s => s.stage === journey.workflowStage);
        if (!stageConfig) return false;

        // Check if user's role matches the stage role
        const roleMatches = 
          user.role === 'super_admin' ||
          (stageConfig.role === 'business_user' && (user.role === 'admin' || user.department === 'Marketing')) ||
          (stageConfig.role === 'dmo_team' && user.role === 'developer') ||
          (stageConfig.role === 'cx_team' && user.role === 'comms') ||
          (stageConfig.role === 'control_team' && user.role === 'compliance');

        // Check if action is allowed in this stage
        const actionAllowed = stageConfig.actions.includes(action);

        return roleMatches && actionAllowed;
      },

      getAvailableWorkflowActions: (journey: Journey) => {
        const { canPerformWorkflowAction } = get();
        const stageConfig = workflowStages.find(s => s.stage === journey.workflowStage);
        if (!stageConfig) return [];

        return stageConfig.actions.filter(action => canPerformWorkflowAction(journey, action));
      },

      // Rule CRUD
      addRule: (ruleData) => {
        const now = new Date().toISOString();
        const newRule: Rule = {
          ...ruleData,
          id: `r${Date.now()}`,
          createdAt: now,
          updatedAt: now,
        };
        set(state => ({ rules: [...state.rules, newRule] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created rule',
          entityType: 'rule',
          entityId: newRule.id,
          entityName: newRule.name,
        });
      },

      updateRule: (id, updates) => {
        set(state => ({
          rules: state.rules.map(r => 
            r.id === id ? { ...r, ...updates, updatedAt: new Date().toISOString() } : r
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated rule',
          entityType: 'rule',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteRule: (id) => {
        const rule = get().rules.find(r => r.id === id);
        set(state => ({ rules: state.rules.filter(r => r.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted rule',
          entityType: 'rule',
          entityId: id,
          entityName: rule?.name || id,
        });
      },

      validateRule: (id, userId) => {
        const now = new Date().toISOString();
        set(state => ({
          rules: state.rules.map(r => 
            r.id === id ? { 
              ...r, 
              validatedAt: now, 
              validatedBy: userId,
              status: 'active',
              updatedAt: now
            } : r
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Validated rule',
          entityType: 'rule',
          entityId: id,
          entityName: get().rules.find(r => r.id === id)?.name || id,
        });
      },

      // Template CRUD
      addTemplate: (templateData) => {
        const now = new Date().toISOString();
        const newTemplate: Template = {
          ...templateData,
          id: `t${Date.now()}`,
          createdAt: now,
          updatedAt: now,
        };
        set(state => ({ templates: [...state.templates, newTemplate] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created template',
          entityType: 'template',
          entityId: newTemplate.id,
          entityName: newTemplate.name,
        });
      },

      updateTemplate: (id, updates) => {
        set(state => ({
          templates: state.templates.map(t => 
            t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated template',
          entityType: 'template',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteTemplate: (id) => {
        const template = get().templates.find(t => t.id === id);
        set(state => ({ templates: state.templates.filter(t => t.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted template',
          entityType: 'template',
          entityId: id,
          entityName: template?.name || id,
        });
      },

      // DataSource CRUD
      addDataSource: (dataSourceData) => {
        const now = new Date().toISOString();
        const newDataSource: DataSource = {
          ...dataSourceData,
          id: `ds${Date.now()}`,
          createdAt: now,
          updatedAt: now,
        };
        set(state => ({ dataSources: [...state.dataSources, newDataSource] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created data source',
          entityType: 'datasource',
          entityId: newDataSource.id,
          entityName: newDataSource.name,
        });
      },

      updateDataSource: (id, updates) => {
        set(state => ({
          dataSources: state.dataSources.map(ds => 
            ds.id === id ? { ...ds, ...updates, updatedAt: new Date().toISOString() } : ds
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated data source',
          entityType: 'datasource',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteDataSource: (id) => {
        const ds = get().dataSources.find(d => d.id === id);
        set(state => ({ dataSources: state.dataSources.filter(d => d.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted data source',
          entityType: 'datasource',
          entityId: id,
          entityName: ds?.name || id,
        });
      },

      testDataSource: (id) => {
        set(state => ({
          dataSources: state.dataSources.map(ds => 
            ds.id === id ? { 
              ...ds, 
              status: 'testing',
              updatedAt: new Date().toISOString()
            } : ds
          )
        }));
        
        setTimeout(() => {
          set(state => ({
            dataSources: state.dataSources.map(ds => 
              ds.id === id ? { 
                ...ds, 
                status: Math.random() > 0.2 ? 'connected' : 'error',
                lastTestedAt: new Date().toISOString(),
                lastError: Math.random() > 0.2 ? undefined : 'Connection timeout',
                updatedAt: new Date().toISOString()
              } : ds
            )
          }));
        }, 2000);

        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Tested data source connection',
          entityType: 'datasource',
          entityId: id,
          entityName: get().dataSources.find(d => d.id === id)?.name || id,
        });
      },

      toggleDataSource: (id) => {
        const ds = get().dataSources.find(d => d.id === id);
        if (ds) {
          get().updateDataSource(id, { isActive: !ds.isActive });
        }
      },

      // SMTP Config CRUD
      addSmtpConfig: (configData) => {
        const newConfig: SMTPConfig = {
          ...configData,
          id: `smtp${Date.now()}`,
        };
        set(state => ({ smtpConfigs: [...state.smtpConfigs, newConfig] }));
      },

      updateSmtpConfig: (id, updates) => {
        set(state => ({
          smtpConfigs: state.smtpConfigs.map(c => 
            c.id === id ? { ...c, ...updates } : c
          )
        }));
      },

      deleteSmtpConfig: (id) => {
        set(state => ({ smtpConfigs: state.smtpConfigs.filter(c => c.id !== id) }));
      },

      testSmtpConfig: (id) => {
        set(state => ({
          smtpConfigs: state.smtpConfigs.map(c => 
            c.id === id ? { ...c, testStatus: 'pending' } : c
          )
        }));
        setTimeout(() => {
          set(state => ({
            smtpConfigs: state.smtpConfigs.map(c => 
              c.id === id ? { 
                ...c, 
                testStatus: Math.random() > 0.2 ? 'success' : 'failed',
                testMessage: Math.random() > 0.2 ? 'Connection successful' : 'Authentication failed'
              } : c
            )
          }));
        }, 2000);
      },

      setDefaultSmtpConfig: (id) => {
        set(state => ({
          smtpConfigs: state.smtpConfigs.map(c => ({
            ...c,
            isDefault: c.id === id
          }))
        }));
      },

      // Mailbox CRUD
      addMailbox: (mailboxData) => {
        const newMailbox: Mailbox = {
          ...mailboxData,
          id: `mb${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        set(state => ({ mailboxes: [...state.mailboxes, newMailbox] }));
      },

      updateMailbox: (id, updates) => {
        set(state => ({
          mailboxes: state.mailboxes.map(m => 
            m.id === id ? { ...m, ...updates } : m
          )
        }));
      },

      deleteMailbox: (id) => {
        set(state => ({ mailboxes: state.mailboxes.filter(m => m.id !== id) }));
      },

      // Email Alias CRUD
      addEmailAlias: (aliasData) => {
        const newAlias: EmailAlias = {
          ...aliasData,
          id: `ea${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        set(state => ({ emailAliases: [...state.emailAliases, newAlias] }));
      },

      updateEmailAlias: (id, updates) => {
        set(state => ({
          emailAliases: state.emailAliases.map(a => 
            a.id === id ? { ...a, ...updates } : a
          )
        }));
      },

      deleteEmailAlias: (id) => {
        set(state => ({ emailAliases: state.emailAliases.filter(a => a.id !== id) }));
      },

      // Email Rotation CRUD
      addRotationConfig: (configData) => {
        const now = new Date().toISOString();
        const newConfig: EmailRotationConfig = {
          ...configData,
          id: `rot${Date.now()}`,
          createdAt: now,
          updatedAt: now,
        };
        set(state => ({ emailRotationConfigs: [...state.emailRotationConfigs, newConfig] }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Created email rotation configuration',
          entityType: 'config',
          entityId: newConfig.id,
          entityName: newConfig.name,
        });
      },

      updateRotationConfig: (id, updates) => {
        set(state => ({
          emailRotationConfigs: state.emailRotationConfigs.map(c => 
            c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
          )
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Updated email rotation configuration',
          entityType: 'config',
          entityId: id,
          entityName: updates.name || id,
        });
      },

      deleteRotationConfig: (id) => {
        const config = get().emailRotationConfigs.find(c => c.id === id);
        set(state => ({ emailRotationConfigs: state.emailRotationConfigs.filter(c => c.id !== id) }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Deleted email rotation configuration',
          entityType: 'config',
          entityId: id,
          entityName: config?.name || id,
        });
      },

      toggleRotationConfig: (id) => {
        const config = get().emailRotationConfigs.find(c => c.id === id);
        if (config) {
          get().updateRotationConfig(id, { enabled: !config.enabled });
        }
      },

      // Email Rotation Logic
      getRotationPoolMailboxes: () => {
        const { mailboxes, emailRotationConfigs } = get();
        const activeConfig = emailRotationConfigs.find(c => c.enabled);
        
        if (!activeConfig) {
          return mailboxes.filter(m => m.isActive && m.inRotationPool);
        }
        
        return mailboxes.filter(m => 
          m.isActive && 
          activeConfig.mailboxIds.includes(m.id)
        );
      },

      getNextMailboxForSending: (estimatedEmailCount: number) => {
        const { mailboxes, emailRotationConfigs } = get();
        const activeConfig = emailRotationConfigs.find(c => c.enabled);
        
        if (!activeConfig || estimatedEmailCount < activeConfig.rotationThreshold) {
          const defaultMailbox = mailboxes.find(m => m.isActive && m.inRotationPool);
          return defaultMailbox || null;
        }
        
        const poolMailboxes = mailboxes.filter(m => {
          if (!m.isActive) return false;
          if (!activeConfig.mailboxIds.includes(m.id)) return false;
          
          const sentToday = m.sentToday || 0;
          const remainingCapacity = Math.min(
            m.dailyLimit - sentToday,
            activeConfig.maxEmailsPerMailboxPerDay - sentToday,
            activeConfig.maxEmailsPerMailboxPerHour
          );
          
          return remainingCapacity > 0;
        });
        
        if (poolMailboxes.length === 0) {
          return null;
        }
        
        let sortedMailboxes: Mailbox[];
        switch (activeConfig.rotationStrategy) {
          case 'least_used':
            sortedMailboxes = [...poolMailboxes].sort((a, b) => 
              (a.sentToday || 0) - (b.sentToday || 0)
            );
            break;
          case 'priority_based':
            sortedMailboxes = [...poolMailboxes].sort((a, b) => 
              (a.rotationPriority || 999) - (b.rotationPriority || 999)
            );
            break;
          case 'random':
            sortedMailboxes = [...poolMailboxes].sort(() => Math.random() - 0.5);
            break;
          case 'round_robin':
          default:
            sortedMailboxes = [...poolMailboxes].sort((a, b) => {
              const aTime = a.lastUsedAt ? new Date(a.lastUsedAt).getTime() : 0;
              const bTime = b.lastUsedAt ? new Date(b.lastUsedAt).getTime() : 0;
              return aTime - bTime;
            });
            break;
        }
        
        return sortedMailboxes[0];
      },

      incrementMailboxSentCount: (mailboxId: string, count: number) => {
        const now = new Date().toISOString();
        set(state => ({
          mailboxes: state.mailboxes.map(m => 
            m.id === mailboxId 
              ? { 
                  ...m, 
                  sentToday: (m.sentToday || 0) + count,
                  lastUsedAt: now
                } 
              : m
          )
        }));
      },

      resetMailboxDailyCounts: () => {
        set(state => ({
          mailboxes: state.mailboxes.map(m => ({ 
            ...m, 
            sentToday: 0,
            lastUsedAt: undefined
          }))
        }));
        get().addActivityLog({
          userId: get().user?.id || '',
          userName: get().user?.name || '',
          action: 'Reset mailbox daily send counts',
          entityType: 'config',
        });
      },

      // Activity Log
      addActivityLog: (logData) => {
        const newLog: ActivityLog = {
          ...logData,
          id: `al${Date.now()}`,
          timestamp: new Date().toISOString(),
        };
        set(state => ({ 
          activityLogs: [newLog, ...state.activityLogs].slice(0, 100) 
        }));
      },

      // Stats
      updateDashboardStats: (updates) => {
        set(state => ({
          dashboardStats: { ...state.dashboardStats, ...updates }
        }));
      },
    }),
    {
      name: 'journey-platform-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        loginAttempts: state.loginAttempts,
        users: state.users,
        journeys: state.journeys,
        rules: state.rules,
        templates: state.templates,
        dataSources: state.dataSources,
        journeyRuns: state.journeyRuns,
        smtpConfigs: state.smtpConfigs,
        mailboxes: state.mailboxes,
        emailAliases: state.emailAliases,
        activityLogs: state.activityLogs,
        dashboardStats: state.dashboardStats,
        emailRotationConfigs: state.emailRotationConfigs,
      }),
    }
  )
);
