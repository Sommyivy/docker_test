import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard,
  Route,
  FileCode,
  Mail,
  Database,
  PlayCircle,
  Settings,
  Users,
  BarChart3,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Building2,
  Bell,
  Shield,
  Lock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
  permission?: string;
  requiredRole?: string[];
}

const navItems: NavItem[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'journeys', label: 'Journeys', icon: Route },
  { id: 'rules', label: 'Rules', icon: FileCode, permission: 'rules:read' },
  { id: 'templates', label: 'Templates', icon: Mail, permission: 'templates:read' },
  { id: 'datasources', label: 'Data Sources', icon: Database, permission: 'datasources:read' },
  { id: 'runs', label: 'Runs & Monitoring', icon: PlayCircle, badge: 1, permission: 'runs:read' },
  { id: 'users', label: 'User Management', icon: Users, permission: 'users:read', requiredRole: ['super_admin', 'admin'] },
  { id: 'reports', label: 'Reports', icon: BarChart3, permission: 'reports:read' },
];

const adminItems: NavItem[] = [
  { id: 'admin', label: 'Admin Settings', icon: Settings, permission: 'admin:config', requiredRole: ['super_admin', 'admin'] },
];

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const { user, logout, activeModule, setActiveModule, dashboardStats, canAccessModule, hasPermission } = useAppStore();

  const handleNavClick = (moduleId: string) => {
    setActiveModule(moduleId);
  };

  const handleLogout = () => {
    logout();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Get role display name
  const getRoleDisplayName = (role: string) => {
    const roleNames: Record<string, string> = {
      super_admin: 'Super Administrator',
      admin: 'Administrator',
      developer: 'Developer',
      comms: 'Communications',
      compliance: 'Compliance Officer',
      viewer: 'Viewer',
    };
    return roleNames[role] || role;
  };

  const renderNavItem = (item: NavItem) => {
    const Icon = item.icon;
    const isActive = activeModule === item.id;
    
    // Check if user can access this module
    const canAccess = canAccessModule(item.id);
    const hasRequiredPermission = !item.permission || hasPermission(item.permission.split(':')[0], item.permission.split(':')[1] || 'view');
    
    // Check required role
    const hasRequiredRole = !item.requiredRole || item.requiredRole.includes(user?.role || '');

    if (!canAccess || !hasRequiredPermission || !hasRequiredRole) return null;

    return (
      <button
        key={item.id}
        onClick={() => handleNavClick(item.id)}
        className={cn(
          'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
          'w-full text-left',
          isActive
            ? 'bg-[#062A78] text-white shadow-md'
            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
          collapsed && 'justify-center px-2'
        )}
      >
        <Icon className={cn('w-5 h-5 flex-shrink-0', isActive && 'text-white')} />
        {!collapsed && (
          <>
            <span className="flex-1">{item.label}</span>
            {item.badge && (
              <Badge variant={isActive ? 'secondary' : 'default'} className="text-xs">
                {item.badge}
              </Badge>
            )}
          </>
        )}
      </button>
    );
  };

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed left-0 top-0 h-full bg-white border-r border-slate-200 z-40 transition-all duration-300',
          collapsed ? 'w-16' : 'w-64'
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-slate-200">
          <div className={cn('flex items-center gap-3', collapsed && 'justify-center w-full')}>
            <div className="w-8 h-8 rounded-lg bg-[#062A78] flex items-center justify-center flex-shrink-0">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            {!collapsed && (
              <div className="flex flex-col">
                <span className="font-bold text-[#062A78] text-sm leading-tight">Access Bank</span>
                <span className="text-[10px] text-slate-500">Journey Platform</span>
              </div>
            )}
          </div>
        </div>

        {/* Collapse Button */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-20 w-6 h-6 bg-white border border-slate-200 rounded-full flex items-center justify-center shadow-sm hover:bg-slate-50"
        >
          {collapsed ? (
            <ChevronRight className="w-3 h-3 text-slate-500" />
          ) : (
            <ChevronLeft className="w-3 h-3 text-slate-500" />
          )}
        </button>

        {/* Navigation */}
        <ScrollArea className="h-[calc(100vh-8rem)]">
          <div className="p-3 space-y-1">
            {navItems.map(renderNavItem)}
          </div>

          <Separator className="my-3 mx-3 w-auto" />

          <div className="px-3 pb-3">
            {!collapsed && (
              <p className="px-3 text-xs font-medium text-slate-400 mb-2">Administration</p>
            )}
            <div className="space-y-1">
              {adminItems.map(renderNavItem)}
            </div>
          </div>
        </ScrollArea>
      </aside>

      {/* Main Content */}
      <main
        className={cn(
          'flex-1 min-h-screen transition-all duration-300',
          collapsed ? 'ml-16' : 'ml-64'
        )}
      >
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30">
          <div>
            <h1 className="text-xl font-semibold text-slate-900">
              {navItems.find((i) => i.id === activeModule)?.label ||
                adminItems.find((i) => i.id === activeModule)?.label ||
                'Dashboard'}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {/* Notifications */}
            <button className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
              {dashboardStats.pendingApprovals > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#F28A1A] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {dashboardStats.pendingApprovals}
                </span>
              )}
            </button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 p-1.5 rounded-lg hover:bg-slate-100 transition-colors">
                  <Avatar className="w-8 h-8 bg-[#062A78]">
                    <AvatarFallback className="text-white text-xs font-medium">
                      {getInitials(user?.name || 'U')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-left">
                    <p className="text-sm font-medium text-slate-900">{user?.name}</p>
                    <p className="text-xs text-slate-500">{getRoleDisplayName(user?.role || '')}</p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span className="font-semibold">{user?.name}</span>
                    <span className="text-xs text-muted-foreground font-normal">{user?.email}</span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="px-2 py-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <Shield className="w-3 h-3" />
                    <span>Role: {getRoleDisplayName(user?.role || '')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Building2 className="w-3 h-3" />
                    <span>Dept: {user?.department}</span>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="gap-2">
                  <Users className="w-4 h-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2">
                  <Lock className="w-4 h-4" />
                  Change Password
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2">
                  <Settings className="w-4 h-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="gap-2 text-red-600">
                  <LogOut className="w-4 h-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}
