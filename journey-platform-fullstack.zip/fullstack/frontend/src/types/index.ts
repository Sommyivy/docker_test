// Customer Journey Engagement Platform - TypeScript Types

// User & Authentication
export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
  permissions: Permission[];
  // Password management
  passwordHash: string;
  isTemporaryPassword: boolean;
  passwordChangedAt?: string;
  passwordExpiresAt?: string;
  failedLoginAttempts: number;
  lockedUntil?: string;
  // Profile
  phone?: string;
  avatar?: string;
}

// Workflow Stage Definitions
export type WorkflowStage = 
  | 'intake'           // Business user submits request
  | 'dmo_review'       // DMO team reviews and creates rules
  | 'cx_review'        // CX/Comms team reviews content
  | 'control_review'   // Control team final approval
  | 'approved'         // Fully approved
  | 'rejected'         // Rejected at any stage
  | 'live'             // Active/running
  | 'paused'           // Temporarily paused
  | 'completed'        // Journey completed
  | 'archived';        // Archived

export type WorkflowStageRole = 
  | 'business_user'    // Initiates journey request
  | 'dmo_team'         // Creates business rules and logic
  | 'cx_team'          // Reviews and approves content/templates
  | 'control_team'     // Final approval before going live
  | 'system';          // Automated transitions

export interface WorkflowStageConfig {
  stage: WorkflowStage;
  role: WorkflowStageRole;
  label: string;
  description: string;
  actions: WorkflowAction[];
  canEdit: boolean;
  canComment: boolean;
  slaHours?: number;   // SLA for this stage
}

export type WorkflowAction = 
  | 'submit'           // Submit to next stage
  | 'approve'          // Approve and move forward
  | 'reject'           // Reject and return
  | 'request_changes'  // Request changes without rejecting
  | 'escalate'         // Escalate to higher authority
  | 'pause'            // Pause journey
  | 'resume'           // Resume journey
  | 'archive'          // Archive journey
  | 'delete';          // Delete journey

export interface WorkflowComment {
  id: string;
  stage: WorkflowStage;
  userId: string;
  userName: string;
  userRole: UserRole;
  comment: string;
  timestamp: string;
  action: WorkflowAction;
  attachments?: Attachment[];
}

export interface Attachment {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: WorkflowAction;
  fromStage?: WorkflowStage;
  toStage?: WorkflowStage;
  comment?: string;
  metadata?: Record<string, unknown>;
}

// Login attempt tracking
export interface LoginAttempt {
  email: string;
  timestamp: string;
  success: boolean;
  ipAddress?: string;
  errorMessage?: string;
}

// Password policy
export interface PasswordPolicy {
  minLength: number;
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
  expiryDays: number;
  preventReuseCount: number;
  lockoutAfterFailedAttempts: number;
  lockoutDurationMinutes: number;
}

export type UserRole = 'super_admin' | 'admin' | 'developer' | 'comms' | 'compliance' | 'viewer';

export type Permission = 
  | 'journeys:read' | 'journeys:create' | 'journeys:edit' | 'journeys:delete' | 'journeys:approve'
  | 'rules:read' | 'rules:create' | 'rules:edit' | 'rules:delete' | 'rules:validate'
  | 'templates:read' | 'templates:create' | 'templates:edit' | 'templates:delete'
  | 'datasources:read' | 'datasources:create' | 'datasources:edit' | 'datasources:delete' | 'datasources:test'
  | 'runs:read' | 'runs:control' | 'runs:monitor'
  | 'admin:config' | 'admin:smtp' | 'admin:mailboxes' | 'admin:aliases'
  | 'users:read' | 'users:create' | 'users:edit' | 'users:delete' | 'users:manage_roles'
  | 'reports:read' | 'reports:export';

// Journey Lifecycle Stages (Customer Lifecycle)
export type JourneyStage = 'ACQUIRE' | 'ACTIVATE' | 'ENGAGE' | 'GROW' | 'RETAIN' | 'WIN_BACK' | 'ADVOCATE';

// Journey with Workflow Support
export interface Journey {
  id: string;
  name: string;
  description: string;
  // Customer lifecycle stage
  lifecycleStage: JourneyStage;
  // Workflow stage (approval process)
  workflowStage: WorkflowStage;
  // Legacy status for backward compatibility
  status: JourneyStatus;
  priority: 'low' | 'medium' | 'high' | 'critical';
  
  // Ownership
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  
  // Assignment
  assignedTo?: string;           // Current owner
  assignedToName?: string;
  assignedToRole?: UserRole;
  
  // Scheduling
  scheduledAt?: string;
  startedAt?: string;
  completedAt?: string;
  
  // Business Rules
  entryRuleId?: string;
  exitRuleId?: string;
  
  // Content
  templateId?: string;
  templateName?: string;
  
  // A/B Testing
  controlGroup?: ControlGroup;
  
  // Workflow Data
  comments: WorkflowComment[];
  auditHistory: AuditEntry[];
  
  // Legacy approval (for migration)
  approvalStatus: ApprovalStatus;
  approvalHistory: ApprovalEvent[];
  
  // Metrics
  estimatedReach: number;
  actualReach: number;
  conversionRate: number;
  
  // Metadata
  tags: string[];
  category?: string;
  
  // SLA tracking
  stageEnteredAt?: string;
  slaDeadline?: string;
  slaBreached?: boolean;
}

// Legacy status types (for backward compatibility)
export type JourneyStatus = 'draft' | 'pending_approval' | 'approved' | 'scheduled' | 'running' | 'paused' | 'completed' | 'cancelled';
export type ApprovalStatus = 'pending_dev' | 'pending_comms' | 'pending_compliance' | 'approved' | 'rejected';

export interface ControlGroup {
  enabled: boolean;
  percentage: number;
  description: string;
}

export interface ApprovalEvent {
  stage: ApprovalStatus;
  action: 'submitted' | 'approved' | 'rejected';
  by: string;
  at: string;
  notes?: string;
}

// Data Sources - SQL Connections
export type DataSourceType = 'mssql' | 'oracle' | 'postgresql' | 'mysql' | 'api' | '360_store' | 'snowflake' | 'redshift';
export type DataSourceStatus = 'connected' | 'disconnected' | 'error' | 'testing';
export type SSLMode = 'disable' | 'require' | 'verify-ca' | 'verify-full';

export interface DataSource {
  id: string;
  name: string;
  description?: string;
  type: DataSourceType;
  host: string;
  port: number;
  database?: string;
  schema?: string;
  username?: string;
  password?: string;
  sslMode?: SSLMode;
  status: DataSourceStatus;
  timeoutSeconds: number;
  maxConnections: number;
  lastTestedAt?: string;
  lastError?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
  tags: string[];
  // API specific fields
  apiEndpoint?: string;
  apiKey?: string;
  apiHeaders?: Record<string, string>;
  // 360 Store specific
  storeRegion?: string;
  storeEnvironment?: 'production' | 'staging' | 'development';
}

// Rules & SQL
export type RuleType = 'entry' | 'exit' | 'trigger' | 'segment' | 'validation';
export type RuleStatus = 'active' | 'inactive' | 'draft' | 'error';

export interface Rule {
  id: string;
  name: string;
  description: string;
  type: RuleType;
  status: RuleStatus;
  dataSourceId: string;
  sqlQuery: string;
  sqlPreview?: string;
  validatedAt?: string;
  validatedBy?: string;
  validationResult?: ValidationResult;
  estimatedRecordCount?: number;
  executionTimeMs?: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  isSafe: boolean;
  safetyPolicies: SafetyPolicy[];
}

export interface ValidationResult {
  valid: boolean;
  recordCount: number;
  sampleData: Record<string, unknown>[];
  columns: string[];
  errors?: string[];
  warnings?: string[];
}

export interface SafetyPolicy {
  id: string;
  name: string;
  type: 'readonly' | 'noupdate' | 'nodelete' | 'noinsert' | 'whitelist' | 'rowlimit';
  enabled: boolean;
  config?: Record<string, unknown> | { maxRows: number };
}

// Email Templates with Workflow
export type TemplateType = 'email' | 'sms' | 'push' | 'whatsapp';
export type TemplateStatus = 'draft' | 'pending_review' | 'approved' | 'active' | 'archived' | 'rejected';

export interface Template {
  id: string;
  name: string;
  description: string;
  type: TemplateType;
  status: TemplateStatus;
  
  // Workflow
  workflowStage: WorkflowStage;
  
  // Content
  subject?: string;
  htmlContent: string;
  textContent?: string;
  variables: TemplateVariable[];
  previewData?: Record<string, string>;
  
  // Ownership
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  
  // Assignment
  assignedTo?: string;
  assignedToName?: string;
  assignedToRole?: UserRole;
  
  // Workflow Data
  comments: WorkflowComment[];
  auditHistory: AuditEntry[];
  
  // Metadata
  tags: string[];
  category?: string;
  brandGuidelinesCompliant?: boolean;
  legalApproved?: boolean;
  
  // SLA
  stageEnteredAt?: string;
  slaDeadline?: string;
  slaBreached?: boolean;
}

export interface TemplateVariable {
  name: string;
  type: 'string' | 'number' | 'date' | 'boolean';
  required: boolean;
  defaultValue?: string;
  description?: string;
}

// Journey Runs & Monitoring
export interface JourneyRun {
  id: string;
  journeyId: string;
  journeyName: string;
  status: RunStatus;
  startedAt: string;
  completedAt?: string;
  scheduledAt?: string;
  totalRecords: number;
  processedRecords: number;
  successfulSends: number;
  failedSends: number;
  bounced: number;
  opened: number;
  clicked: number;
  unsubscribed: number;
  complained: number;
  executionLogs: ExecutionLog[];
  triggeredBy: string;
  dataSourceId: string;
}

export type RunStatus = 'pending' | 'queued' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';

export interface ExecutionLog {
  timestamp: string;
  level: 'info' | 'warning' | 'error';
  message: string;
  details?: Record<string, unknown>;
}

// Admin Configuration
export interface SMTPConfig {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  password: string;
  encryption: 'none' | 'tls' | 'ssl';
  fromEmail: string;
  fromName: string;
  isDefault: boolean;
  isActive: boolean;
  testStatus?: 'pending' | 'success' | 'failed';
  testMessage?: string;
}

export interface Mailbox {
  id: string;
  email: string;
  name: string;
  department: string;
  smtpConfigId: string;
  isActive: boolean;
  dailyLimit: number;
  sentToday?: number;
  createdAt: string;
  // Rotation pool membership
  inRotationPool?: boolean;
  rotationPriority?: number;
  lastUsedAt?: string;
}

// Email Rotation Configuration
export interface EmailRotationConfig {
  id: string;
  name: string;
  description?: string;
  // Rotation settings
  enabled: boolean;
  rotationThreshold: number; // e.g., 10000 - when to start rotating
  rotationStrategy: 'round_robin' | 'least_used' | 'priority_based' | 'random';
  batchSize: number; // emails per batch before switching mailboxes
  cooldownMinutes: number; // cooldown between switches
  // Pool settings
  mailboxIds: string[]; // mailboxes in this rotation pool
  maxEmailsPerMailboxPerHour: number;
  maxEmailsPerMailboxPerDay: number;
  // Safety settings
  pauseOnHighBounceRate: boolean;
  bounceRateThreshold: number; // percentage
  pauseOnHighComplaintRate: boolean;
  complaintRateThreshold: number; // percentage
  // Scheduling
  activeHoursStart?: string; // HH:mm format
  activeHoursEnd?: string; // HH:mm format
  respectMailboxLimits: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

// Email Send Job for tracking rotation
export interface EmailSendJob {
  id: string;
  journeyRunId: string;
  recipientEmail: string;
  fromMailboxId: string;
  fromEmail: string;
  status: 'pending' | 'sent' | 'failed' | 'bounced' | 'complained';
  sentAt?: string;
  batchNumber: number;
  rotationIndex: number;
  errorMessage?: string;
}

export interface EmailAlias {
  id: string;
  alias: string;
  targetEmail: string;
  description?: string;
  isActive: boolean;
  createdAt: string;
}

// Reports & Analytics
export interface ReportMetric {
  date: string;
  journeysRun: number;
  emailsSent: number;
  emailsDelivered: number;
  openRate: number;
  clickRate: number;
  bounceRate: number;
  unsubscribeRate: number;
  complaintRate: number;
}

export interface JourneyPerformance {
  journeyId: string;
  journeyName: string;
  stage: JourneyStage;
  runs: number;
  totalSent: number;
  delivered: number;
  opened: number;
  clicked: number;
  converted: number;
  roi: number;
}

// Dashboard Stats
export interface DashboardStats {
  totalJourneys: number;
  activeJourneys: number;
  totalRuns: number;
  emailsSent: number;
  deliveryRate: number;
  openRate: number;
  clickRate: number;
  pendingApprovals: number;
  activeRules: number;
  connectedDataSources: number;
}

// Activity Log
export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  entityType: 'journey' | 'rule' | 'template' | 'datasource' | 'user' | 'config';
  entityId?: string;
  entityName?: string;
  details?: Record<string, unknown>;
  timestamp: string;
  ipAddress?: string;
}

// Navigation
export interface NavItem {
  id: string;
  label: string;
  icon: string;
  path: string;
  requiredPermission?: Permission;
  children?: NavItem[];
}
