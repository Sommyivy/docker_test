import { useState, useEffect } from 'react';
import { useAppStore } from '@/store/appStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Building2, Mail, Lock, Loader2, Eye, EyeOff, AlertCircle, CheckCircle, User, Shield, Code, FileText, BarChart } from 'lucide-react';
import { loginCredentials } from '@/data/mockData';

// Password change dialog component
function PasswordChangeDialog({ 
  isOpen, 
  onClose, 
  onSubmit 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onSubmit: (oldPass: string, newPass: string) => Promise<boolean>;
}) {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const validatePassword = (password: string) => {
    if (password.length < 8) return 'Password must be at least 8 characters';
    if (!/[A-Z]/.test(password)) return 'Password must contain at least one uppercase letter';
    if (!/[a-z]/.test(password)) return 'Password must contain at least one lowercase letter';
    if (!/[0-9]/.test(password)) return 'Password must contain at least one number';
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) return 'Password must contain at least one special character';
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const validationError = validatePassword(newPassword);
    if (validationError) {
      setError(validationError);
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    setIsSubmitting(true);
    const success = await onSubmit(oldPassword, newPassword);
    setIsSubmitting(false);

    if (success) {
      onClose();
    } else {
      setError('Current password is incorrect');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Change Your Password</DialogTitle>
          <DialogDescription>
            Your account is using a temporary password. Please create a new password to continue.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-2">
            <Label>Current Password</Label>
            <div className="relative">
              <Input
                type={showOldPassword ? 'text' : 'password'}
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowOldPassword(!showOldPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                {showOldPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div className="space-y-2">
            <Label>New Password</Label>
            <div className="relative">
              <Input
                type={showNewPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              Must be at least 8 characters with uppercase, lowercase, number, and special character
            </p>
          </div>
          <div className="space-y-2">
            <Label>Confirm New Password</Label>
            <Input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>
          <DialogFooter>
            <Button type="submit" className="bg-[#062A78]" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                'Change Password'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Role badge component
function RoleBadge({ role }: { role: string }) {
  const roleConfig: Record<string, { color: string; icon: React.ElementType; label: string }> = {
    super_admin: { color: 'bg-red-100 text-red-700', icon: Shield, label: 'Super Admin' },
    admin: { color: 'bg-orange-100 text-orange-700', icon: User, label: 'Admin' },
    developer: { color: 'bg-blue-100 text-blue-700', icon: Code, label: 'Developer' },
    comms: { color: 'bg-purple-100 text-purple-700', icon: FileText, label: 'Communications' },
    compliance: { color: 'bg-green-100 text-green-700', icon: CheckCircle, label: 'Compliance' },
    viewer: { color: 'bg-gray-100 text-gray-700', icon: BarChart, label: 'Viewer' },
  };

  const config = roleConfig[role] || roleConfig.viewer;
  const Icon = config.icon;

  return (
    <Badge className={`${config.color} text-xs`}>
      <Icon className="w-3 h-3 mr-1" />
      {config.label}
    </Badge>
  );
}

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showCredentials, setShowCredentials] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);
  
  const { login, isAuthenticated, changePassword, showPasswordChangeDialog, setShowPasswordChangeDialog } = useAppStore();

  // Handle password change requirement
  useEffect(() => {
    if (isAuthenticated && showPasswordChangeDialog) {
      setShowPasswordChange(true);
    }
  }, [isAuthenticated, showPasswordChangeDialog]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const result = await login(email, password);
    setIsLoading(false);

    if (result.success) {
      setLoginSuccess(true);
      if (!result.requiresPasswordChange) {
        // Login complete, will redirect automatically
      }
    } else {
      setError(result.error || 'Login failed');
    }
  };

  const handlePasswordChange = async (oldPass: string, newPass: string) => {
    const { user } = useAppStore.getState();
    if (!user) return false;
    
    const success = await changePassword(user.id, oldPass, newPass);
    if (success) {
      setShowPasswordChangeDialog(false);
    }
    return success;
  };

  if (isAuthenticated && !showPasswordChangeDialog) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#062A78]/5 to-[#F28A1A]/5 p-4">
      <div className="w-full max-w-5xl flex flex-col lg:flex-row gap-8">
        {/* Left side - Login Form */}
        <div className="flex-1">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-[#062A78] mb-4">
              <Building2 className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-[#062A78]">Access Bank</h1>
            <p className="text-muted-foreground mt-1">Customer Journey Engagement Platform</p>
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-xl">Welcome back</CardTitle>
              <CardDescription>
                Enter your credentials to access the platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {loginSuccess && (
                <Alert className="mb-4 bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>Login successful! Redirecting...</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                      disabled={isLoading || loginSuccess}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                      required
                      disabled={isLoading || loginSuccess}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-[#062A78] hover:bg-[#062A78]/90"
                  disabled={isLoading || loginSuccess}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </Button>
              </form>

              <div className="mt-6 pt-6 border-t">
                <button
                  onClick={() => setShowCredentials(!showCredentials)}
                  className="text-sm text-[#062A78] hover:underline w-full text-center"
                >
                  {showCredentials ? 'Hide Demo Credentials' : 'Show Demo Credentials'}
                </button>
              </div>
            </CardContent>
          </Card>

          <p className="text-center text-xs text-muted-foreground mt-8">
            © 2024 Access Bank PLC. All rights reserved.
          </p>
        </div>

        {/* Right side - Demo Credentials */}
        {showCredentials && (
          <div className="lg:w-96">
            <Card className="border-0 shadow-xl h-full">
              <CardHeader>
                <CardTitle className="text-lg">Demo Credentials</CardTitle>
                <CardDescription>
                  Use these accounts to test different roles
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[500px] overflow-y-auto">
                  {loginCredentials.map((cred, index) => (
                    <div
                      key={index}
                      className="p-3 rounded-lg border hover:border-[#062A78] hover:bg-[#062A78]/5 cursor-pointer transition-all"
                      onClick={() => {
                        setEmail(cred.email);
                        setPassword(cred.password);
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <RoleBadge role={cred.role} />
                        {cred.isTemporary && (
                          <Badge variant="outline" className="text-xs text-orange-600 border-orange-300">
                            Temporary
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm font-medium">{cred.email}</p>
                      <p className="text-xs text-muted-foreground">{cred.description}</p>
                      <p className="text-xs font-mono mt-1 bg-slate-100 p-1 rounded">
                        Password: {cred.password}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-700">
                    <AlertCircle className="w-4 h-4 inline mr-1" />
                    Click on any credential card to auto-fill the login form
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Password Change Dialog */}
      <PasswordChangeDialog
        isOpen={showPasswordChange}
        onClose={() => {}}
        onSubmit={handlePasswordChange}
      />
    </div>
  );
}
