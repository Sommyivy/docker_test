// Mock Data for Customer Journey Engagement Platform

import type {
  User,
  Journey,
  Rule,
  Template,
  DataSource,
  JourneyRun,
  SMTPConfig,
  Mailbox,
  EmailAlias,
  ActivityLog,
  DashboardStats,
  ReportMetric,
  JourneyPerformance,
  PasswordPolicy,
  WorkflowStageConfig,
  WorkflowComment,
  AuditEntry,
  WorkflowStage,
} from '@/types';

// Password policy configuration
export const passwordPolicy: PasswordPolicy = {
  minLength: 8,
  requireUppercase: true,
  requireLowercase: true,
  requireNumbers: true,
  requireSpecialChars: true,
  expiryDays: 90,
  preventReuseCount: 5,
  lockoutAfterFailedAttempts: 5,
  lockoutDurationMinutes: 30,
};

// User credentials database (in production, this would be in a secure database)
// Password format: plain text for demo purposes only
export const userCredentials: Record<string, { password: string; isTemporary: boolean }> = {
  'admin@accessbankplc.com': { password: 'Admin@123', isTemporary: false },
  'journey.dev@accessbankplc.com': { password: 'TempPass123!', isTemporary: true },
  'comms.reviewer@accessbankplc.com': { password: 'TempPass456!', isTemporary: true },
  'compliance.officer@accessbankplc.com': { password: 'TempPass789!', isTemporary: true },
  'viewer@accessbankplc.com': { password: 'Viewer@123', isTemporary: false },
  'marketing@accessbankplc.com': { password: 'TempMkt123!', isTemporary: true },
  'developer2@accessbankplc.com': { password: 'TempDev123!', isTemporary: true },
};

// Current user (logged in)
export const currentUser: User = {
  id: 'u1',
  email: 'admin@accessbankplc.com',
  name: 'System Administrator',
  role: 'super_admin',
  department: 'IT Operations',
  isActive: true,
  lastLogin: new Date().toISOString(),
  createdAt: '2024-01-15T08:00:00Z',
  permissions: [
    'journeys:read', 'journeys:create', 'journeys:edit', 'journeys:delete', 'journeys:approve',
    'rules:read', 'rules:create', 'rules:edit', 'rules:delete', 'rules:validate',
    'templates:read', 'templates:create', 'templates:edit', 'templates:delete',
    'datasources:read', 'datasources:create', 'datasources:edit', 'datasources:delete', 'datasources:test',
    'runs:read', 'runs:control', 'runs:monitor',
    'admin:config', 'admin:smtp', 'admin:mailboxes', 'admin:aliases',
    'users:read', 'users:create', 'users:edit', 'users:delete', 'users:manage_roles',
    'reports:read', 'reports:export',
  ],
  passwordHash: 'hashed_admin_password',
  isTemporaryPassword: false,
  passwordChangedAt: '2024-01-15T08:00:00Z',
  failedLoginAttempts: 0,
  phone: '+234-1-2712000',
};

// Users
export const users: User[] = [
  currentUser,
  {
    id: 'u2',
    email: 'journey.dev@accessbankplc.com',
    name: 'Journey Developer',
    role: 'developer',
    department: 'Digital Marketing',
    isActive: true,
    lastLogin: '2024-03-20T14:30:00Z',
    createdAt: '2024-01-20T09:00:00Z',
    permissions: ['journeys:read', 'journeys:create', 'journeys:edit', 'rules:read', 'rules:create', 'templates:read', 'runs:read'],
    passwordHash: 'hashed_dev_password',
    isTemporaryPassword: true,
    passwordExpiresAt: '2024-04-20T00:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712001',
  },
  {
    id: 'u3',
    email: 'comms.reviewer@accessbankplc.com',
    name: 'Communications Reviewer',
    role: 'comms',
    department: 'Corporate Communications',
    isActive: true,
    lastLogin: '2024-03-21T10:15:00Z',
    createdAt: '2024-02-01T11:00:00Z',
    permissions: ['journeys:read', 'journeys:approve', 'templates:read', 'templates:edit'],
    passwordHash: 'hashed_comms_password',
    isTemporaryPassword: true,
    passwordExpiresAt: '2024-04-21T00:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712002',
  },
  {
    id: 'u4',
    email: 'compliance.officer@accessbankplc.com',
    name: 'Compliance Officer',
    role: 'compliance',
    department: 'Risk & Compliance',
    isActive: true,
    lastLogin: '2024-03-19T16:45:00Z',
    createdAt: '2024-02-10T08:30:00Z',
    permissions: ['journeys:read', 'journeys:approve', 'rules:read', 'reports:read'],
    passwordHash: 'hashed_compliance_password',
    isTemporaryPassword: true,
    passwordExpiresAt: '2024-04-19T00:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712003',
  },
  {
    id: 'u5',
    email: 'viewer@accessbankplc.com',
    name: 'Report Viewer',
    role: 'viewer',
    department: 'Management',
    isActive: true,
    lastLogin: '2024-03-18T09:00:00Z',
    createdAt: '2024-03-01T10:00:00Z',
    permissions: ['journeys:read', 'runs:read', 'reports:read'],
    passwordHash: 'hashed_viewer_password',
    isTemporaryPassword: false,
    passwordChangedAt: '2024-03-01T10:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712004',
  },
  {
    id: 'u6',
    email: 'marketing@accessbankplc.com',
    name: 'Marketing Manager',
    role: 'admin',
    department: 'Marketing',
    isActive: true,
    lastLogin: '2024-03-20T11:00:00Z',
    createdAt: '2024-02-15T09:00:00Z',
    permissions: [
      'journeys:read', 'journeys:create', 'journeys:edit', 'journeys:approve',
      'rules:read', 'rules:create', 'templates:read', 'templates:create', 'templates:edit',
      'datasources:read', 'runs:read', 'reports:read', 'reports:export',
    ],
    passwordHash: 'hashed_marketing_password',
    isTemporaryPassword: true,
    passwordExpiresAt: '2024-04-20T00:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712005',
  },
  {
    id: 'u7',
    email: 'developer2@accessbankplc.com',
    name: 'Senior Developer',
    role: 'developer',
    department: 'IT Development',
    isActive: true,
    lastLogin: '2024-03-19T13:30:00Z',
    createdAt: '2024-02-20T10:00:00Z',
    permissions: ['journeys:read', 'journeys:create', 'journeys:edit', 'journeys:delete', 'rules:read', 'rules:create', 'rules:edit', 'templates:read', 'runs:read'],
    passwordHash: 'hashed_dev2_password',
    isTemporaryPassword: true,
    passwordExpiresAt: '2024-04-19T00:00:00Z',
    failedLoginAttempts: 0,
    phone: '+234-1-2712006',
  },
  {
    id: 'u8',
    email: 'support@accessbankplc.com',
    name: 'Support Staff',
    role: 'viewer',
    department: 'Customer Support',
    isActive: false, // Inactive user example
    lastLogin: '2024-02-15T09:00:00Z',
    createdAt: '2024-01-25T08:00:00Z',
    permissions: ['journeys:read', 'runs:read'],
    passwordHash: 'hashed_support_password',
    isTemporaryPassword: false,
    failedLoginAttempts: 3,
    lockedUntil: '2024-03-22T12:00:00Z',
    phone: '+234-1-2712007',
  },
];

// Login credentials reference for display
export const loginCredentials = [
  { email: 'admin@accessbankplc.com', password: 'Admin@123', role: 'Super Admin', description: 'Full system access', isTemporary: false },
  { email: 'marketing@accessbankplc.com', password: 'TempMkt123!', role: 'Admin', description: 'Marketing admin with journey approval', isTemporary: true },
  { email: 'journey.dev@accessbankplc.com', password: 'TempPass123!', role: 'Developer', description: 'Can create and edit journeys', isTemporary: true },
  { email: 'developer2@accessbankplc.com', password: 'TempDev123!', role: 'Developer', description: 'Senior developer access', isTemporary: true },
  { email: 'comms.reviewer@accessbankplc.com', password: 'TempPass456!', role: 'Communications', description: 'Reviews and approves content', isTemporary: true },
  { email: 'compliance.officer@accessbankplc.com', password: 'TempPass789!', role: 'Compliance', description: 'Compliance approval and reports', isTemporary: true },
  { email: 'viewer@accessbankplc.com', password: 'Viewer@123', role: 'Viewer', description: 'Read-only access to reports', isTemporary: false },
];

// Module access matrix by role
export const moduleAccessMatrix: Record<string, string[]> = {
  super_admin: ['overview', 'journeys', 'rules', 'templates', 'datasources', 'runs', 'admin', 'users', 'reports'],
  admin: ['overview', 'journeys', 'rules', 'templates', 'datasources', 'runs', 'reports'],
  developer: ['overview', 'journeys', 'rules', 'templates', 'datasources', 'runs'],
  comms: ['overview', 'journeys', 'templates', 'runs'],
  compliance: ['overview', 'journeys', 'rules', 'reports'],
  viewer: ['overview', 'journeys', 'runs', 'reports'],
};

// Workflow Stage Configuration
export const workflowStages: WorkflowStageConfig[] = [
  {
    stage: 'intake',
    role: 'business_user',
    label: 'Intake',
    description: 'Business user submits journey request with objectives and target audience',
    actions: ['submit'],
    canEdit: true,
    canComment: true,
    slaHours: 24,
  },
  {
    stage: 'dmo_review',
    role: 'dmo_team',
    label: 'DMO Review',
    description: 'DMO team translates request into business rules and customer logic',
    actions: ['submit', 'request_changes', 'reject'],
    canEdit: true,
    canComment: true,
    slaHours: 48,
  },
  {
    stage: 'cx_review',
    role: 'cx_team',
    label: 'CX Review',
    description: 'CX/Communications team reviews and approves content and templates',
    actions: ['approve', 'request_changes', 'reject'],
    canEdit: true,
    canComment: true,
    slaHours: 24,
  },
  {
    stage: 'control_review',
    role: 'control_team',
    label: 'Control Review',
    description: 'Control team performs final approval before activation',
    actions: ['approve', 'request_changes', 'reject'],
    canEdit: false,
    canComment: true,
    slaHours: 24,
  },
  {
    stage: 'approved',
    role: 'system',
    label: 'Approved',
    description: 'Journey is approved and ready for scheduling',
    actions: ['submit'],
    canEdit: false,
    canComment: true,
  },
  {
    stage: 'live',
    role: 'system',
    label: 'Live',
    description: 'Journey is active and running',
    actions: ['pause', 'archive'],
    canEdit: false,
    canComment: true,
  },
  {
    stage: 'paused',
    role: 'system',
    label: 'Paused',
    description: 'Journey is temporarily paused',
    actions: ['resume', 'archive'],
    canEdit: false,
    canComment: true,
  },
  {
    stage: 'rejected',
    role: 'system',
    label: 'Rejected',
    description: 'Journey was rejected and needs revision',
    actions: ['submit'],
    canEdit: true,
    canComment: true,
  },
  {
    stage: 'archived',
    role: 'system',
    label: 'Archived',
    description: 'Journey is archived and no longer active',
    actions: [],
    canEdit: false,
    canComment: false,
  },
];

// Stage transition rules
export const stageTransitions: Record<WorkflowStage, { next: WorkflowStage[]; prev?: WorkflowStage }> = {
  intake: { next: ['dmo_review'] },
  dmo_review: { next: ['cx_review', 'rejected'], prev: 'intake' },
  cx_review: { next: ['control_review', 'rejected'], prev: 'dmo_review' },
  control_review: { next: ['approved', 'rejected'], prev: 'cx_review' },
  approved: { next: ['live'], prev: 'control_review' },
  live: { next: ['paused', 'archived'] },
  paused: { next: ['live', 'archived'], prev: 'live' },
  rejected: { next: ['intake'], prev: 'dmo_review' },
  archived: { next: [], prev: 'live' },
  completed: { next: [], prev: 'live' },
};

// Role to workflow stage mapping
export const roleToWorkflowStage: Record<string, WorkflowStage[]> = {
  business_user: ['intake', 'rejected'],
  dmo_team: ['dmo_review'],
  cx_team: ['cx_review'],
  control_team: ['control_review'],
  admin: ['intake', 'dmo_review', 'cx_review', 'control_review', 'approved', 'live', 'paused'],
  super_admin: ['intake', 'dmo_review', 'cx_review', 'control_review', 'approved', 'live', 'paused', 'archived'],
};

// Sample workflow comments
export const sampleComments: WorkflowComment[] = [
  {
    id: 'wc1',
    stage: 'intake',
    userId: 'u6',
    userName: 'Marketing Manager',
    userRole: 'admin',
    comment: 'We need to target new savings account holders with a welcome series. Goal is to increase product adoption by 25%.',
    timestamp: '2024-02-01T09:00:00Z',
    action: 'submit',
  },
  {
    id: 'wc2',
    stage: 'dmo_review',
    userId: 'u2',
    userName: 'Journey Developer',
    userRole: 'developer',
    comment: 'Created entry rule to identify new account holders within last 30 days. Estimated reach: 15,000 customers per month.',
    timestamp: '2024-02-20T14:00:00Z',
    action: 'submit',
  },
  {
    id: 'wc3',
    stage: 'cx_review',
    userId: 'u3',
    userName: 'Communications Reviewer',
    userRole: 'comms',
    comment: 'Content looks good. Approved with minor text changes in the CTA button. Please use "Access Your Account" instead of "Login".',
    timestamp: '2024-02-22T11:00:00Z',
    action: 'approve',
  },
  {
    id: 'wc4',
    stage: 'control_review',
    userId: 'u4',
    userName: 'Compliance Officer',
    userRole: 'compliance',
    comment: 'Approved. All regulatory requirements met. Ensure unsubscribe link is functional.',
    timestamp: '2024-02-25T16:00:00Z',
    action: 'approve',
  },
];

// Sample audit entries
export const sampleAuditEntries: AuditEntry[] = [
  {
    id: 'ae1',
    timestamp: '2024-02-01T09:00:00Z',
    userId: 'u6',
    userName: 'Marketing Manager',
    userRole: 'admin',
    action: 'submit',
    fromStage: undefined,
    toStage: 'intake',
    comment: 'Journey request submitted',
  },
  {
    id: 'ae2',
    timestamp: '2024-02-20T14:00:00Z',
    userId: 'u2',
    userName: 'Journey Developer',
    userRole: 'developer',
    action: 'submit',
    fromStage: 'intake',
    toStage: 'dmo_review',
    comment: 'Business rules created and validated',
  },
  {
    id: 'ae3',
    timestamp: '2024-02-22T11:00:00Z',
    userId: 'u3',
    userName: 'Communications Reviewer',
    userRole: 'comms',
    action: 'approve',
    fromStage: 'dmo_review',
    toStage: 'cx_review',
    comment: 'Content approved with minor changes',
  },
  {
    id: 'ae4',
    timestamp: '2024-02-25T16:00:00Z',
    userId: 'u4',
    userName: 'Compliance Officer',
    userRole: 'compliance',
    action: 'approve',
    fromStage: 'cx_review',
    toStage: 'control_review',
    comment: 'Final approval granted',
  },
  {
    id: 'ae5',
    timestamp: '2024-03-01T00:00:00Z',
    userId: 'system',
    userName: 'System',
    userRole: 'super_admin',
    action: 'submit',
    fromStage: 'control_review',
    toStage: 'live',
    comment: 'Journey activated automatically per schedule',
  },
];

// Data Sources including 360 Data Store
export const dataSources: DataSource[] = [
  {
    id: 'ds1',
    name: '360 Data Store - Production',
    description: 'Primary customer 360 data warehouse with unified customer profiles, transactions, and interactions',
    type: '360_store',
    host: '360store-prod.accessbank.local',
    port: 1433,
    database: 'Customer360',
    schema: 'dbo',
    username: 'journey_svc',
    sslMode: 'require',
    status: 'connected',
    timeoutSeconds: 30,
    maxConnections: 50,
    lastTestedAt: '2024-03-21T08:00:00Z',
    createdBy: 'u1',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-03-21T08:00:00Z',
    isActive: true,
    tags: ['primary', 'customer-data', 'production'],
    storeRegion: 'lagos-primary',
    storeEnvironment: 'production',
  },
  {
    id: 'ds2',
    name: '360 Data Store - Staging',
    description: 'Staging environment for 360 data store testing',
    type: '360_store',
    host: '360store-staging.accessbank.local',
    port: 1433,
    database: 'Customer360_Staging',
    schema: 'dbo',
    username: 'journey_svc_staging',
    sslMode: 'require',
    status: 'connected',
    timeoutSeconds: 30,
    maxConnections: 20,
    lastTestedAt: '2024-03-20T14:00:00Z',
    createdBy: 'u1',
    createdAt: '2024-01-20T11:00:00Z',
    updatedAt: '2024-03-20T14:00:00Z',
    isActive: true,
    tags: ['staging', 'customer-data', 'testing'],
    storeRegion: 'lagos-secondary',
    storeEnvironment: 'staging',
  },
  {
    id: 'ds3',
    name: 'Core Banking - Oracle',
    description: 'Core banking system with account and transaction data',
    type: 'oracle',
    host: 'corebank-db.accessbank.local',
    port: 1521,
    database: 'COREBANK',
    schema: 'BANKING',
    username: 'journey_reader',
    sslMode: 'verify-ca',
    status: 'connected',
    timeoutSeconds: 45,
    maxConnections: 30,
    lastTestedAt: '2024-03-21T07:30:00Z',
    createdBy: 'u1',
    createdAt: '2024-01-25T09:00:00Z',
    updatedAt: '2024-03-21T07:30:00Z',
    isActive: true,
    tags: ['core-banking', 'oracle', 'production'],
  },
  {
    id: 'ds4',
    name: 'Marketing Data Warehouse',
    description: 'Snowflake data warehouse for marketing analytics',
    type: 'snowflake',
    host: 'accessbank.snowflakecomputing.com',
    port: 443,
    database: 'MARKETING_DW',
    schema: 'PUBLIC',
    username: 'JOURNEY_USER',
    sslMode: 'require',
    status: 'connected',
    timeoutSeconds: 60,
    maxConnections: 25,
    lastTestedAt: '2024-03-21T06:00:00Z',
    createdBy: 'u2',
    createdAt: '2024-02-01T14:00:00Z',
    updatedAt: '2024-03-21T06:00:00Z',
    isActive: true,
    tags: ['snowflake', 'marketing', 'analytics'],
  },
  {
    id: 'ds5',
    name: 'CRM API - Salesforce',
    description: 'Salesforce CRM API connection for lead and opportunity data',
    type: 'api',
    host: 'accessbank.my.salesforce.com',
    port: 443,
    apiEndpoint: 'https://accessbank.my.salesforce.com/services/data/v58.0/',
    apiHeaders: {
      'Content-Type': 'application/json',
    },
    sslMode: 'require',
    status: 'connected',
    timeoutSeconds: 30,
    maxConnections: 100,
    lastTestedAt: '2024-03-20T18:00:00Z',
    createdBy: 'u2',
    createdAt: '2024-02-10T10:30:00Z',
    updatedAt: '2024-03-20T18:00:00Z',
    isActive: true,
    tags: ['crm', 'api', 'salesforce'],
  },
  {
    id: 'ds6',
    name: 'Loan Management System',
    description: 'PostgreSQL database for loan applications and servicing',
    type: 'postgresql',
    host: 'loans-db.accessbank.local',
    port: 5432,
    database: 'loan_management',
    schema: 'public',
    username: 'journey_readonly',
    sslMode: 'require',
    status: 'error',
    timeoutSeconds: 30,
    maxConnections: 20,
    lastTestedAt: '2024-03-19T12:00:00Z',
    lastError: 'Connection timeout - network unreachable',
    createdBy: 'u1',
    createdAt: '2024-02-15T11:00:00Z',
    updatedAt: '2024-03-19T12:00:00Z',
    isActive: false,
    tags: ['loans', 'postgresql', 'maintenance'],
  },
  {
    id: 'ds7',
    name: 'Mobile App Analytics',
    description: 'MySQL database for mobile app user behavior',
    type: 'mysql',
    host: 'mobile-analytics.accessbank.local',
    port: 3306,
    database: 'mobile_app',
    username: 'analytics_user',
    sslMode: 'require',
    status: 'connected',
    timeoutSeconds: 20,
    maxConnections: 40,
    lastTestedAt: '2024-03-21T05:00:00Z',
    createdBy: 'u2',
    createdAt: '2024-03-01T09:00:00Z',
    updatedAt: '2024-03-21T05:00:00Z',
    isActive: true,
    tags: ['mobile', 'mysql', 'analytics'],
  },
  {
    id: 'ds8',
    name: 'AWS Redshift - Analytics',
    description: 'Redshift cluster for advanced analytics and reporting',
    type: 'redshift',
    host: 'accessbank-analytics.abc123.us-east-1.redshift.amazonaws.com',
    port: 5439,
    database: 'analytics',
    schema: 'public',
    username: 'journey_analytics',
    sslMode: 'require',
    status: 'disconnected',
    timeoutSeconds: 60,
    maxConnections: 15,
    lastTestedAt: '2024-03-18T10:00:00Z',
    createdBy: 'u1',
    createdAt: '2024-03-05T14:00:00Z',
    updatedAt: '2024-03-18T10:00:00Z',
    isActive: false,
    tags: ['redshift', 'aws', 'analytics'],
  },
];

// Rules
export const rules: Rule[] = [
  {
    id: 'r1',
    name: 'New Account Holders - First 30 Days',
    description: 'Customers who opened accounts within the last 30 days',
    type: 'entry',
    status: 'active',
    dataSourceId: 'ds1',
    sqlQuery: `SELECT DISTINCT 
  c.customer_id,
  c.email,
  c.first_name,
  c.last_name,
  c.phone,
  a.account_number,
  a.open_date
FROM customers c
JOIN accounts a ON c.customer_id = a.customer_id
WHERE a.open_date >= DATEADD(day, -30, GETDATE())
  AND a.account_type = 'SAVINGS'
  AND c.email IS NOT NULL
  AND c.consent_marketing = 1`,
    validatedAt: '2024-03-20T10:00:00Z',
    validatedBy: 'u2',
    validationResult: {
      valid: true,
      recordCount: 15420,
      sampleData: [
        { customer_id: 'C100001', email: 'john.doe@email.com', first_name: 'John', last_name: 'Doe', account_number: '4012345678', open_date: '2024-03-15' },
        { customer_id: 'C100002', email: 'jane.smith@email.com', first_name: 'Jane', last_name: 'Smith', account_number: '4012345679', open_date: '2024-03-14' },
      ],
      columns: ['customer_id', 'email', 'first_name', 'last_name', 'phone', 'account_number', 'open_date'],
    },
    estimatedRecordCount: 15420,
    executionTimeMs: 2450,
    createdBy: 'u2',
    createdAt: '2024-02-15T09:00:00Z',
    updatedAt: '2024-03-20T10:00:00Z',
    tags: ['onboarding', 'new-customers', 'savings'],
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
      { id: 'sp2', name: 'Row Limit', type: 'rowlimit', enabled: true, config: { maxRows: 100000 } },
    ],
  },
  {
    id: 'r2',
    name: 'Dormant Account Reactivation',
    description: 'Customers with dormant accounts who logged in recently',
    type: 'entry',
    status: 'active',
    dataSourceId: 'ds1',
    sqlQuery: `SELECT DISTINCT
  c.customer_id,
  c.email,
  c.first_name,
  c.last_name,
  a.account_number,
  DATEDIFF(day, a.last_transaction_date, GETDATE()) as days_dormant
FROM customers c
JOIN accounts a ON c.customer_id = a.customer_id
WHERE a.status = 'DORMANT'
  AND DATEDIFF(day, a.last_transaction_date, GETDATE()) BETWEEN 90 AND 180
  AND c.email IS NOT NULL
  AND c.consent_marketing = 1`,
    validatedAt: '2024-03-19T14:00:00Z',
    validatedBy: 'u2',
    validationResult: {
      valid: true,
      recordCount: 8750,
      sampleData: [
        { customer_id: 'C200001', email: 'mike@email.com', first_name: 'Mike', last_name: 'Johnson', account_number: '4023456789', days_dormant: 120 },
      ],
      columns: ['customer_id', 'email', 'first_name', 'last_name', 'account_number', 'days_dormant'],
    },
    estimatedRecordCount: 8750,
    executionTimeMs: 1890,
    createdBy: 'u2',
    createdAt: '2024-02-20T11:00:00Z',
    updatedAt: '2024-03-19T14:00:00Z',
    tags: ['dormant', 'reactivation', 'retention'],
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
    ],
  },
  {
    id: 'r3',
    name: 'High Value Customers - Gold Tier',
    description: 'Customers with total balance > 5M Naira',
    type: 'segment',
    status: 'active',
    dataSourceId: 'ds3',
    sqlQuery: `SELECT 
  c.customer_id,
  c.email,
  c.first_name,
  c.last_name,
  c.phone,
  SUM(a.balance) as total_balance
FROM customers c
JOIN accounts a ON c.customer_id = a.customer_id
WHERE a.balance > 5000000
  AND a.status = 'ACTIVE'
  AND c.email IS NOT NULL
GROUP BY c.customer_id, c.email, c.first_name, c.last_name, c.phone
HAVING SUM(a.balance) > 5000000`,
    validatedAt: '2024-03-18T09:30:00Z',
    validatedBy: 'u1',
    validationResult: {
      valid: true,
      recordCount: 3240,
      sampleData: [
        { customer_id: 'C500001', email: 'vip@email.com', first_name: 'VIP', last_name: 'Customer', total_balance: 8500000 },
      ],
      columns: ['customer_id', 'email', 'first_name', 'last_name', 'phone', 'total_balance'],
    },
    estimatedRecordCount: 3240,
    executionTimeMs: 3200,
    createdBy: 'u1',
    createdAt: '2024-03-01T10:00:00Z',
    updatedAt: '2024-03-18T09:30:00Z',
    tags: ['high-value', 'vip', 'gold-tier'],
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
    ],
  },
  {
    id: 'r4',
    name: 'Loan Eligibility - Salary Earners',
    description: 'Salary account holders eligible for personal loans',
    type: 'entry',
    status: 'draft',
    dataSourceId: 'ds6',
    sqlQuery: `SELECT 
  c.customer_id,
  c.email,
  c.first_name,
  c.last_name,
  c.monthly_income,
  c.employer_name
FROM customers c
WHERE c.account_type = 'SALARY'
  AND c.monthly_income >= 200000
  AND c.employment_status = 'EMPLOYED'
  AND DATEDIFF(month, c.employment_start_date, GETDATE()) >= 6
  AND c.email IS NOT NULL`,
    createdBy: 'u2',
    createdAt: '2024-03-10T14:00:00Z',
    updatedAt: '2024-03-10T14:00:00Z',
    tags: ['loans', 'salary', 'eligibility'],
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
    ],
  },
  {
    id: 'r5',
    name: 'Exit - Unsubscribed Customers',
    description: 'Remove customers who have unsubscribed from marketing',
    type: 'exit',
    status: 'active',
    dataSourceId: 'ds1',
    sqlQuery: `SELECT customer_id, email, unsubscribe_date
FROM customer_preferences
WHERE consent_marketing = 0
  AND unsubscribe_date >= DATEADD(day, -1, GETDATE())`,
    validatedAt: '2024-03-15T11:00:00Z',
    validatedBy: 'u2',
    validationResult: {
      valid: true,
      recordCount: 45,
      sampleData: [],
      columns: ['customer_id', 'email', 'unsubscribe_date'],
    },
    estimatedRecordCount: 45,
    executionTimeMs: 450,
    createdBy: 'u2',
    createdAt: '2024-03-05T09:00:00Z',
    updatedAt: '2024-03-15T11:00:00Z',
    tags: ['unsubscribe', 'exit', 'compliance'],
    isSafe: true,
    safetyPolicies: [
      { id: 'sp1', name: 'Read-Only', type: 'readonly', enabled: true },
    ],
  },
];

// Templates with Workflow Support
export const templates: Template[] = [
  {
    id: 't1',
    name: 'Welcome - New Savings Account',
    description: 'Welcome email for new savings account holders',
    type: 'email',
    status: 'active',
    workflowStage: 'approved',
    subject: 'Welcome to Access Bank, {{first_name}}!',
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .header { background: #062A78; padding: 20px; text-align: center; }
    .header img { max-width: 200px; }
    .content { padding: 30px; max-width: 600px; margin: 0 auto; }
    .cta { background: #F28A1A; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
    .footer { background: #f5f5f5; padding: 20px; text-align: center; font-size: 12px; color: #666; }
  </style>
</head>
<body>
  <div class="header">
    <img src="https://accessbankplc.com/logo.png" alt="Access Bank">
  </div>
  <div class="content">
    <h1>Welcome to Access Bank, {{first_name}}!</h1>
    <p>Dear {{first_name}} {{last_name}},</p>
    <p>Thank you for opening a Savings Account with us. Your account number is <strong>{{account_number}}</strong>.</p>
    <p>With your new account, you can:</p>
    <ul>
      <li>Enjoy competitive interest rates</li>
      <li>Access 24/7 mobile and internet banking</li>
      <li>Use over 600 branches and ATMs nationwide</li>
      <li>Get a free debit card</li>
    </ul>
    <a href="{{login_url}}" class="cta">Access Your Account</a>
    <p>If you have any questions, please contact us at 01-2712000 or visit any of our branches.</p>
    <p>Best regards,<br>Access Bank Team</p>
  </div>
  <div class="footer">
    <p>© 2024 Access Bank PLC. All rights reserved.</p>
    <p><a href="{{unsubscribe_url}}">Unsubscribe</a> | <a href="{{privacy_url}}">Privacy Policy</a></p>
  </div>
</body>
</html>`,
    textContent: 'Welcome to Access Bank, {{first_name}}! Your account {{account_number}} is now active.',
    variables: [
      { name: 'first_name', type: 'string', required: true },
      { name: 'last_name', type: 'string', required: true },
      { name: 'account_number', type: 'string', required: true },
      { name: 'login_url', type: 'string', required: true, defaultValue: 'https://online.accessbankplc.com' },
      { name: 'unsubscribe_url', type: 'string', required: true },
      { name: 'privacy_url', type: 'string', required: true, defaultValue: 'https://accessbankplc.com/privacy' },
    ],
    previewData: {
      first_name: 'John',
      last_name: 'Doe',
      account_number: '4012345678',
      login_url: 'https://online.accessbankplc.com',
      unsubscribe_url: 'https://accessbankplc.com/unsubscribe',
      privacy_url: 'https://accessbankplc.com/privacy',
    },
    createdBy: 'u2',
    createdByName: 'Journey Developer',
    createdAt: '2024-02-01T10:00:00Z',
    updatedAt: '2024-03-15T14:00:00Z',
    tags: ['welcome', 'onboarding', 'savings'],
    category: 'Onboarding',
    comments: [],
    auditHistory: [],
    brandGuidelinesCompliant: true,
    legalApproved: true,
  },
  {
    id: 't2',
    name: 'Reactivate Your Account',
    description: 'Email to encourage dormant account holders to reactivate',
    type: 'email',
    status: 'active',
    workflowStage: 'approved',
    subject: '{{first_name}}, we miss you! Reactivate your account',
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .header { background: #062A78; padding: 20px; text-align: center; }
    .content { padding: 30px; max-width: 600px; margin: 0 auto; }
    .cta { background: #F28A1A; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
    .highlight { background: #fff3e0; padding: 15px; border-left: 4px solid #F28A1A; margin: 20px 0; }
  </style>
</head>
<body>
  <div class="header">
    <img src="https://accessbankplc.com/logo.png" alt="Access Bank">
  </div>
  <div class="content">
    <h1>We Miss You, {{first_name}}!</h1>
    <p>Your account <strong>{{account_number}}</strong> has been inactive for {{days_dormant}} days.</p>
    <div class="highlight">
      <h3>Reactivate now and get:</h3>
      <ul>
        <li>₦1,000 bonus on your first transaction</li>
        <li>Free debit card replacement</li>
        <li>Waived account maintenance fees for 3 months</li>
      </ul>
    </div>
    <a href="{{reactivate_url}}" class="cta">Reactivate My Account</a>
    <p>Offer valid until {{offer_expiry}}.</p>
  </div>
</body>
</html>`,
    variables: [
      { name: 'first_name', type: 'string', required: true },
      { name: 'account_number', type: 'string', required: true },
      { name: 'days_dormant', type: 'number', required: true },
      { name: 'reactivate_url', type: 'string', required: true },
      { name: 'offer_expiry', type: 'date', required: true },
    ],
    previewData: {
      first_name: 'Mike',
      account_number: '4023456789',
      days_dormant: '120',
      reactivate_url: 'https://online.accessbankplc.com/reactivate',
      offer_expiry: '2024-04-30',
    },
    createdBy: 'u2',
    createdByName: 'Journey Developer',
    createdAt: '2024-02-15T11:00:00Z',
    updatedAt: '2024-03-10T09:00:00Z',
    tags: ['reactivation', 'dormant', 'retention'],
    category: 'Retention',
    comments: [],
    auditHistory: [],
    brandGuidelinesCompliant: true,
    legalApproved: true,
  },
  {
    id: 't3',
    name: 'Exclusive Gold Tier Benefits',
    description: 'VIP email for high-value customers',
    type: 'email',
    status: 'active',
    workflowStage: 'approved',
    subject: 'Your Exclusive Gold Tier Benefits Await',
    htmlContent: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .header { background: linear-gradient(135deg, #062A78 0%, #F28A1A 100%); padding: 30px; text-align: center; color: white; }
    .content { padding: 30px; max-width: 600px; margin: 0 auto; }
    .benefit { background: #f9f9f9; padding: 20px; margin: 15px 0; border-radius: 8px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Gold Tier Exclusive</h1>
    <p>Premium Banking for Premium Customers</p>
  </div>
  <div class="content">
    <p>Dear {{first_name}},</p>
    <p>As a valued customer with a portfolio of ₦{{total_balance}}, you now qualify for our exclusive Gold Tier benefits:</p>
    <div class="benefit">
      <h3>🏆 Dedicated Relationship Manager</h3>
      <p>Personalized service and financial advice</p>
    </div>
    <div class="benefit">
      <h3>💳 Priority Banking</h3>
      <p>Skip the queue at all branches</p>
    </div>
    <div class="benefit">
      <h3>✈️ Lounge Access</h3>
      <p>Complimentary airport lounge access worldwide</p>
    </div>
    <p><a href="{{benefits_url}}" style="background: #F28A1A; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">View All Benefits</a></p>
  </div>
</body>
</html>`,
    variables: [
      { name: 'first_name', type: 'string', required: true },
      { name: 'total_balance', type: 'number', required: true },
      { name: 'benefits_url', type: 'string', required: true },
    ],
    previewData: {
      first_name: 'VIP',
      total_balance: '8500000',
      benefits_url: 'https://accessbankplc.com/gold-benefits',
    },
    createdBy: 'u1',
    createdByName: 'System Administrator',
    createdAt: '2024-03-05T14:00:00Z',
    updatedAt: '2024-03-12T10:00:00Z',
    tags: ['vip', 'gold', 'high-value'],
    category: 'VIP',
    comments: [],
    auditHistory: [],
    brandGuidelinesCompliant: true,
    legalApproved: true,
  },
];

// Journeys with Workflow Support
export const journeys: Journey[] = [
  {
    id: 'j1',
    name: 'New Account Onboarding',
    description: 'Welcome journey for new savings account holders with educational content and product recommendations',
    lifecycleStage: 'ACQUIRE',
    workflowStage: 'live',
    status: 'running',
    priority: 'high',
    createdBy: 'u6',
    createdByName: 'Marketing Manager',
    createdAt: '2024-02-01T09:00:00Z',
    updatedAt: '2024-03-20T10:00:00Z',
    scheduledAt: '2024-03-01T00:00:00Z',
    startedAt: '2024-03-01T00:00:00Z',
    entryRuleId: 'r1',
    templateId: 't1',
    templateName: 'Welcome - New Savings Account',
    controlGroup: { enabled: true, percentage: 10, description: '10% control group for effectiveness measurement' },
    approvalStatus: 'approved',
    approvalHistory: [
      { stage: 'pending_dev', action: 'submitted', by: 'u2', at: '2024-02-20T14:00:00Z' },
      { stage: 'pending_comms', action: 'approved', by: 'u3', at: '2024-02-22T11:00:00Z', notes: 'Content approved with minor changes' },
      { stage: 'pending_compliance', action: 'approved', by: 'u4', at: '2024-02-25T16:00:00Z' },
    ],
    comments: sampleComments,
    auditHistory: sampleAuditEntries,
    estimatedReach: 15000,
    actualReach: 15420,
    conversionRate: 23.5,
    tags: ['onboarding', 'welcome', 'savings'],
    category: 'Onboarding',
    stageEnteredAt: '2024-03-01T00:00:00Z',
  },
  {
    id: 'j2',
    name: 'Dormant Account Reactivation',
    description: 'Win-back campaign for customers with dormant accounts',
    lifecycleStage: 'WIN_BACK',
    workflowStage: 'live',
    status: 'running',
    priority: 'high',
    createdBy: 'u6',
    createdByName: 'Marketing Manager',
    createdAt: '2024-02-15T10:00:00Z',
    updatedAt: '2024-03-19T14:00:00Z',
    scheduledAt: '2024-03-15T00:00:00Z',
    startedAt: '2024-03-15T00:00:00Z',
    entryRuleId: 'r2',
    templateId: 't2',
    templateName: 'Reactivate Your Account',
    controlGroup: { enabled: true, percentage: 5, description: '5% control group' },
    approvalStatus: 'approved',
    approvalHistory: [
      { stage: 'pending_dev', action: 'submitted', by: 'u2', at: '2024-03-05T09:00:00Z' },
      { stage: 'pending_comms', action: 'approved', by: 'u3', at: '2024-03-08T14:00:00Z' },
      { stage: 'pending_compliance', action: 'approved', by: 'u4', at: '2024-03-12T10:00:00Z' },
    ],
    comments: [
      {
        id: 'wc6',
        stage: 'intake',
        userId: 'u6',
        userName: 'Marketing Manager',
        userRole: 'admin',
        comment: 'Need to reactivate dormant accounts. Target accounts inactive for 90-180 days.',
        timestamp: '2024-02-15T10:00:00Z',
        action: 'submit',
      },
      {
        id: 'wc7',
        stage: 'cx_review',
        userId: 'u3',
        userName: 'Communications Reviewer',
        userRole: 'comms',
        comment: 'Approved. The incentive offer (₦1,000 bonus) is compelling.',
        timestamp: '2024-03-08T14:00:00Z',
        action: 'approve',
      },
    ],
    auditHistory: [
      {
        id: 'ae6',
        timestamp: '2024-02-15T10:00:00Z',
        userId: 'u6',
        userName: 'Marketing Manager',
        userRole: 'admin',
        action: 'submit',
        toStage: 'intake',
      },
      {
        id: 'ae7',
        timestamp: '2024-03-15T00:00:00Z',
        userId: 'system',
        userName: 'System',
        userRole: 'super_admin',
        action: 'submit',
        fromStage: 'control_review',
        toStage: 'live',
      },
    ],
    estimatedReach: 8000,
    actualReach: 8750,
    conversionRate: 18.2,
    tags: ['dormant', 'reactivation', 'win-back'],
    category: 'Retention',
    stageEnteredAt: '2024-03-15T00:00:00Z',
  },
  {
    id: 'j3',
    name: 'Gold Tier Upgrade Notification',
    description: 'Notify customers who qualify for Gold Tier status',
    lifecycleStage: 'GROW',
    workflowStage: 'approved',
    status: 'approved',
    priority: 'medium',
    createdBy: 'u1',
    createdByName: 'System Administrator',
    createdAt: '2024-03-01T11:00:00Z',
    updatedAt: '2024-03-18T09:30:00Z',
    scheduledAt: '2024-03-25T00:00:00Z',
    entryRuleId: 'r3',
    templateId: 't3',
    templateName: 'Exclusive Gold Tier Benefits',
    controlGroup: { enabled: false, percentage: 0, description: '' },
    approvalStatus: 'approved',
    approvalHistory: [
      { stage: 'pending_dev', action: 'submitted', by: 'u1', at: '2024-03-10T14:00:00Z' },
      { stage: 'pending_comms', action: 'approved', by: 'u3', at: '2024-03-14T11:00:00Z' },
      { stage: 'pending_compliance', action: 'approved', by: 'u4', at: '2024-03-18T09:30:00Z' },
    ],
    comments: [
      {
        id: 'wc8',
        stage: 'control_review',
        userId: 'u4',
        userName: 'Compliance Officer',
        userRole: 'compliance',
        comment: 'Approved. Ensure we have consent for premium service communications.',
        timestamp: '2024-03-18T09:30:00Z',
        action: 'approve',
      },
    ],
    auditHistory: [
      {
        id: 'ae8',
        timestamp: '2024-03-18T09:30:00Z',
        userId: 'u4',
        userName: 'Compliance Officer',
        userRole: 'compliance',
        action: 'approve',
        fromStage: 'cx_review',
        toStage: 'control_review',
      },
    ],
    estimatedReach: 3000,
    actualReach: 0,
    conversionRate: 0,
    tags: ['vip', 'gold', 'upgrade'],
    category: 'VIP',
    stageEnteredAt: '2024-03-18T09:30:00Z',
    slaDeadline: '2024-03-25T00:00:00Z',
  },
  {
    id: 'j4',
    name: 'Loan Pre-Approval Campaign',
    description: 'Target salary earners with pre-approved loan offers',
    lifecycleStage: 'GROW',
    workflowStage: 'intake',
    status: 'draft',
    priority: 'high',
    createdBy: 'u2',
    createdByName: 'Journey Developer',
    createdAt: '2024-03-10T14:00:00Z',
    updatedAt: '2024-03-10T14:00:00Z',
    entryRuleId: 'r4',
    approvalStatus: 'pending_dev',
    approvalHistory: [],
    comments: [],
    auditHistory: [],
    estimatedReach: 25000,
    actualReach: 0,
    conversionRate: 0,
    tags: ['loans', 'pre-approval', 'salary'],
    category: 'Marketing',
  },
  {
    id: 'j5',
    name: 'Monthly Statement Reminder',
    description: 'Reminder to check monthly statements',
    lifecycleStage: 'ENGAGE',
    workflowStage: 'approved',
    status: 'scheduled',
    priority: 'low',
    createdBy: 'u2',
    createdByName: 'Journey Developer',
    createdAt: '2024-03-05T09:00:00Z',
    updatedAt: '2024-03-15T11:00:00Z',
    scheduledAt: '2024-04-01T09:00:00Z',
    approvalStatus: 'approved',
    approvalHistory: [
      { stage: 'pending_dev', action: 'submitted', by: 'u2', at: '2024-03-10T10:00:00Z' },
      { stage: 'pending_comms', action: 'approved', by: 'u3', at: '2024-03-12T14:00:00Z' },
      { stage: 'pending_compliance', action: 'approved', by: 'u4', at: '2024-03-15T11:00:00Z' },
    ],
    comments: [],
    auditHistory: [],
    estimatedReach: 500000,
    actualReach: 0,
    conversionRate: 0,
    tags: ['statements', 'monthly', 'engagement'],
    category: 'Transactional',
    stageEnteredAt: '2024-03-15T11:00:00Z',
  },
];

// Journey Runs
export const journeyRuns: JourneyRun[] = [
  {
    id: 'run1',
    journeyId: 'j1',
    journeyName: 'New Account Onboarding',
    status: 'completed',
    startedAt: '2024-03-01T00:00:00Z',
    completedAt: '2024-03-01T06:30:00Z',
    totalRecords: 15420,
    processedRecords: 15420,
    successfulSends: 15200,
    failedSends: 220,
    bounced: 45,
    opened: 6080,
    clicked: 2432,
    unsubscribed: 12,
    complained: 2,
    executionLogs: [
      { timestamp: '2024-03-01T00:00:00Z', level: 'info', message: 'Journey run started' },
      { timestamp: '2024-03-01T00:05:00Z', level: 'info', message: 'Rule execution completed: 15,420 records identified' },
      { timestamp: '2024-03-01T06:30:00Z', level: 'info', message: 'All emails sent successfully' },
    ],
    triggeredBy: 'system',
    dataSourceId: 'ds1',
  },
  {
    id: 'run2',
    journeyId: 'j2',
    journeyName: 'Dormant Account Reactivation',
    status: 'running',
    startedAt: '2024-03-15T00:00:00Z',
    totalRecords: 8750,
    processedRecords: 6000,
    successfulSends: 5950,
    failedSends: 50,
    bounced: 15,
    opened: 1785,
    clicked: 595,
    unsubscribed: 5,
    complained: 0,
    executionLogs: [
      { timestamp: '2024-03-15T00:00:00Z', level: 'info', message: 'Journey run started' },
      { timestamp: '2024-03-15T00:10:00Z', level: 'info', message: 'Processing batch 1 of 9' },
      { timestamp: '2024-03-15T03:00:00Z', level: 'info', message: 'Processing batch 5 of 9' },
    ],
    triggeredBy: 'system',
    dataSourceId: 'ds1',
  },
  {
    id: 'run3',
    journeyId: 'j1',
    journeyName: 'New Account Onboarding',
    status: 'completed',
    startedAt: '2024-02-15T00:00:00Z',
    completedAt: '2024-02-15T05:45:00Z',
    totalRecords: 12300,
    processedRecords: 12300,
    successfulSends: 12150,
    failedSends: 150,
    bounced: 30,
    opened: 4860,
    clicked: 1944,
    unsubscribed: 8,
    complained: 1,
    executionLogs: [
      { timestamp: '2024-02-15T00:00:00Z', level: 'info', message: 'Journey run started' },
      { timestamp: '2024-02-15T05:45:00Z', level: 'info', message: 'Journey run completed' },
    ],
    triggeredBy: 'system',
    dataSourceId: 'ds1',
  },
];

// SMTP Configurations
export const smtpConfigs: SMTPConfig[] = [
  {
    id: 'smtp1',
    name: 'Primary SMTP - Lagos',
    host: 'smtp-lagos.accessbank.local',
    port: 587,
    username: 'journey@accessbankplc.com',
    password: '********',
    encryption: 'tls',
    fromEmail: 'noreply@accessbankplc.com',
    fromName: 'Access Bank',
    isDefault: true,
    isActive: true,
    testStatus: 'success',
  },
  {
    id: 'smtp2',
    name: 'Backup SMTP - Abuja',
    host: 'smtp-abuja.accessbank.local',
    port: 587,
    username: 'backup@accessbankplc.com',
    password: '********',
    encryption: 'tls',
    fromEmail: 'noreply@accessbankplc.com',
    fromName: 'Access Bank',
    isDefault: false,
    isActive: true,
    testStatus: 'success',
  },
  {
    id: 'smtp3',
    name: 'Marketing SMTP',
    host: 'smtp-marketing.accessbank.local',
    port: 465,
    username: 'marketing@accessbankplc.com',
    password: '********',
    encryption: 'ssl',
    fromEmail: 'marketing@accessbankplc.com',
    fromName: 'Access Bank Marketing',
    isDefault: false,
    isActive: true,
    testStatus: 'success',
  },
];

// Mailboxes
export const mailboxes: Mailbox[] = [
  {
    id: 'mb1',
    email: 'noreply@accessbankplc.com',
    name: 'No Reply',
    department: 'IT Operations',
    smtpConfigId: 'smtp1',
    isActive: true,
    dailyLimit: 10000,
    sentToday: 15420,
    createdAt: '2024-01-15T10:00:00Z',
    inRotationPool: true,
    rotationPriority: 1,
    lastUsedAt: '2024-03-21T10:00:00Z',
  },
  {
    id: 'mb2',
    email: 'marketing@accessbankplc.com',
    name: 'Marketing Team',
    department: 'Marketing',
    smtpConfigId: 'smtp3',
    isActive: true,
    dailyLimit: 10000,
    sentToday: 8750,
    createdAt: '2024-02-01T11:00:00Z',
    inRotationPool: true,
    rotationPriority: 2,
    lastUsedAt: '2024-03-21T09:30:00Z',
  },
  {
    id: 'mb3',
    email: 'support@accessbankplc.com',
    name: 'Customer Support',
    department: 'Customer Service',
    smtpConfigId: 'smtp1',
    isActive: true,
    dailyLimit: 10000,
    sentToday: 3200,
    createdAt: '2024-02-15T09:00:00Z',
    inRotationPool: true,
    rotationPriority: 3,
    lastUsedAt: '2024-03-21T08:00:00Z',
  },
  {
    id: 'mb4',
    email: 'info@accessbankplc.com',
    name: 'Info Mailbox',
    department: 'Customer Service',
    smtpConfigId: 'smtp1',
    isActive: true,
    dailyLimit: 10000,
    sentToday: 1500,
    createdAt: '2024-02-20T10:00:00Z',
    inRotationPool: true,
    rotationPriority: 4,
    lastUsedAt: '2024-03-21T07:00:00Z',
  },
  {
    id: 'mb5',
    email: 'alerts@accessbankplc.com',
    name: 'Alerts System',
    department: 'IT Operations',
    smtpConfigId: 'smtp2',
    isActive: true,
    dailyLimit: 10000,
    sentToday: 4200,
    createdAt: '2024-03-01T09:00:00Z',
    inRotationPool: true,
    rotationPriority: 5,
    lastUsedAt: '2024-03-21T06:00:00Z',
  },
];

// Email Rotation Configuration
export const emailRotationConfigs = [
  {
    id: 'rot1',
    name: 'High Volume Journey Rotation',
    description: 'Rotates emails across multiple mailboxes when sending exceeds 10,000 emails to prevent flagging',
    enabled: true,
    rotationThreshold: 10000,
    rotationStrategy: 'round_robin' as const,
    batchSize: 1000,
    cooldownMinutes: 5,
    mailboxIds: ['mb1', 'mb2', 'mb3', 'mb4', 'mb5'],
    maxEmailsPerMailboxPerHour: 2000,
    maxEmailsPerMailboxPerDay: 10000,
    pauseOnHighBounceRate: true,
    bounceRateThreshold: 5,
    pauseOnHighComplaintRate: true,
    complaintRateThreshold: 0.1,
    activeHoursStart: '08:00',
    activeHoursEnd: '20:00',
    respectMailboxLimits: true,
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-03-21T08:00:00Z',
    createdBy: 'u1',
  },
];

// Email Aliases
export const emailAliases: EmailAlias[] = [
  {
    id: 'ea1',
    alias: 'info@accessbankplc.com',
    targetEmail: 'marketing@accessbankplc.com',
    description: 'General inquiries',
    isActive: true,
    createdAt: '2024-01-20T10:00:00Z',
  },
  {
    id: 'ea2',
    alias: 'feedback@accessbankplc.com',
    targetEmail: 'support@accessbankplc.com',
    description: 'Customer feedback',
    isActive: true,
    createdAt: '2024-02-01T14:00:00Z',
  },
  {
    id: 'ea3',
    alias: 'promo@accessbankplc.com',
    targetEmail: 'marketing@accessbankplc.com',
    description: 'Promotional emails',
    isActive: false,
    createdAt: '2024-03-01T09:00:00Z',
  },
];

// Activity Logs
export const activityLogs: ActivityLog[] = [
  {
    id: 'al1',
    userId: 'u2',
    userName: 'Journey Developer',
    action: 'Created journey',
    entityType: 'journey',
    entityId: 'j4',
    entityName: 'Loan Pre-Approval Campaign',
    timestamp: '2024-03-10T14:00:00Z',
  },
  {
    id: 'al2',
    userId: 'u3',
    userName: 'Communications Reviewer',
    action: 'Approved journey',
    entityType: 'journey',
    entityId: 'j3',
    entityName: 'Gold Tier Upgrade Notification',
    timestamp: '2024-03-14T11:00:00Z',
  },
  {
    id: 'al3',
    userId: 'u1',
    userName: 'System Administrator',
    action: 'Tested data source connection',
    entityType: 'datasource',
    entityId: 'ds1',
    entityName: '360 Data Store - Production',
    timestamp: '2024-03-21T08:00:00Z',
  },
  {
    id: 'al4',
    userId: 'u2',
    userName: 'Journey Developer',
    action: 'Validated rule',
    entityType: 'rule',
    entityId: 'r1',
    entityName: 'New Account Holders - First 30 Days',
    timestamp: '2024-03-20T10:00:00Z',
  },
  {
    id: 'al5',
    userId: 'u4',
    userName: 'Compliance Officer',
    action: 'Approved journey',
    entityType: 'journey',
    entityId: 'j2',
    entityName: 'Dormant Account Reactivation',
    timestamp: '2024-03-12T10:00:00Z',
  },
];

// Dashboard Stats
export const dashboardStats: DashboardStats = {
  totalJourneys: 24,
  activeJourneys: 8,
  totalRuns: 156,
  emailsSent: 2450000,
  deliveryRate: 98.5,
  openRate: 24.3,
  clickRate: 8.7,
  pendingApprovals: 3,
  activeRules: 18,
  connectedDataSources: 6,
};

// Report Metrics (last 30 days)
export const reportMetrics: ReportMetric[] = Array.from({ length: 30 }, (_, i) => {
  const date = new Date();
  date.setDate(date.getDate() - (29 - i));
  return {
    date: date.toISOString().split('T')[0],
    journeysRun: Math.floor(Math.random() * 10) + 2,
    emailsSent: Math.floor(Math.random() * 50000) + 20000,
    emailsDelivered: Math.floor(Math.random() * 49000) + 20000,
    openRate: Math.random() * 10 + 20,
    clickRate: Math.random() * 5 + 5,
    bounceRate: Math.random() * 2 + 0.5,
    unsubscribeRate: Math.random() * 0.5 + 0.1,
    complaintRate: Math.random() * 0.1 + 0.01,
  };
});

// Journey Performance
export const journeyPerformance: JourneyPerformance[] = [
  {
    journeyId: 'j1',
    journeyName: 'New Account Onboarding',
    stage: 'ACQUIRE',
    runs: 12,
    totalSent: 175000,
    delivered: 172375,
    opened: 44818,
    clicked: 14939,
    converted: 41183,
    roi: 4.2,
  },
  {
    journeyId: 'j2',
    journeyName: 'Dormant Account Reactivation',
    stage: 'WIN_BACK',
    runs: 8,
    totalSent: 65000,
    delivered: 63975,
    opened: 15354,
    clicked: 5118,
    converted: 11643,
    roi: 3.8,
  },
  {
    journeyId: 'j3',
    journeyName: 'Gold Tier Upgrade Notification',
    stage: 'GROW',
    runs: 4,
    totalSent: 12000,
    delivered: 11820,
    opened: 4373,
    clicked: 1891,
    converted: 2364,
    roi: 5.5,
  },
];
