/// <reference types="vite/client" />
// API Service - connects the frontend to the backend
// All calls go through here instead of mockData

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

// ─── Token Management ────────────────────────────────────────────────────────

let accessToken: string | null = localStorage.getItem('accessToken');
let refreshToken: string | null = localStorage.getItem('refreshToken');

export const setTokens = (tokens: { accessToken: string; refreshToken: string }) => {
  accessToken = tokens.accessToken;
  refreshToken = tokens.refreshToken;
  localStorage.setItem('accessToken', tokens.accessToken);
  localStorage.setItem('refreshToken', tokens.refreshToken);
};

export const clearTokens = () => {
  accessToken = null;
  refreshToken = null;
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
};

export const getAccessToken = () => accessToken;

// ─── Core Fetch ───────────────────────────────────────────────────────────────

async function apiFetch<T = any>(
  path: string,
  options: RequestInit = {},
  retry = true
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });

  // Token expired — try refresh once
  if (res.status === 401 && retry && refreshToken) {
    const refreshed = await tryRefreshToken();
    if (refreshed) {
      return apiFetch(path, options, false);
    } else {
      clearTokens();
      window.location.href = '/';
      throw new Error('Session expired');
    }
  }

  const data = await res.json().catch(() => ({ success: false, message: res.statusText }));

  if (!res.ok) {
    throw new Error(data.message || `Request failed: ${res.status}`);
  }

  return data;
}

async function tryRefreshToken(): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/api/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    if (!res.ok) return false;
    const data = await res.json();
    if (data.data?.tokens) {
      setTokens(data.data.tokens);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

// Helpers
const get = <T = any>(path: string) => apiFetch<T>(path);
const post = <T = any>(path: string, body?: any) => apiFetch<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined });
const put = <T = any>(path: string, body?: any) => apiFetch<T>(path, { method: 'PUT', body: body ? JSON.stringify(body) : undefined });
const del = <T = any>(path: string) => apiFetch<T>(path, { method: 'DELETE' });

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const authApi = {
  login: async (email: string, password: string) => {
    const data = await post('/api/auth/login', { email, password });
    if (data.data?.tokens) setTokens(data.data.tokens);
    return data;
  },
  logout: async () => {
    await post('/api/auth/logout').catch(() => {});
    clearTokens();
  },
  me: () => get('/api/auth/me'),
  changePassword: (oldPassword: string, newPassword: string) =>
    post('/api/auth/change-password', { oldPassword, newPassword }),
  forgotPassword: (email: string) =>
    post('/api/auth/forgot-password', { email }),
  resetPassword: (token: string, newPassword: string) =>
    post('/api/auth/reset-password', { token, newPassword }),
};

// ─── Users ────────────────────────────────────────────────────────────────────

export const usersApi = {
  getAll: (params?: Record<string, any>) =>
    get(`/api/users?${new URLSearchParams(params).toString()}`),
  getById: (id: string) => get(`/api/users/${id}`),
  create: (data: any) => post('/api/users', data),
  update: (id: string, data: any) => put(`/api/users/${id}`, data),
  delete: (id: string) => del(`/api/users/${id}`),
  unlock: (id: string) => post(`/api/users/${id}/unlock`),
  resetPassword: (id: string) => post(`/api/users/${id}/reset-password`),
  getSessions: (id: string) => get(`/api/users/${id}/sessions`),
  revokeSessions: (id: string) => del(`/api/users/${id}/sessions`),
};

// ─── Journeys ─────────────────────────────────────────────────────────────────

export const journeysApi = {
  getAll: (params?: Record<string, any>) =>
    get(`/api/journeys?${new URLSearchParams(params).toString()}`),
  getStats: () => get('/api/journeys/stats'),
  getById: (id: string) => get(`/api/journeys/${id}`),
  create: (data: any) => post('/api/journeys', data),
  update: (id: string, data: any) => put(`/api/journeys/${id}`, data),
  delete: (id: string) => del(`/api/journeys/${id}`),
  transition: (id: string, status: string, notes?: string) =>
    post(`/api/journeys/${id}/transition`, { status, notes }),
  schedule: (id: string, scheduledAt: string) =>
    post(`/api/journeys/${id}/schedule`, { scheduledAt }),
  duplicate: (id: string) => post(`/api/journeys/${id}/duplicate`),
  getComments: (id: string) => get(`/api/journeys/${id}/comments`),
  addComment: (id: string, content: string, type?: string) =>
    post(`/api/journeys/${id}/comments`, { content, type }),
  getRuns: (id: string) => get(`/api/journeys/${id}/runs`),
  getAudit: (id: string) => get(`/api/journeys/${id}/audit`),
};

// ─── Rules ────────────────────────────────────────────────────────────────────

export const rulesApi = {
  getAll: (params?: Record<string, any>) =>
    get(`/api/rules?${new URLSearchParams(params).toString()}`),
  getById: (id: string) => get(`/api/rules/${id}`),
  create: (data: any) => post('/api/rules', data),
  update: (id: string, data: any) => put(`/api/rules/${id}`, data),
  delete: (id: string) => del(`/api/rules/${id}`),
  activate: (id: string) => post(`/api/rules/${id}/activate`),
  deactivate: (id: string) => post(`/api/rules/${id}/deactivate`),
  test: (id: string) => post(`/api/rules/${id}/test`),
};

// ─── Templates ────────────────────────────────────────────────────────────────

export const templatesApi = {
  getAll: (params?: Record<string, any>) =>
    get(`/api/templates?${new URLSearchParams(params).toString()}`),
  getById: (id: string) => get(`/api/templates/${id}`),
  create: (data: any) => post('/api/templates', data),
  update: (id: string, data: any) => put(`/api/templates/${id}`, data),
  delete: (id: string) => del(`/api/templates/${id}`),
  review: (id: string, approved: boolean, reason?: string) =>
    post(`/api/templates/${id}/review`, { approved, reason }),
  preview: (id: string, variables?: Record<string, any>) =>
    post(`/api/templates/${id}/preview`, { variables }),
  duplicate: (id: string) => post(`/api/templates/${id}/duplicate`),
};

// ─── Data Sources ─────────────────────────────────────────────────────────────

export const dataSourcesApi = {
  getAll: (params?: Record<string, any>) =>
    get(`/api/datasources?${new URLSearchParams(params).toString()}`),
  getById: (id: string) => get(`/api/datasources/${id}`),
  create: (data: any) => post('/api/datasources', data),
  update: (id: string, data: any) => put(`/api/datasources/${id}`, data),
  delete: (id: string) => del(`/api/datasources/${id}`),
  test: (id: string) => post(`/api/datasources/${id}/test`),
  toggle: (id: string) => post(`/api/datasources/${id}/toggle`),
};

// ─── Reports ──────────────────────────────────────────────────────────────────

export const reportsApi = {
  getOverview: () => get('/api/reports/overview'),
  getJourneyReport: (params?: Record<string, any>) =>
    get(`/api/reports/journeys?${new URLSearchParams(params).toString()}`),
  getUserReport: () => get('/api/reports/users'),
  getActivityLog: (params?: Record<string, any>) =>
    get(`/api/reports/activity?${new URLSearchParams(params).toString()}`),
  getAuditLog: (params?: Record<string, any>) =>
    get(`/api/reports/audit?${new URLSearchParams(params).toString()}`),
  getEmailReport: () => get('/api/reports/email'),
  exportJourneys: () => `${API_URL}/api/reports/export/journeys?token=${accessToken}`,
  exportUsers: () => `${API_URL}/api/reports/export/users?token=${accessToken}`,
};

// ─── Workflow ─────────────────────────────────────────────────────────────────

export const workflowApi = {
  getStages: () => get('/api/workflows/stages'),
  getHistory: (journeyId: string) => get(`/api/workflows/journeys/${journeyId}/history`),
  submit: (journeyId: string, notes?: string) =>
    post(`/api/workflows/journeys/${journeyId}/submit`, { notes }),
  approve: (journeyId: string, notes?: string) =>
    post(`/api/workflows/journeys/${journeyId}/approve`, { notes }),
  reject: (journeyId: string, reason: string) =>
    post(`/api/workflows/journeys/${journeyId}/reject`, { reason }),
  requestChanges: (journeyId: string, comment: string) =>
    post(`/api/workflows/journeys/${journeyId}/request-changes`, { comment }),
  addComment: (journeyId: string, content: string, type?: string) =>
    post(`/api/workflows/journeys/${journeyId}/comments`, { content, type }),
  getComments: (journeyId: string) =>
    get(`/api/workflows/journeys/${journeyId}/comments`),
};

// ─── Admin ────────────────────────────────────────────────────────────────────

export const adminApi = {
  getStats: () => get('/api/admin/stats'),
  getHealth: () => get('/api/admin/health'),
  // Email configs
  getEmailConfigs: () => get('/api/admin/email-configs'),
  createEmailConfig: (data: any) => post('/api/admin/email-configs', data),
  updateEmailConfig: (id: string, data: any) => put(`/api/admin/email-configs/${id}`, data),
  deleteEmailConfig: (id: string) => del(`/api/admin/email-configs/${id}`),
  testEmailConfig: (id: string) => post(`/api/admin/email-configs/${id}/test`),
  setDefaultEmailConfig: (id: string) => post(`/api/admin/email-configs/${id}/set-default`),
  // Email aliases
  getEmailAliases: () => get('/api/admin/email-aliases'),
  createEmailAlias: (data: any) => post('/api/admin/email-aliases', data),
  updateEmailAlias: (id: string, data: any) => put(`/api/admin/email-aliases/${id}`, data),
  deleteEmailAlias: (id: string) => del(`/api/admin/email-aliases/${id}`),
  toggleEmailAlias: (id: string) => post(`/api/admin/email-aliases/${id}/toggle`),
  // Sessions
  getActiveSessions: () => get('/api/admin/sessions'),
  revokeSession: (id: string) => del(`/api/admin/sessions/${id}`),
  // Logs
  getActivity: (params?: Record<string, any>) =>
    get(`/api/admin/activity?${new URLSearchParams(params).toString()}`),
  getAudit: (params?: Record<string, any>) =>
    get(`/api/admin/audit?${new URLSearchParams(params).toString()}`),
};

export default {
  auth: authApi,
  users: usersApi,
  journeys: journeysApi,
  rules: rulesApi,
  templates: templatesApi,
  dataSources: dataSourcesApi,
  reports: reportsApi,
  workflow: workflowApi,
  admin: adminApi,
};
