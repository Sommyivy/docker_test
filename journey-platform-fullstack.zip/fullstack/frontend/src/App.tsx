import { useAppStore } from '@/store/appStore';
import { Login } from '@/pages/Login';
import { MainLayout } from '@/components/layout/MainLayout';
import { OverviewModule } from '@/sections/OverviewModule';
import { JourneysModule } from '@/sections/JourneysModule';
import { RulesModule } from '@/sections/RulesModule';
import { TemplatesModule } from '@/sections/TemplatesModule';
import { DataSourcesModule } from '@/sections/DataSourcesModule';
import { RunsModule } from '@/sections/RunsModule';
import { AdminModule } from '@/sections/AdminModule';
import { UsersModule } from '@/sections/UsersModule';
import { ReportsModule } from '@/sections/ReportsModule';
import { Toaster } from '@/components/ui/sonner';

function App() {
  const { isAuthenticated, activeModule } = useAppStore();

  if (!isAuthenticated) {
    return (
      <>
        <Login />
        <Toaster position="top-right" />
      </>
    );
  }

  const renderModule = () => {
    switch (activeModule) {
      case 'overview':
        return <OverviewModule />;
      case 'journeys':
        return <JourneysModule />;
      case 'rules':
        return <RulesModule />;
      case 'templates':
        return <TemplatesModule />;
      case 'datasources':
        return <DataSourcesModule />;
      case 'runs':
        return <RunsModule />;
      case 'admin':
        return <AdminModule />;
      case 'users':
        return <UsersModule />;
      case 'reports':
        return <ReportsModule />;
      default:
        return <OverviewModule />;
    }
  };

  return (
    <>
      <MainLayout>{renderModule()}</MainLayout>
      <Toaster position="top-right" />
    </>
  );
}

export default App;
