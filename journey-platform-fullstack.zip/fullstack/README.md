# Access Bank Customer Journey Engagement Platform

A comprehensive, workflow-based customer journey management solution for Access Bank PLC.

## Features

### Core Functionality
- **Customer Lifecycle Management**: ACQUIRE → ACTIVATE → ENGAGE → GROW → RETAIN → WIN_BACK → ADVOCATE
- **Workflow-Based Approvals**: Multi-stage approval process with role-based routing
- **Email Campaign Management**: Template creation, scheduling, and delivery tracking
- **Data Source Integration**: Connect to 360 Data Store, Core Banking, and external sources
- **Real-time Analytics**: Dashboard with performance metrics and reporting

### Workflow Stages
1. **Intake** - Business user submits journey request
2. **DMO Review** - DMO team translates to business rules
3. **CX Review** - CX/Communications team reviews content
4. **Control Review** - Control team performs final approval
5. **Approved** - Journey ready for deployment
6. **Live** - Journey is running

### User Roles
- Super Administrator
- Administrator
- Business User
- DMO Team
- CX Team
- Control Team
- Journey Developer
- Communications Reviewer
- Compliance Officer
- Viewer

## Tech Stack

### Backend
- **Runtime**: Node.js 20 + TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL 15
- **ORM**: Sequelize TypeScript
- **Authentication**: JWT with refresh tokens
- **Email**: Nodemailer with rotation
- **Scheduling**: node-cron

### Frontend
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **State Management**: Zustand
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI
- **Charts**: Recharts
- **Forms**: React Hook Form + Zod

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Web Server**: Nginx
- **Cache**: Redis (optional)
- **Monitoring**: Built-in health checks

## Quick Start

### Prerequisites
- Docker 20.10+
- Docker Compose 2.0+
- 4GB RAM minimum

### Installation

```bash
# 1. Extract the package
tar -xzf journey-platform-fullstack.tar.gz
cd journey-platform-fullstack

# 2. Configure environment
cp .env.example .env
nano .env  # Edit with your settings

# 3. Start services
chmod +x scripts/*.sh
./scripts/start.sh

# 4. Access application
# Frontend: http://localhost
# API: http://localhost:5000
```

### Default Login

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@accessbankplc.com | Admin@123 |

**Note**: You must change the temporary password on first login.

## Project Structure

```
journey-platform-fullstack/
├── backend/                 # Backend API
│   ├── src/
│   │   ├── config/         # Configuration files
│   │   ├── controllers/    # Route controllers
│   │   ├── middleware/     # Express middleware
│   │   ├── models/         # Database models
│   │   ├── routes/         # API routes
│   │   ├── services/       # Business logic
│   │   └── utils/          # Utility functions
│   ├── database/
│   │   ├── init/          # Database initialization
│   │   └── seeders/       # Data seeders
│   └── package.json
├── frontend/               # Frontend application
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── pages/         # Page components
│   │   ├── store/         # Zustand stores
│   │   └── utils/         # Utility functions
│   └── package.json
├── docker/                 # Docker configurations
├── scripts/                # Deployment scripts
├── docs/                   # Documentation
├── docker-compose.yml
└── README.md
```

## API Documentation

### Authentication Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | User login |
| POST | /api/auth/logout | User logout |
| POST | /api/auth/refresh | Refresh token |
| GET | /api/auth/me | Get current user |

### Journey Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/journeys | List all journeys |
| POST | /api/journeys | Create new journey |
| GET | /api/journeys/:id | Get journey details |
| PUT | /api/journeys/:id | Update journey |
| POST | /api/journeys/:id/transition | Workflow transition |

### Workflow Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/workflows/:journeyId/comments | Get comments |
| POST | /api/workflows/:journeyId/comments | Add comment |
| GET | /api/workflows/:journeyId/audit | Get audit history |
| GET | /api/workflows/:journeyId/actions | Get available actions |

## Development

### Backend Development

```bash
cd backend
npm install
npm run dev
```

### Frontend Development

```bash
cd frontend
npm install
npm run dev
```

### Database Migrations

```bash
cd backend
npm run migrate    # Run migrations
npm run seed       # Seed data
```

## Deployment

### Production with Docker

```bash
# Production deployment
docker-compose -f docker-compose.yml up -d

# View logs
docker-compose logs -f

# Backup database
./scripts/backup.sh
```

### Manual Deployment

See [DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md) for detailed instructions.

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NODE_ENV` | Environment mode | `development` |
| `PORT` | Backend port | `5000` |
| `DB_HOST` | Database host | `localhost` |
| `DB_PORT` | Database port | `5432` |
| `DB_NAME` | Database name | `journey_platform` |
| `DB_USER` | Database user | `postgres` |
| `DB_PASSWORD` | Database password | - |
| `JWT_SECRET` | JWT signing secret | - |
| `SMTP_HOST` | SMTP server host | - |
| `SMTP_PORT` | SMTP server port | `587` |

## Security

- JWT-based authentication with refresh tokens
- Role-based access control (RBAC)
- Password history enforcement
- Account lockout after failed attempts
- Rate limiting on API endpoints
- SQL injection protection via parameterized queries
- XSS protection via input sanitization

## Monitoring

### Health Checks

- Backend: `GET /health`
- Database: Automatic connection monitoring
- Email: Connection verification

### Logs

```bash
# View all logs
docker-compose logs -f

# View specific service
docker-compose logs -f backend
docker-compose logs -f frontend
```

## Backup and Restore

### Backup

```bash
# Automated backup
./scripts/backup.sh

# Manual backup
docker-compose exec postgres pg_dump -U postgres journey_platform > backup.sql
```

### Restore

```bash
docker-compose exec -T postgres psql -U postgres journey_platform < backup.sql
```

## Troubleshooting

### Common Issues

1. **Database connection failed**
   - Check PostgreSQL is running: `docker-compose ps postgres`
   - Verify credentials in `.env`

2. **Backend won't start**
   - Check logs: `docker-compose logs backend`
   - Verify environment variables

3. **Frontend blank page**
   - Clear browser cache
   - Check API is accessible: `curl http://localhost:5000/health`

See [DEPLOYMENT_GUIDE.md](docs/DEPLOYMENT_GUIDE.md) for more troubleshooting steps.

## Support

For support and questions:
- Email: support@accessbankplc.com
- Internal: Contact IT Department

## License

PRIVATE - Access Bank PLC

## Changelog

### v1.0.0 (2024)
- Initial release
- Workflow-based approval system
- Multi-role user management
- Email campaign management
- Data source integration
- Real-time analytics dashboard

---

**Access Bank PLC**
**Customer Journey Engagement Platform**
**Version 1.0.0**
