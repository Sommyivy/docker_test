# Access Bank Journey Platform - Deployment Guide

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Quick Start (Docker)](#quick-start-docker)
3. [Manual Installation](#manual-installation)
4. [Production Deployment](#production-deployment)
5. [Database Setup](#database-setup)
6. [Configuration](#configuration)
7. [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

- **OS**: Linux (Ubuntu 20.04+), macOS, or Windows with WSL2
- **RAM**: Minimum 4GB (8GB recommended)
- **Storage**: Minimum 10GB free space
- **CPU**: 2 cores minimum

### Required Software

- **Docker** (20.10+) and **Docker Compose** (2.0+)
- **Node.js** (18+) and **npm** (9+) - for development only
- **Git** - for cloning the repository

## Quick Start (Docker)

The fastest way to get started is using Docker Compose:

### 1. Download and Extract

```bash
# Extract the deployment package
tar -xzf journey-platform-fullstack.tar.gz
cd journey-platform-fullstack
```

### 2. Configure Environment

```bash
# Copy environment file
cp .env.example .env

# Edit with your settings
nano .env
```

**Required Configuration:**

```env
# Database (Change passwords!)
DB_PASSWORD=YourSecurePassword123!

# JWT Secrets (Generate strong random strings)
JWT_SECRET=your-super-secret-jwt-key-min-32-chars
JWT_REFRESH_SECRET=your-refresh-secret-key-min-32-chars

# Email SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# 360 Data Store Connection
DATASTORE_360_HOST=your-datastore-host
DATASTORE_360_USERNAME=your-username
DATASTORE_360_PASSWORD=your-password
```

### 3. Start Services

```bash
# Make scripts executable
chmod +x scripts/*.sh

# Start all services
./scripts/start.sh
```

### 4. Access Application

- **Frontend**: http://localhost
- **Backend API**: http://localhost:5000
- **API Health**: http://localhost:5000/health

### 5. Initial Login

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@accessbankplc.com | Admin@123 |

**Important**: Change the default password on first login!

## Manual Installation

### Backend Setup

```bash
# Navigate to backend
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
# Edit .env with your configuration

# Build TypeScript
npm run build

# Run database migrations
npm run migrate

# Seed default data
npm run seed

# Start server
npm start
```

### Frontend Setup

```bash
# Navigate to frontend
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Start development server
npm run dev

# Or build for production
npm run build
```

## Production Deployment

### Using Docker Compose

```bash
# Production mode
docker-compose -f docker-compose.yml up -d

# View logs
docker-compose logs -f

# Scale backend (if needed)
docker-compose up -d --scale backend=3
```

### SSL/HTTPS Setup

For production, use a reverse proxy like Nginx or Traefik:

```nginx
server {
    listen 443 ssl http2;
    server_name journey.accessbankplc.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Environment Variables for Production

```env
NODE_ENV=production

# Security
BCRYPT_SALT_ROUNDS=12
JWT_SECRET=use-strong-random-string-here
JWT_EXPIRES_IN=12h

# Database Pooling
DB_POOL_MAX=20
DB_POOL_MIN=5

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100

# Logging
LOG_LEVEL=warn
```

## Database Setup

### PostgreSQL Installation (Without Docker)

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database
sudo -u postgres psql -c "CREATE DATABASE journey_platform;"
sudo -u postgres psql -c "CREATE USER journey_user WITH PASSWORD 'secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE journey_platform TO journey_user;"
```

### Database Backup

```bash
# Automated backup script
./scripts/backup.sh

# Manual backup
docker-compose exec postgres pg_dump -U postgres journey_platform > backup_$(date +%Y%m%d).sql
```

### Database Restore

```bash
# Restore from backup
docker-compose exec -T postgres psql -U postgres journey_platform < backup_file.sql
```

## Configuration

### Email Configuration

1. **Gmail SMTP:**
   - Enable 2FA
   - Generate App Password
   - Use App Password in SMTP_PASS

2. **Custom SMTP:**
   ```env
   SMTP_HOST=mail.yourdomain.com
   SMTP_PORT=587
   SMTP_USER=noreply@yourdomain.com
   SMTP_PASS=your-password
   ```

### 360 Data Store Connection

```env
DATASTORE_360_HOST=360datastore.accessbankplc.com
DATASTORE_360_PORT=1433
DATASTORE_360_DATABASE=CUSTOMER_360
DATASTORE_360_USERNAME=journey_platform
DATASTORE_360_PASSWORD=secure_password
DATASTORE_360_ENCRYPT=true
```

### User Roles and Permissions

| Role | Description | Permissions |
|------|-------------|-------------|
| Super Admin | Full system access | All |
| Admin | Administrative access | All except user deletion |
| Business User | Create journey requests | View, Create Journeys |
| DMO Team | Translate to business rules | Edit Journeys, Manage Rules |
| CX Team | Review content/templates | Approve Templates |
| Control Team | Final approval | Approve Journeys |
| Journey Developer | Build journeys | Create/Edit Journeys |
| Viewer | Read-only access | View only |

## Troubleshooting

### Common Issues

#### 1. Database Connection Failed

```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Verify credentials in .env
cat .env | grep DB_
```

#### 2. Backend Won't Start

```bash
# Check logs
docker-compose logs backend

# Verify environment variables
docker-compose exec backend env

# Restart backend
docker-compose restart backend
```

#### 3. Frontend Blank Page

```bash
# Clear browser cache
# Check console for errors
# Verify API is accessible
curl http://localhost:5000/health
```

#### 4. Email Not Sending

```bash
# Test SMTP configuration
docker-compose exec backend node -e "
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});
transporter.verify().then(() => console.log('SMTP OK')).catch(console.error);
"
```

### Getting Help

1. Check logs: `docker-compose logs -f`
2. Review documentation in `/docs`
3. Contact support: support@accessbankplc.com

## Maintenance

### Regular Tasks

- **Daily**: Monitor logs, check email queue
- **Weekly**: Review user activity, backup database
- **Monthly**: Update dependencies, review security

### Update Procedure

```bash
# Backup first
./scripts/backup.sh

# Pull updates
git pull origin main

# Rebuild and restart
./scripts/update.sh
```

## Security Checklist

- [ ] Change all default passwords
- [ ] Use strong JWT secrets (min 32 chars)
- [ ] Enable HTTPS in production
- [ ] Configure firewall rules
- [ ] Set up log monitoring
- [ ] Enable database encryption
- [ ] Regular security updates
- [ ] Implement backup strategy

---

**Access Bank PLC - IT Department**
**Version**: 1.0.0
**Last Updated**: 2024
