#!/bin/bash

# Access Bank Journey Platform - Installation Script
# This script sets up the complete application on a local system

set -e

echo "=========================================="
echo "Access Bank Journey Platform - Installer"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
   print_error "Do not run this script as root"
   exit 1
fi

# Get installation directory
INSTALL_DIR=${1:-"$HOME/journey-platform"}
print_status "Installation directory: $INSTALL_DIR"

# Create installation directory
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# Check prerequisites
print_status "Checking prerequisites..."

# Check Docker
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    echo "Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    echo "Visit: https://docs.docker.com/compose/install/"
    exit 1
fi

print_status "Docker version: $(docker --version)"
print_status "Docker Compose version: $(docker-compose --version)"

# Check Node.js (for development)
if command -v node &> /dev/null; then
    print_status "Node.js version: $(node --version)"
else
    print_warning "Node.js is not installed. It's required for development but not for production deployment."
fi

# Create directory structure
print_status "Creating directory structure..."
mkdir -p {backend,frontend,logs,backups}

# Copy environment file
print_status "Setting up environment configuration..."
if [ ! -f .env ]; then
    cat > .env << 'EOF'
# ============================================
# Access Bank Journey Platform - Environment Configuration
# ============================================

# Application Settings
NODE_ENV=production
BACKEND_PORT=5000
FRONTEND_PORT=80

# Database Configuration
DB_HOST=postgres
DB_PORT=5432
DB_NAME=journey_platform
DB_USER=postgres
DB_PASSWORD=ChangeThisSecurePassword123!

# JWT Secrets (Change these in production!)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_REFRESH_SECRET=your-refresh-token-secret-change-this

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# Frontend URL
FRONTEND_URL=http://localhost

# 360 Data Store Connection
DATASTORE_360_HOST=360datastore.accessbankplc.com
DATASTORE_360_PORT=1433
DATASTORE_360_DATABASE=CUSTOMER_360
DATASTORE_360_USERNAME=journey_platform_user
DATASTORE_360_PASSWORD=secure_password
EOF
    print_status "Created .env file. Please edit it with your actual configuration values."
else
    print_warning ".env file already exists. Keeping existing configuration."
fi

# Create docker-compose override for local development
if [ ! -f docker-compose.override.yml ]; then
    cat > docker-compose.override.yml << 'EOF'
version: '3.8'

services:
  backend:
    volumes:
      - ./backend/src:/app/src
      - ./backend/logs:/app/logs
    environment:
      - NODE_ENV=development
    command: npm run dev

  frontend:
    build:
      target: builder
    volumes:
      - ./frontend/src:/app/src
      - ./frontend/public:/app/public
    command: npm run dev
    ports:
      - "3000:3000"
EOF
    print_status "Created docker-compose.override.yml for development"
fi

# Create startup script
cat > start.sh << 'EOF'
#!/bin/bash
set -e

echo "Starting Access Bank Journey Platform..."

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Start services
docker-compose up -d

echo ""
echo "=========================================="
echo "Services started successfully!"
echo "=========================================="
echo ""
echo "Frontend: http://localhost"
echo "Backend API: http://localhost:5000"
echo "API Health Check: http://localhost:5000/health"
echo ""
echo "To view logs: docker-compose logs -f"
echo "To stop: docker-compose down"
echo ""
EOF
chmod +x start.sh

# Create stop script
cat > stop.sh << 'EOF'
#!/bin/bash
set -e

echo "Stopping Access Bank Journey Platform..."
docker-compose down

echo "Services stopped."
EOF
chmod +x stop.sh

# Create backup script
cat > backup.sh << 'EOF'
#!/bin/bash
set -e

BACKUP_DIR="./backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$TIMESTAMP.sql"

mkdir -p "$BACKUP_DIR"

echo "Creating database backup..."
docker-compose exec -T postgres pg_dump -U postgres journey_platform > "$BACKUP_FILE"

echo "Backup created: $BACKUP_FILE"
EOF
chmod +x backup.sh

# Create update script
cat > update.sh << 'EOF'
#!/bin/bash
set -e

echo "Updating Access Bank Journey Platform..."

# Pull latest images
docker-compose pull

# Rebuild and restart
docker-compose up -d --build

echo "Update completed!"
EOF
chmod +x update.sh

print_status "Scripts created: start.sh, stop.sh, backup.sh, update.sh"

# Create README
cat > README.md << 'EOF'
# Access Bank Journey Platform

## Quick Start

1. Configure environment variables in `.env` file
2. Run `./start.sh` to start all services
3. Access the application at http://localhost

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@accessbankplc.com | Admin@123 |
| Business User | business@accessbankplc.com | Business@123 |
| DMO Team | dmo@accessbankplc.com | Dmo@123 |
| CX Team | cx@accessbankplc.com | Cx@123 |
| Control Team | control@accessbankplc.com | Control@123 |

**Note:** You will be required to change the temporary password on first login.

## Available Scripts

- `./start.sh` - Start all services
- `./stop.sh` - Stop all services
- `./backup.sh` - Create database backup
- `./update.sh` - Update to latest version

## Services

| Service | URL | Description |
|---------|-----|-------------|
| Frontend | http://localhost | Web application |
| Backend API | http://localhost:5000 | REST API |
| Database | localhost:5432 | PostgreSQL |
| Redis | localhost:6379 | Cache (optional) |

## Docker Commands

```bash
# View logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f backend

# Restart a service
docker-compose restart backend

# Execute command in container
docker-compose exec backend sh

# Database backup
docker-compose exec postgres pg_dump -U postgres journey_platform > backup.sql

# Database restore
docker-compose exec -T postgres psql -U postgres journey_platform < backup.sql
```

## Directory Structure

```
journey-platform/
├── backend/          # Backend API source code
├── frontend/         # Frontend application
├── docker/           # Docker configuration files
├── logs/             # Application logs
├── backups/          # Database backups
├── .env              # Environment configuration
├── docker-compose.yml
├── start.sh
├── stop.sh
└── README.md
```

## Support

For support, contact the IT team or email support@accessbankplc.com
EOF

print_status "README.md created"

# Final instructions
echo ""
echo "=========================================="
echo "Installation Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo ""
echo "1. Edit the .env file with your configuration:"
echo "   nano $INSTALL_DIR/.env"
echo ""
echo "2. Start the application:"
echo "   cd $INSTALL_DIR && ./start.sh"
echo ""
echo "3. Access the application:"
echo "   Frontend: http://localhost"
echo "   API: http://localhost:5000"
echo ""
echo "4. Default admin login:"
echo "   Email: admin@accessbankplc.com"
echo "   Password: Admin@123"
echo ""
echo "For more information, see README.md"
echo ""
