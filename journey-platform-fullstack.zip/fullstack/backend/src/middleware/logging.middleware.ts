import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

// Request logger middleware
export const requestLogger = (req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const logData = {
      method: req.method,
      url: req.originalUrl,
      status: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip,
      userAgent: req.get('user-agent'),
      userId: req.user?.id,
    };

    if (res.statusCode >= 400) {
      logger.warn('Request completed with error', logData);
    } else {
      logger.info('Request completed', logData);
    }
  });

  next();
};

// Activity logger middleware
export const activityLogger = (activityType: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Store original end function
    const originalEnd = res.end;

    res.end = function(chunk?: any, encoding?: any, cb?: any) {
      // Restore original end function
      res.end = originalEnd;

      // Only log successful requests
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const { ActivityLog } = require('../models/activity-log.model');
        
        ActivityLog.create({
          type: activityType,
          userId: req.user?.id,
          entityType: req.params.id ? req.baseUrl.split('/').pop() : undefined,
          entityId: req.params.id,
          description: `${req.method} ${req.originalUrl}`,
          ipAddress: req.ip,
          metadata: {
            body: req.body,
            params: req.params,
            query: req.query,
          },
        }).catch((error: any) => {
          logger.error('Failed to log activity:', error);
        });
      }

      // Call original end
      return originalEnd.call(this, chunk, encoding, cb);
    };

    next();
  };
};

// Audit logger middleware
export const auditLogger = (action: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Capture old value before request processing
    const entityType = req.baseUrl.split('/').pop() || 'unknown';
    const entityId = req.params.id;
    let oldValue: any = null;

    if (entityId && (req.method === 'PUT' || req.method === 'PATCH')) {
      try {
        // Try to get old value (this is a simplified approach)
        // In production, you might want to fetch from database
        oldValue = req.body._oldValue;
        delete req.body._oldValue;
      } catch (error) {
        logger.warn('Could not capture old value for audit log');
      }
    }

    // Store original end function
    const originalEnd = res.end;

    res.end = function(chunk?: any, encoding?: any, cb?: any) {
      // Restore original end function
      res.end = originalEnd;

      // Only log successful requests
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const { AuditLog } = require('../models/audit-log.model');
        
        AuditLog.create({
          entityType,
          entityId: entityId || req.body.id,
          action,
          oldValue,
          newValue: req.body,
          performedBy: req.user?.id,
          ipAddress: req.ip,
          userAgent: req.get('user-agent'),
          notes: req.body.notes || req.body.comment,
        }).catch((error: any) => {
          logger.error('Failed to create audit log:', error);
        });
      }

      // Call original end
      return originalEnd.call(this, chunk, encoding, cb);
    };

    next();
  };
};

export default requestLogger;
