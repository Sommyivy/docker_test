import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User, UserStatus } from '../models/user.model';
import { UserSession } from '../models/user-session.model';
import { AppError } from './error.middleware';
import { logger } from '../utils/logger';

// Extend Express Request interface
declare global {
  namespace Express {
    interface Request {
      user?: User;
      session?: UserSession;
    }
  }
}

// JWT Payload interface
interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  sessionId: string;
  iat: number;
  exp: number;
}

// Authenticate JWT token
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access denied. No token provided.', 401);
    }

    const token = authHeader.split(' ')[1];

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JWTPayload;

    // Check session validity
    const session = await UserSession.findByPk(decoded.sessionId);
    
    if (!session) {
      throw new AppError('Invalid session.', 401);
    }

    if (session.isRevoked) {
      throw new AppError('Session has been revoked.', 401);
    }

    if (session.isExpired()) {
      throw new AppError('Session has expired.', 401);
    }

    // Get user
    const user = await User.findByPk(decoded.userId);

    if (!user) {
      throw new AppError('User not found.', 401);
    }

    if (user.status === UserStatus.INACTIVE) {
      throw new AppError('Account is inactive.', 403);
    }

    if (user.isLocked()) {
      throw new AppError('Account is locked. Please try again later.', 403);
    }

    // Update session activity
    await session.updateActivity();

    // Attach user and session to request
    req.user = user;
    req.session = session;

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError('Invalid token.', 401));
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new AppError('Token expired.', 401));
    }
    next(error);
  }
};

// Optional authentication (doesn't require token but attaches user if present)
export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JWTPayload;
    
    const user = await User.findByPk(decoded.userId);
    
    if (user && user.status === UserStatus.ACTIVE) {
      req.user = user;
    }

    next();
  } catch (error) {
    // Continue without user if token is invalid
    next();
  }
};

// Authorize by role
export const authorize = (...roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('Access denied. Not authenticated.', 401));
    }

    if (!roles.includes(req.user.role)) {
      logger.warn('Unauthorized access attempt:', {
        userId: req.user.id,
        role: req.user.role,
        requiredRoles: roles,
        url: req.originalUrl,
      });
      return next(new AppError('Access denied. Insufficient permissions.', 403));
    }

    next();
  };
};

// Check module permission
export const checkPermission = (module: string, action: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('Access denied. Not authenticated.', 401));
    }

    const permissions = req.user.permissions || User.getDefaultPermissions(req.user.role);
    
    const modulePermissions = permissions[module as keyof typeof permissions];
    
    if (!modulePermissions || !(modulePermissions as any)[action]) {
      logger.warn('Permission denied:', {
        userId: req.user.id,
        module,
        action,
        url: req.originalUrl,
      });
      return next(new AppError('Access denied. Insufficient permissions.', 403));
    }

    next();
  };
};

// Refresh token validation
export const validateRefreshToken = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw new AppError('Refresh token is required.', 400);
    }

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as JWTPayload;

    const session = await UserSession.findByPk(decoded.sessionId);

    if (!session || session.refreshToken !== refreshToken) {
      throw new AppError('Invalid refresh token.', 401);
    }

    if (session.isRefreshExpired()) {
      throw new AppError('Refresh token expired.', 401);
    }

    if (session.isRevoked) {
      throw new AppError('Session has been revoked.', 401);
    }

    req.session = session;
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError('Invalid refresh token.', 401));
    }
    next(error);
  }
};

export default authenticate;
