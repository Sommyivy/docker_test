import cron from 'node-cron';
import { Journey, JourneyStatus } from '../models/journey.model';
import { JourneyRun, RunStatus } from '../models/journey-run.model';
import { EmailService } from './email.service';
import { logger } from '../utils/logger';

export class SchedulerService {
  private static instance: SchedulerService;
  private emailService: EmailService;
  private jobs: Map<string, cron.ScheduledTask> = new Map();

  private constructor() {
    this.emailService = EmailService.getInstance();
  }

  public static getInstance(): SchedulerService {
    if (!SchedulerService.instance) {
      SchedulerService.instance = new SchedulerService();
    }
    return SchedulerService.instance;
  }

  // Start all scheduled jobs
  public startAllJobs(): void {
    this.startDailyEmailResetJob();
    this.startJourneySchedulerJob();
    this.startJourneyCompletionJob();
    this.startSessionCleanupJob();

    logger.info('All scheduler jobs started');
  }

  // Stop all scheduled jobs
  public stopAllJobs(): void {
    this.jobs.forEach(job => job.stop());
    this.jobs.clear();

    logger.info('All scheduler jobs stopped');
  }

  // Reset daily email counters at midnight
  private startDailyEmailResetJob(): void {
    const job = cron.schedule('0 0 * * *', async () => {
      try {
        logger.info('Running daily email counter reset...');
        await this.emailService.resetDailyCounters();
        logger.info('Daily email counters reset completed');
      } catch (error) {
        logger.error('Failed to reset daily email counters:', error);
      }
    }, {
      scheduled: true,
      timezone: 'Africa/Lagos', // Access Bank timezone
    });

    this.jobs.set('dailyEmailReset', job);
    logger.info('Daily email reset job scheduled');
  }

  // Check and start scheduled journeys
  private startJourneySchedulerJob(): void {
    const job = cron.schedule('*/5 * * * *', async () => {
      try {
        logger.debug('Checking for scheduled journeys...');

        const now = new Date();
        const scheduledJourneys = await Journey.findAll({
          where: {
            status: JourneyStatus.SCHEDULED,
            scheduledAt: {
              $lte: now,
            },
          },
        });

        for (const journey of scheduledJourneys) {
          try {
            await this.startJourney(journey);
            logger.info(`Started scheduled journey: ${journey.name}`);
          } catch (error) {
            logger.error(`Failed to start journey ${journey.name}:`, error);
          }
        }
      } catch (error) {
        logger.error('Journey scheduler job failed:', error);
      }
    }, {
      scheduled: true,
    });

    this.jobs.set('journeyScheduler', job);
    logger.info('Journey scheduler job scheduled');
  }

  // Check and complete finished journeys
  private startJourneyCompletionJob(): void {
    const job = cron.schedule('0 */6 * * *', async () => {
      try {
        logger.debug('Checking for completed journeys...');

        const runningJourneys = await Journey.findAll({
          where: {
            status: JourneyStatus.RUNNING,
          },
        });

        for (const journey of runningJourneys) {
          const runs = await JourneyRun.findAll({ where: { journeyId: journey.id } });
          // Check if all runs are completed
          const allRunsCompleted = runs.every(
            (run: any) => run.status === RunStatus.COMPLETED || run.status === RunStatus.FAILED
          );

          if (allRunsCompleted && runs.length > 0) {
            await journey.update({ status: JourneyStatus.COMPLETED });
            logger.info(`Journey completed: ${journey.name}`);
          }
        }
      } catch (error) {
        logger.error('Journey completion job failed:', error);
      }
    }, {
      scheduled: true,
    });

    this.jobs.set('journeyCompletion', job);
    logger.info('Journey completion job scheduled');
  }

  // Clean up expired sessions
  private startSessionCleanupJob(): void {
    const job = cron.schedule('0 2 * * *', async () => {
      try {
        logger.info('Running session cleanup...');

        const { UserSession } = require('../models/user-session.model');
        const { Op } = require('sequelize');

        const deletedCount = await UserSession.destroy({
          where: {
            [Op.or]: [
              { isRevoked: true },
              { expiresAt: { [Op.lt]: new Date() } },
            ],
          },
        });

        logger.info(`Cleaned up ${deletedCount} expired sessions`);
      } catch (error) {
        logger.error('Session cleanup job failed:', error);
      }
    }, {
      scheduled: true,
    });

    this.jobs.set('sessionCleanup', job);
    logger.info('Session cleanup job scheduled');
  }

  // Start a journey
  private async startJourney(journey: Journey): Promise<void> {
    // Update journey status
    await journey.update({
      status: JourneyStatus.RUNNING,
      startedAt: new Date(),
    });

    // Create journey run
    await JourneyRun.create({
      journeyId: journey.id,
      status: RunStatus.PENDING,
      scheduledAt: new Date(),
      triggeredBy: 'scheduler',
    });

    // TODO: Implement actual journey execution logic
    // This would involve:
    // 1. Querying the data source for target audience
    // 2. Segmenting users based on rules
    // 3. Sending emails using the email service
    // 4. Tracking metrics and updating the journey run
  }

  // Schedule a journey
  public async scheduleJourney(
    journeyId: string,
    scheduleDate: Date
  ): Promise<{ success: boolean; message: string }> {
    try {
      const journey = await Journey.findByPk(journeyId);

      if (!journey) {
        return { success: false, message: 'Journey not found' };
      }

      if (journey.status !== JourneyStatus.APPROVED) {
        return { success: false, message: 'Journey must be approved before scheduling' };
      }

      if (scheduleDate <= new Date()) {
        return { success: false, message: 'Schedule date must be in the future' };
      }

      await journey.update({
        status: JourneyStatus.SCHEDULED,
        scheduledAt: scheduleDate,
      });

      logger.info(`Journey scheduled: ${journey.name} for ${scheduleDate}`);

      return { success: true, message: 'Journey scheduled successfully' };
    } catch (error: any) {
      logger.error('Failed to schedule journey:', error);
      return { success: false, message: error.message };
    }
  }

  // Cancel scheduled journey
  public async cancelScheduledJourney(
    journeyId: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      const journey = await Journey.findByPk(journeyId);

      if (!journey) {
        return { success: false, message: 'Journey not found' };
      }

      if (journey.status !== JourneyStatus.SCHEDULED) {
        return { success: false, message: 'Journey is not scheduled' };
      }

      await journey.update({
        status: JourneyStatus.APPROVED,
        scheduledAt: null,
      });

      logger.info(`Journey schedule cancelled: ${journey.name}`);

      return { success: true, message: 'Journey schedule cancelled' };
    } catch (error: any) {
      logger.error('Failed to cancel journey schedule:', error);
      return { success: false, message: error.message };
    }
  }

  // Get job status
  public getJobStatus(): { name: string; running: boolean }[] {
    return Array.from(this.jobs.entries()).map(([name, job]) => ({
      name,
      running: true,
    }));
  }
}

export default SchedulerService;
