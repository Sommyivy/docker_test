import nodemailer from 'nodemailer';
import { EmailConfig } from '../models/email-config.model';
import { EmailAlias } from '../models/email-alias.model';
import { logger } from '../utils/logger';

export enum RotationStrategy {
  ROUND_ROBIN = 'round_robin',
  RANDOM = 'random',
  LEAST_USED = 'least_used',
}

interface EmailOptions {
  to: string | string[];
  subject: string;
  text?: string;
  html?: string;
  from?: string;
  cc?: string | string[];
  bcc?: string | string[];
  attachments?: any[];
}

interface SendResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

export class EmailService {
  private static instance: EmailService;
  private transporters: Map<string, nodemailer.Transporter> = new Map();
  private currentAliasIndex: number = 0;

  private constructor() {
    this.initializeTransporters();
  }

  public static getInstance(): EmailService {
    if (!EmailService.instance) {
      EmailService.instance = new EmailService();
    }
    return EmailService.instance;
  }

  // Initialize transporters from database
  private async initializeTransporters(): Promise<void> {
    try {
      const configs = await EmailConfig.findAll({ where: { isActive: true } });
      
      for (const config of configs) {
        await this.createTransporter(config);
      }

      logger.info(`Initialized ${configs.length} email transporters`);
    } catch (error) {
      logger.error('Failed to initialize email transporters:', error);
    }
  }

  // Create transporter for a config
  private async createTransporter(config: EmailConfig): Promise<void> {
    const transporter = nodemailer.createTransport({
      host: config.host,
      port: config.port,
      secure: config.secure,
      auth: {
        user: config.username,
        pass: config.password,
      },
    });

    // Verify connection
    try {
      await transporter.verify();
      this.transporters.set(config.id, transporter);
      logger.info(`Email transporter created for: ${config.name}`);
    } catch (error) {
      logger.error(`Failed to verify email config ${config.name}:`, error);
    }
  }

  // Get next email alias using round-robin
  private async getNextAlias(): Promise<EmailAlias | null> {
    const aliases = await EmailAlias.findAll({
      where: { isActive: true },
      order: [['lastUsedAt', 'ASC']],
    });

    if (aliases.length === 0) return null;

    // Find first alias that can send
    for (const alias of aliases) {
      if (alias.canSend()) {
        return alias;
      }
    }

    // If all aliases are at limit, reset and try again
    for (const alias of aliases) {
      await alias.resetDailyCount();
    }

    return aliases[0];
  }

  // Send email with rotation
  public async sendEmail(options: EmailOptions): Promise<SendResult> {
    try {
      // Get next available alias
      const alias = await this.getNextAlias();

      if (!alias) {
        throw new Error('No email aliases available');
      }

      // Get default config
      const config = await EmailConfig.findOne({ where: { isDefault: true, isActive: true } });

      if (!config) {
        throw new Error('No default email configuration found');
      }

      const transporter = this.transporters.get(config.id);

      if (!transporter) {
        throw new Error('Email transporter not initialized');
      }

      // Send email
      const result = await transporter.sendMail({
        from: options.from || `"${config.fromName || 'Access Bank'}" <${alias.email}>`,
        to: options.to,
        cc: options.cc,
        bcc: options.bcc,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments,
      });

      // Record usage
      await alias.recordUsage();

      logger.info('Email sent successfully:', {
        messageId: result.messageId,
        to: options.to,
        alias: alias.email,
      });

      return {
        success: true,
        messageId: result.messageId,
      };
    } catch (error: any) {
      logger.error('Failed to send email:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Send bulk emails with rotation
  public async sendBulkEmails(
    recipients: string[],
    options: Omit<EmailOptions, 'to'>
  ): Promise<SendResult[]> {
    const results: SendResult[] = [];

    for (const recipient of recipients) {
      const result = await this.sendEmail({
        ...options,
        to: recipient,
      });

      results.push(result);

      // Small delay to prevent rate limiting
      await this.delay(100);
    }

    return results;
  }

  // Send password reset email
  public async sendPasswordResetEmail(
    to: string,
    resetToken: string,
    userName: string
  ): Promise<SendResult> {
    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;

    return this.sendEmail({
      to,
      subject: 'Password Reset Request - Access Bank Journey Platform',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #003087;">Password Reset Request</h2>
          <p>Hello ${userName},</p>
          <p>You have requested to reset your password for the Access Bank Journey Platform.</p>
          <p>Click the link below to reset your password:</p>
          <a href="${resetUrl}" style="display: inline-block; background-color: #003087; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; margin: 16px 0;">Reset Password</a>
          <p>Or copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #666;">${resetUrl}</p>
          <p>This link will expire in 1 hour.</p>
          <p>If you did not request this password reset, please ignore this email.</p>
          <hr style="border: none; border-top: 1px solid #eee; margin: 24px 0;">
          <p style="color: #666; font-size: 12px;">Access Bank PLC - Journey Platform</p>
        </div>
      `,
      text: `
        Password Reset Request
        
        Hello ${userName},
        
        You have requested to reset your password for the Access Bank Journey Platform.
        
        Click the link below to reset your password:
        ${resetUrl}
        
        This link will expire in 1 hour.
        
        If you did not request this password reset, please ignore this email.
        
        Access Bank PLC - Journey Platform
      `,
    });
  }

  // Send welcome email
  public async sendWelcomeEmail(
    to: string,
    userName: string,
    temporaryPassword: string
  ): Promise<SendResult> {
    const loginUrl = `${process.env.FRONTEND_URL}/login`;

    return this.sendEmail({
      to,
      subject: 'Welcome to Access Bank Journey Platform',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #003087;">Welcome to Access Bank Journey Platform</h2>
          <p>Hello ${userName},</p>
          <p>Your account has been created successfully.</p>
          <p><strong>Temporary Password:</strong> ${temporaryPassword}</p>
          <p>You will be required to change this password on your first login.</p>
          <a href="${loginUrl}" style="display: inline-block; background-color: #003087; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; margin: 16px 0;">Login to Platform</a>
          <hr style="border: none; border-top: 1px solid #eee; margin: 24px 0;">
          <p style="color: #666; font-size: 12px;">Access Bank PLC - Journey Platform</p>
        </div>
      `,
      text: `
        Welcome to Access Bank Journey Platform
        
        Hello ${userName},
        
        Your account has been created successfully.
        
        Temporary Password: ${temporaryPassword}
        
        You will be required to change this password on your first login.
        
        Login: ${loginUrl}
        
        Access Bank PLC - Journey Platform
      `,
    });
  }

  // Send journey notification
  public async sendJourneyNotification(
    to: string,
    journeyName: string,
    status: string,
    actionUrl: string
  ): Promise<SendResult> {
    return this.sendEmail({
      to,
      subject: `Journey ${status}: ${journeyName}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #003087;">Journey Status Update</h2>
          <p>The journey <strong>${journeyName}</strong> has been updated to status: <strong>${status}</strong>.</p>
          <a href="${actionUrl}" style="display: inline-block; background-color: #003087; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; margin: 16px 0;">View Journey</a>
          <hr style="border: none; border-top: 1px solid #eee; margin: 24px 0;">
          <p style="color: #666; font-size: 12px;">Access Bank PLC - Journey Platform</p>
        </div>
      `,
    });
  }

  // Test email configuration
  public async testConfig(configId: string): Promise<{ success: boolean; message: string }> {
    try {
      const config = await EmailConfig.findByPk(configId);

      if (!config) {
        return { success: false, message: 'Configuration not found' };
      }

      const transporter = nodemailer.createTransport({
        host: config.host,
        port: config.port,
        secure: config.secure,
        auth: {
          user: config.username,
          pass: config.password,
        },
      });

      await transporter.verify();

      await config.update({
        lastTestedAt: new Date(),
        lastTestSuccess: true,
        lastTestResult: 'Connection successful',
      });

      return { success: true, message: 'Connection successful' };
    } catch (error: any) {
      const config = await EmailConfig.findByPk(configId);
      if (config) {
        await config.update({
          lastTestedAt: new Date(),
          lastTestSuccess: false,
          lastTestResult: error.message,
        });
      }

      return { success: false, message: error.message };
    }
  }

  // Reset daily counters
  public async resetDailyCounters(): Promise<void> {
    try {
      await EmailAlias.update(
        { dailySent: 0, lastResetAt: new Date() },
        { where: {} }
      );

      await EmailConfig.update(
        { dailySent: 0, lastResetAt: new Date() },
        { where: {} }
      );

      logger.info('Daily email counters reset');
    } catch (error) {
      logger.error('Failed to reset daily counters:', error);
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export default EmailService;
