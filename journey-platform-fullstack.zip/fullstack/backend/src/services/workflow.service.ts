import { Journey, JourneyStatus } from '../models/journey.model';
import { WorkflowComment, CommentType } from '../models/workflow-comment.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { User, UserRole } from '../models/user.model';
import { EmailService } from './email.service';
import { logger } from '../utils/logger';

export interface WorkflowTransition {
  from: JourneyStatus;
  to: JourneyStatus;
  allowedRoles: UserRole[];
  requiresComment: boolean;
}

export class WorkflowService {
  private static instance: WorkflowService;
  private emailService: EmailService;

  private transitions: WorkflowTransition[] = [
    { from: JourneyStatus.DRAFT, to: JourneyStatus.INTAKE, allowedRoles: [UserRole.BUSINESS_USER, UserRole.JOURNEY_DEVELOPER, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.INTAKE, to: JourneyStatus.DMO_REVIEW, allowedRoles: [UserRole.DMO_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.DMO_REVIEW, to: JourneyStatus.CX_REVIEW, allowedRoles: [UserRole.DMO_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.DMO_REVIEW, to: JourneyStatus.INTAKE, allowedRoles: [UserRole.DMO_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: true },
    { from: JourneyStatus.CX_REVIEW, to: JourneyStatus.CONTROL_REVIEW, allowedRoles: [UserRole.CX_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.CX_REVIEW, to: JourneyStatus.DMO_REVIEW, allowedRoles: [UserRole.CX_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: true },
    { from: JourneyStatus.CONTROL_REVIEW, to: JourneyStatus.APPROVED, allowedRoles: [UserRole.CONTROL_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.CONTROL_REVIEW, to: JourneyStatus.CX_REVIEW, allowedRoles: [UserRole.CONTROL_TEAM, UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: true },
    { from: JourneyStatus.APPROVED, to: JourneyStatus.SCHEDULED, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.JOURNEY_DEVELOPER], requiresComment: false },
    { from: JourneyStatus.APPROVED, to: JourneyStatus.RUNNING, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN, UserRole.JOURNEY_DEVELOPER], requiresComment: false },
    { from: JourneyStatus.SCHEDULED, to: JourneyStatus.RUNNING, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.RUNNING, to: JourneyStatus.PAUSED, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.PAUSED, to: JourneyStatus.RUNNING, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
    { from: JourneyStatus.RUNNING, to: JourneyStatus.COMPLETED, allowedRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN], requiresComment: false },
  ];

  private constructor() {
    this.emailService = EmailService.getInstance();
  }

  public static getInstance(): WorkflowService {
    if (!WorkflowService.instance) {
      WorkflowService.instance = new WorkflowService();
    }
    return WorkflowService.instance;
  }

  // Check if transition is allowed
  public canTransition(
    journey: Journey,
    newStatus: JourneyStatus,
    userRole: UserRole
  ): { allowed: boolean; reason?: string } {
    const transition = this.transitions.find(
      t => t.from === journey.status && t.to === newStatus
    );

    if (!transition) {
      return { allowed: false, reason: `Cannot transition from ${journey.status} to ${newStatus}` };
    }

    if (!transition.allowedRoles.includes(userRole)) {
      return { allowed: false, reason: 'Insufficient permissions for this transition' };
    }

    return { allowed: true };
  }

  // Perform workflow transition
  public async transition(
    journey: Journey,
    newStatus: JourneyStatus,
    userId: string,
    userRole: UserRole,
    comment?: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      // Check if transition is allowed
      const canTransition = this.canTransition(journey, newStatus, userRole);

      if (!canTransition.allowed) {
        return { success: false, message: canTransition.reason! };
      }

      const transition = this.transitions.find(
        t => t.from === journey.status && t.to === newStatus
      )!;

      // Check if comment is required
      if (transition.requiresComment && !comment) {
        return { success: false, message: 'A comment is required for this transition' };
      }

      const oldStatus = journey.status;

      // Update journey status
      await journey.transitionTo(newStatus, userId, comment);

      // Add comment if provided
      if (comment) {
        await WorkflowComment.create({
          journeyId: journey.id,
          userId,
          content: comment,
          type: this.getCommentTypeForTransition(newStatus),
          stage: newStatus,
        });
      }

      // Create audit log
      await AuditLog.create({
        entityType: 'journey',
        entityId: journey.id,
        action: AuditAction.STATUS_CHANGE,
        oldValue: oldStatus,
        newValue: newStatus,
        performedBy: userId,
        notes: comment,
      });

      // Notify relevant users
      await this.notifyStakeholders(journey, newStatus, userId);

      logger.info('Workflow transition completed:', {
        journeyId: journey.id,
        from: oldStatus,
        to: newStatus,
        userId,
      });

      return { success: true, message: `Journey transitioned to ${newStatus}` };
    } catch (error: any) {
      logger.error('Workflow transition failed:', error);
      return { success: false, message: error.message };
    }
  }

  // Add comment to journey
  public async addComment(
    journeyId: string,
    userId: string,
    content: string,
    type: CommentType = CommentType.GENERAL,
    parentId?: string
  ): Promise<WorkflowComment> {
    const comment = await WorkflowComment.create({
      journeyId,
      userId,
      content,
      type,
      parentId,
    });

    logger.info('Comment added to journey:', { journeyId, userId, type });

    return comment;
  }

  // Get journey comments
  public async getComments(journeyId: string): Promise<WorkflowComment[]> {
    return WorkflowComment.findAll({
      where: { journeyId },
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'firstName', 'lastName', 'email'],
        },
      ],
      order: [['createdAt', 'DESC']],
    });
  }

  // Get audit history for journey
  public async getAuditHistory(journeyId: string): Promise<AuditLog[]> {
    return AuditLog.findAll({
      where: { entityType: 'journey', entityId: journeyId },
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'firstName', 'lastName', 'email'],
        },
      ],
      order: [['createdAt', 'DESC']],
    });
  }

  // Get available actions for user
  public getAvailableActions(
    journey: Journey,
    userRole: UserRole
  ): { status: JourneyStatus; label: string; requiresComment: boolean }[] {
    const availableTransitions = this.transitions.filter(
      t => t.from === journey.status && t.allowedRoles.includes(userRole)
    );

    return availableTransitions.map(t => ({
      status: t.to,
      label: this.getActionLabel(t.to),
      requiresComment: t.requiresComment,
    }));
  }

  // Get workflow stage info
  public getStageInfo(status: JourneyStatus): {
    label: string;
    description: string;
    responsibleRoles: UserRole[];
  } {
    const stageInfo: Record<JourneyStatus, { label: string; description: string; responsibleRoles: UserRole[] }> = {
      [JourneyStatus.DRAFT]: {
        label: 'Draft',
        description: 'Journey is being created and edited',
        responsibleRoles: [UserRole.BUSINESS_USER, UserRole.JOURNEY_DEVELOPER],
      },
      [JourneyStatus.INTAKE]: {
        label: 'Intake',
        description: 'Business user has submitted the journey request',
        responsibleRoles: [UserRole.BUSINESS_USER],
      },
      [JourneyStatus.DMO_REVIEW]: {
        label: 'DMO Review',
        description: 'DMO team is translating request into business rules',
        responsibleRoles: [UserRole.DMO_TEAM],
      },
      [JourneyStatus.CX_REVIEW]: {
        label: 'CX Review',
        description: 'CX/Communications team is reviewing content and templates',
        responsibleRoles: [UserRole.CX_TEAM, UserRole.COMMUNICATIONS_REVIEWER],
      },
      [JourneyStatus.CONTROL_REVIEW]: {
        label: 'Control Review',
        description: 'Control team is performing final approval',
        responsibleRoles: [UserRole.CONTROL_TEAM, UserRole.COMPLIANCE_OFFICER],
      },
      [JourneyStatus.APPROVED]: {
        label: 'Approved',
        description: 'Journey has been approved and is ready for deployment',
        responsibleRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN],
      },
      [JourneyStatus.SCHEDULED]: {
        label: 'Scheduled',
        description: 'Journey is scheduled to run',
        responsibleRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN],
      },
      [JourneyStatus.RUNNING]: {
        label: 'Running',
        description: 'Journey is currently active',
        responsibleRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN],
      },
      [JourneyStatus.PAUSED]: {
        label: 'Paused',
        description: 'Journey has been temporarily paused',
        responsibleRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN],
      },
      [JourneyStatus.COMPLETED]: {
        label: 'Completed',
        description: 'Journey has completed its run',
        responsibleRoles: [UserRole.ADMIN, UserRole.SUPER_ADMIN],
      },
      [JourneyStatus.REJECTED]: {
        label: 'Rejected',
        description: 'Journey has been rejected',
        responsibleRoles: [],
      },
      [JourneyStatus.ARCHIVED]: {
        label: 'Archived',
        description: 'Journey has been archived',
        responsibleRoles: [],
      },
    };

    return stageInfo[status];
  }

  // Notify stakeholders of status change
  private async notifyStakeholders(
    journey: Journey,
    newStatus: JourneyStatus,
    triggeredByUserId: string
  ): Promise<void> {
    try {
      // Get users to notify based on new status
      let rolesToNotify: UserRole[] = [];

      switch (newStatus) {
        case JourneyStatus.INTAKE:
          rolesToNotify = [UserRole.DMO_TEAM];
          break;
        case JourneyStatus.DMO_REVIEW:
          rolesToNotify = [UserRole.CX_TEAM];
          break;
        case JourneyStatus.CX_REVIEW:
          rolesToNotify = [UserRole.CONTROL_TEAM];
          break;
        case JourneyStatus.APPROVED:
          rolesToNotify = [UserRole.ADMIN, UserRole.JOURNEY_DEVELOPER];
          break;
        case JourneyStatus.REJECTED:
          rolesToNotify = [UserRole.BUSINESS_USER, UserRole.JOURNEY_DEVELOPER];
          break;
      }

      if (rolesToNotify.length === 0) return;

      // Get users with these roles
      const usersToNotify = await User.findAll({
        where: {
          role: rolesToNotify,
          status: 'active',
        },
      });

      const actionUrl = `${process.env.FRONTEND_URL}/journeys/${journey.id}`;

      // Send notifications
      for (const user of usersToNotify) {
        if (user.id !== triggeredByUserId) {
          await this.emailService.sendJourneyNotification(
            user.email,
            journey.name,
            newStatus,
            actionUrl
          );
        }
      }
    } catch (error) {
      logger.error('Failed to notify stakeholders:', error);
    }
  }

  // Get comment type for transition
  private getCommentTypeForTransition(newStatus: JourneyStatus): CommentType {
    switch (newStatus) {
      case JourneyStatus.APPROVED:
        return CommentType.APPROVAL;
      case JourneyStatus.REJECTED:
        return CommentType.REJECTION;
      case JourneyStatus.INTAKE:
      case JourneyStatus.DMO_REVIEW:
      case JourneyStatus.CX_REVIEW:
        return CommentType.REQUEST_CHANGE;
      default:
        return CommentType.GENERAL;
    }
  }

  // Get action label
  private getActionLabel(status: JourneyStatus): string {
    const labels: Record<JourneyStatus, string> = {
      [JourneyStatus.DRAFT]: 'Save as Draft',
      [JourneyStatus.INTAKE]: 'Submit for Review',
      [JourneyStatus.DMO_REVIEW]: 'Send to DMO Review',
      [JourneyStatus.CX_REVIEW]: 'Send to CX Review',
      [JourneyStatus.CONTROL_REVIEW]: 'Send to Control Review',
      [JourneyStatus.APPROVED]: 'Approve',
      [JourneyStatus.SCHEDULED]: 'Schedule',
      [JourneyStatus.RUNNING]: 'Start Journey',
      [JourneyStatus.PAUSED]: 'Pause',
      [JourneyStatus.COMPLETED]: 'Complete',
      [JourneyStatus.REJECTED]: 'Reject',
      [JourneyStatus.ARCHIVED]: 'Archive',
    };

    return labels[status] || status;
  }
}

export default WorkflowService;
