import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

export enum DataSourceType {
  POSTGRESQL = 'postgresql',
  MSSQL = 'mssql',
  ORACLE = 'oracle',
  MYSQL = 'mysql',
  SNOWFLAKE = 'snowflake',
  REDSHIFT = 'redshift',
  API = 'api',
  FILE = 'file',
}

export enum DataSourceStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  ERROR = 'error',
  TESTING = 'testing',
}

export interface IDataSourceConfig {
  host?: string;
  port?: number;
  database?: string;
  username?: string;
  password?: string;
  ssl?: boolean;
  connectionString?: string;
  apiUrl?: string;
  apiKey?: string;
  apiHeaders?: Record<string, string>;
  filePath?: string;
  fileFormat?: 'csv' | 'json' | 'xml' | 'parquet';
  additionalOptions?: Record<string, any>;
}

@Table({
  tableName: 'data_sources',
  timestamps: true,
  underscored: true,
})
export class DataSource extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @Column(DataType.TEXT)
  description?: string;

  @AllowNull(false)
  @Column(DataType.ENUM(...Object.values(DataSourceType)))
  type!: DataSourceType;

  @AllowNull(false)
  @Default(DataSourceStatus.INACTIVE)
  @Column(DataType.ENUM(...Object.values(DataSourceStatus)))
  status!: DataSourceStatus;

  @Column(DataType.JSONB)
  config!: IDataSourceConfig;

  @Column(DataType.TEXT)
  testQuery?: string;

  @Column(DataType.DATE)
  lastTestedAt?: Date;

  @Column(DataType.STRING(500))
  lastTestResult?: string;

  @Column(DataType.BOOLEAN)
  lastTestSuccess?: boolean;

  @Column(DataType.JSONB)
  schema?: {
    tables: string[];
    columns: Record<string, string[]>;
  };

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  createdBy!: string;

  @BelongsTo(() => User, 'createdBy')
  creator!: User;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  maskSensitiveData(): Partial<DataSource> {
    const data = this.toJSON();
    if (data.config) {
      if (data.config.password) {
        data.config.password = '********';
      }
      if (data.config.apiKey) {
        data.config.apiKey = '********';
      }
    }
    return data;
  }
}

export default DataSource;
