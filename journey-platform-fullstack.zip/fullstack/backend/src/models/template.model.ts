import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

export enum TemplateType {
  EMAIL = 'email',
  SMS = 'sms',
  PUSH = 'push',
  WHATSAPP = 'whatsapp',
}

export enum TemplateStatus {
  DRAFT = 'draft',
  PENDING_REVIEW = 'pending_review',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  ARCHIVED = 'archived',
}

export interface ITemplateVariable {
  name: string;
  type: 'string' | 'number' | 'date' | 'boolean' | 'array';
  defaultValue?: any;
  required?: boolean;
  description?: string;
}

@Table({
  tableName: 'templates',
  timestamps: true,
  underscored: true,
})
export class Template extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @Column(DataType.TEXT)
  description?: string;

  @AllowNull(false)
  @Default(TemplateType.EMAIL)
  @Column(DataType.ENUM(...Object.values(TemplateType)))
  type!: TemplateType;

  @AllowNull(false)
  @Default(TemplateStatus.DRAFT)
  @Column(DataType.ENUM(...Object.values(TemplateStatus)))
  status!: TemplateStatus;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  subject!: string;

  @AllowNull(false)
  @Column(DataType.TEXT)
  content!: string;

  @Column(DataType.TEXT)
  htmlContent?: string;

  @Column(DataType.TEXT)
  plainTextContent?: string;

  @Column(DataType.JSONB)
  variables?: ITemplateVariable[];

  @Column(DataType.STRING(255))
  previewImageUrl?: string;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  createdBy!: string;

  @BelongsTo(() => User, 'createdBy')
  creator!: User;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  reviewedBy?: string;

  @Column(DataType.DATE)
  reviewedAt?: Date;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  approvedBy?: string;

  @Column(DataType.DATE)
  approvedAt?: Date;

  @Column(DataType.TEXT)
  rejectionReason?: string;

  @Default(1)
  @Column(DataType.INTEGER)
  version!: number;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  isEditable(): boolean {
    return this.status === TemplateStatus.DRAFT || this.status === TemplateStatus.REJECTED;
  }

  getVariableNames(): string[] {
    const variableRegex = /\{\{(\w+)\}\}/g;
    const matches = this.content.match(variableRegex) || [];
    return matches.map(match => match.replace(/\{\{|\}\}/g, ''));
  }

  render(variables: Record<string, any>): { subject: string; content: string } {
    let renderedSubject = this.subject;
    let renderedContent = this.content;

    Object.entries(variables).forEach(([key, value]) => {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      renderedSubject = renderedSubject.replace(regex, String(value));
      renderedContent = renderedContent.replace(regex, String(value));
    });

    return { subject: renderedSubject, content: renderedContent };
  }

  validateVariables(variables: Record<string, any>): { valid: boolean; missing: string[] } {
    const requiredVars = this.variables?.filter(v => v.required).map(v => v.name) || [];
    const missing = requiredVars.filter(varName => !(varName in variables));
    return { valid: missing.length === 0, missing };
  }
}

export default Template;
