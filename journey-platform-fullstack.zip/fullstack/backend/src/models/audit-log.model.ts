import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

export enum AuditAction {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  STATUS_CHANGE = 'status_change',
  APPROVE = 'approve',
  REJECT = 'reject',
  LOGIN = 'login',
  LOGOUT = 'logout',
  PASSWORD_CHANGE = 'password_change',
  EXPORT = 'export',
  IMPORT = 'import',
  TEST_CONNECTION = 'test_connection',
  RUN = 'run',
  SCHEDULE = 'schedule',
  CANCEL = 'cancel',
}

@Table({
  tableName: 'audit_logs',
  timestamps: true,
  underscored: true,
})
export class AuditLog extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(50))
  entityType!: string;

  @AllowNull(false)
  @Column(DataType.UUID)
  entityId!: string;

  @AllowNull(false)
  @Column(DataType.ENUM(...Object.values(AuditAction)))
  action!: AuditAction;

  @Column(DataType.JSONB)
  oldValue?: any;

  @Column(DataType.JSONB)
  newValue?: any;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  performedBy!: string;

  @BelongsTo(() => User, 'performedBy')
  user!: User;

  @Column(DataType.STRING(255))
  ipAddress?: string;

  @Column(DataType.STRING(500))
  userAgent?: string;

  @Column(DataType.TEXT)
  notes?: string;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @CreatedAt
  createdAt!: Date;
}

export default AuditLog;
