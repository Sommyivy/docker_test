import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { Journey } from './journey.model';

export enum RunStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
  PARTIAL = 'partial',
}

export interface IRunMetrics {
  totalRecipients: number;
  processed: number;
  successful: number;
  failed: number;
  bounced: number;
  opened: number;
  clicked: number;
  converted: number;
  unsubscribed: number;
  openRate: number;
  clickRate: number;
  conversionRate: number;
  bounceRate: number;
  avgTimeToOpen?: number;
  avgTimeToClick?: number;
}

export interface IRunError {
  recipientId: string;
  error: string;
  timestamp: Date;
}

@Table({
  tableName: 'journey_runs',
  timestamps: true,
  underscored: true,
})
export class JourneyRun extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => Journey)
  @AllowNull(false)
  @Column(DataType.UUID)
  journeyId!: string;

  @BelongsTo(() => Journey)
  journey!: Journey;

  @AllowNull(false)
  @Default(RunStatus.PENDING)
  @Column(DataType.ENUM(...Object.values(RunStatus)))
  status!: RunStatus;

  @Column(DataType.INTEGER)
  batchNumber?: number;

  @Column(DataType.INTEGER)
  totalBatches?: number;

  @Column(DataType.DATE)
  startedAt?: Date;

  @Column(DataType.DATE)
  completedAt?: Date;

  @Column(DataType.DATE)
  scheduledAt?: Date;

  @Column(DataType.JSONB)
  metrics?: IRunMetrics;

  @Column(DataType.JSONB)
  errors?: IRunError[];

  @Column(DataType.TEXT)
  errorMessage?: string;

  @Column(DataType.STRING(255))
  triggeredBy?: string;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  getDuration(): number | null {
    if (!this.startedAt || !this.completedAt) return null;
    return this.completedAt.getTime() - this.startedAt.getTime();
  }

  getSuccessRate(): number {
    if (!this.metrics || this.metrics.totalRecipients === 0) return 0;
    return (this.metrics.successful / this.metrics.totalRecipients) * 100;
  }

  updateMetrics(metrics: Partial<IRunMetrics>): Promise<JourneyRun> {
    this.metrics = { ...this.metrics, ...metrics } as IRunMetrics;
    return this.save();
  }

  addError(error: IRunError): Promise<JourneyRun> {
    this.errors = this.errors || [];
    this.errors.push(error);
    return this.save();
  }
}

export default JourneyRun;
