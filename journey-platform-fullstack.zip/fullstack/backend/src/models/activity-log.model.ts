import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

export enum ActivityType {
  JOURNEY_CREATED = 'journey_created',
  JOURNEY_UPDATED = 'journey_updated',
  JOURNEY_APPROVED = 'journey_approved',
  JOURNEY_REJECTED = 'journey_rejected',
  JOURNEY_STARTED = 'journey_started',
  JOURNEY_COMPLETED = 'journey_completed',
  RULE_CREATED = 'rule_created',
  RULE_UPDATED = 'rule_updated',
  TEMPLATE_CREATED = 'template_created',
  TEMPLATE_APPROVED = 'template_approved',
  DATASOURCE_CREATED = 'datasource_created',
  DATASOURCE_TESTED = 'datasource_tested',
  USER_LOGIN = 'user_login',
  USER_LOGOUT = 'user_logout',
  USER_CREATED = 'user_created',
  PASSWORD_CHANGED = 'password_changed',
  SETTINGS_UPDATED = 'settings_updated',
}

@Table({
  tableName: 'activity_logs',
  timestamps: true,
  underscored: true,
})
export class ActivityLog extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.ENUM(...Object.values(ActivityType)))
  type!: ActivityType;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  userId!: string;

  @BelongsTo(() => User)
  user!: User;

  @Column(DataType.STRING(50))
  entityType?: string;

  @Column(DataType.UUID)
  entityId?: string;

  @Column(DataType.STRING(255))
  entityName?: string;

  @Column(DataType.TEXT)
  description?: string;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @Column(DataType.STRING(255))
  ipAddress?: string;

  @CreatedAt
  createdAt!: Date;
}

export default ActivityLog;
