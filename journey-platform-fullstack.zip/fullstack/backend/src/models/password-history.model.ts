import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

@Table({
  tableName: 'password_history',
  timestamps: true,
  underscored: true,
})
export class PasswordHistory extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  userId!: string;

  @BelongsTo(() => User)
  user!: User;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  password!: string;

  @CreatedAt
  createdAt!: Date;

  // Static method to check if password was used before
  static async wasPasswordUsed(userId: string, newPassword: string): Promise<boolean> {
    const historyCount = parseInt(process.env.PASSWORD_HISTORY_COUNT || '5');
    const history = await PasswordHistory.findAll({
      where: { userId },
      order: [['createdAt', 'DESC']],
      limit: historyCount,
    });

    for (const record of history) {
      const bcrypt = require('bcryptjs');
      if (await bcrypt.compare(newPassword, record.password)) {
        return true;
      }
    }

    return false;
  }

  // Static method to add password to history
  static async addToHistory(userId: string, password: string): Promise<void> {
    await PasswordHistory.create({
      userId,
      password,
    });

    // Clean up old entries beyond the history limit
    const historyCount = parseInt(process.env.PASSWORD_HISTORY_COUNT || '5');
    const allHistory = await PasswordHistory.findAll({
      where: { userId },
      order: [['createdAt', 'DESC']],
    });

    if (allHistory.length > historyCount) {
      const entriesToDelete = allHistory.slice(historyCount);
      for (const entry of entriesToDelete) {
        await entry.destroy();
      }
    }
  }
}

export default PasswordHistory;
