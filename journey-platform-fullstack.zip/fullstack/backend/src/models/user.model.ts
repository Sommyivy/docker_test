import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  Unique,
  CreatedAt,
  UpdatedAt,
  HasMany,
  BeforeCreate,
  BeforeUpdate,
} from 'sequelize-typescript';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export enum UserRole {
  SUPER_ADMIN = 'super_admin',
  ADMIN = 'admin',
  BUSINESS_USER = 'business_user',
  DMO_TEAM = 'dmo_team',
  CX_TEAM = 'cx_team',
  CONTROL_TEAM = 'control_team',
  JOURNEY_DEVELOPER = 'journey_developer',
  COMMUNICATIONS_REVIEWER = 'communications_reviewer',
  COMPLIANCE_OFFICER = 'compliance_officer',
  VIEWER = 'viewer',
}

export enum UserStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  LOCKED = 'locked',
  PENDING_PASSWORD_CHANGE = 'pending_password_change',
}

export interface IUserPermissions {
  journeys: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    approve: boolean;
  };
  rules: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
  };
  templates: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    approve: boolean;
  };
  datasources: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
    test: boolean;
  };
  users: {
    view: boolean;
    create: boolean;
    edit: boolean;
    delete: boolean;
  };
  reports: {
    view: boolean;
    export: boolean;
  };
  admin: {
    view: boolean;
    configure: boolean;
  };
}

@Table({
  tableName: 'users',
  timestamps: true,
  underscored: true,
})
export class User extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(100))
  firstName!: string;

  @AllowNull(false)
  @Column(DataType.STRING(100))
  lastName!: string;

  @Unique
  @AllowNull(false)
  @Column(DataType.STRING(255))
  email!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  password!: string;

  @Column(DataType.STRING(20))
  phone?: string;

  @AllowNull(false)
  @Default(UserRole.VIEWER)
  @Column(DataType.ENUM(...Object.values(UserRole)))
  role!: UserRole;

  @AllowNull(false)
  @Default(UserStatus.PENDING_PASSWORD_CHANGE)
  @Column(DataType.ENUM(...Object.values(UserStatus)))
  status!: UserStatus;

  @Column(DataType.STRING(100))
  department?: string;

  @Column(DataType.STRING(100))
  jobTitle?: string;

  @Default(false)
  @Column(DataType.BOOLEAN)
  isTemporaryPassword!: boolean;

  @Column(DataType.INTEGER)
  loginAttempts?: number;

  @Column(DataType.DATE)
  lastLoginAt?: Date;

  @Column(DataType.DATE)
  lockedUntil?: Date;

  @Column(DataType.DATE)
  passwordChangedAt?: Date;

  @Column(DataType.DATE)
  lastActivityAt?: Date;

  @Column(DataType.JSONB)
  permissions?: IUserPermissions;

  @Default(true)
  @Column(DataType.BOOLEAN)
  emailNotifications!: boolean;

  @Default(true)
  @Column(DataType.BOOLEAN)
  pushNotifications!: boolean;

  @Column(DataType.STRING(255))
  avatarUrl?: string;

  @Column(DataType.TEXT)
  notes?: string;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  @Column(DataType.UUID)
  createdBy?: string;

  // Virtual fields
  get fullName(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  // Hash password before saving
  @BeforeCreate
  @BeforeUpdate
  static async hashPassword(instance: User) {
    if (instance.changed('password')) {
      const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || '12');
      instance.password = await bcrypt.hash(instance.password, saltRounds);
    }
  }

  // Instance methods
  async comparePassword(candidatePassword: string): Promise<boolean> {
    return bcrypt.compare(candidatePassword, this.password);
  }

  isLocked(): boolean {
    if (!this.lockedUntil) return false;
    return new Date() < this.lockedUntil;
  }

  incrementLoginAttempts(): Promise<User> {
    const maxAttempts = parseInt(process.env.MAX_LOGIN_ATTEMPTS || '5');
    this.loginAttempts = (this.loginAttempts || 0) + 1;
    
    if (this.loginAttempts >= maxAttempts) {
      const lockoutMinutes = parseInt(process.env.LOCKOUT_DURATION_MINUTES || '30');
      this.lockedUntil = new Date(Date.now() + lockoutMinutes * 60000);
      this.status = UserStatus.LOCKED;
    }
    
    return this.save();
  }

  resetLoginAttempts(): Promise<User> {
    this.loginAttempts = 0;
    this.lockedUntil = undefined as any;
    if (this.status === UserStatus.LOCKED) {
      this.status = UserStatus.ACTIVE;
    }
    return this.save();
  }

  updateLastLogin(): Promise<User> {
    this.lastLoginAt = new Date();
    this.lastActivityAt = new Date();
    return this.save();
  }

  // Default permissions based on role
  static getDefaultPermissions(role: UserRole): IUserPermissions {
    const basePermissions: IUserPermissions = {
      journeys: { view: false, create: false, edit: false, delete: false, approve: false },
      rules: { view: false, create: false, edit: false, delete: false },
      templates: { view: false, create: false, edit: false, delete: false, approve: false },
      datasources: { view: false, create: false, edit: false, delete: false, test: false },
      users: { view: false, create: false, edit: false, delete: false },
      reports: { view: false, export: false },
      admin: { view: false, configure: false },
    };

    switch (role) {
      case UserRole.SUPER_ADMIN:
        return {
          journeys: { view: true, create: true, edit: true, delete: true, approve: true },
          rules: { view: true, create: true, edit: true, delete: true },
          templates: { view: true, create: true, edit: true, delete: true, approve: true },
          datasources: { view: true, create: true, edit: true, delete: true, test: true },
          users: { view: true, create: true, edit: true, delete: true },
          reports: { view: true, export: true },
          admin: { view: true, configure: true },
        };

      case UserRole.ADMIN:
        return {
          journeys: { view: true, create: true, edit: true, delete: true, approve: true },
          rules: { view: true, create: true, edit: true, delete: true },
          templates: { view: true, create: true, edit: true, delete: false, approve: true },
          datasources: { view: true, create: true, edit: true, delete: false, test: true },
          users: { view: true, create: true, edit: true, delete: false },
          reports: { view: true, export: true },
          admin: { view: true, configure: true },
        };

      case UserRole.BUSINESS_USER:
        return {
          journeys: { view: true, create: true, edit: true, delete: false, approve: false },
          rules: { view: true, create: false, edit: false, delete: false },
          templates: { view: true, create: false, edit: false, delete: false, approve: false },
          datasources: { view: true, create: false, edit: false, delete: false, test: false },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: true },
          admin: { view: false, configure: false },
        };

      case UserRole.DMO_TEAM:
        return {
          journeys: { view: true, create: false, edit: true, delete: false, approve: false },
          rules: { view: true, create: true, edit: true, delete: false },
          templates: { view: true, create: false, edit: false, delete: false, approve: false },
          datasources: { view: true, create: false, edit: false, delete: false, test: true },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: true },
          admin: { view: false, configure: false },
        };

      case UserRole.CX_TEAM:
        return {
          journeys: { view: true, create: false, edit: false, delete: false, approve: true },
          rules: { view: true, create: false, edit: false, delete: false },
          templates: { view: true, create: true, edit: true, delete: false, approve: true },
          datasources: { view: false, create: false, edit: false, delete: false, test: false },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: true },
          admin: { view: false, configure: false },
        };

      case UserRole.CONTROL_TEAM:
        return {
          journeys: { view: true, create: false, edit: false, delete: false, approve: true },
          rules: { view: true, create: false, edit: false, delete: false },
          templates: { view: true, create: false, edit: false, delete: false, approve: true },
          datasources: { view: true, create: false, edit: false, delete: false, test: false },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: true },
          admin: { view: true, configure: false },
        };

      case UserRole.JOURNEY_DEVELOPER:
        return {
          journeys: { view: true, create: true, edit: true, delete: false, approve: false },
          rules: { view: true, create: true, edit: true, delete: false },
          templates: { view: true, create: true, edit: true, delete: false, approve: false },
          datasources: { view: true, create: false, edit: false, delete: false, test: true },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: true },
          admin: { view: false, configure: false },
        };

      default:
        return {
          journeys: { view: true, create: false, edit: false, delete: false, approve: false },
          rules: { view: true, create: false, edit: false, delete: false },
          templates: { view: true, create: false, edit: false, delete: false, approve: false },
          datasources: { view: true, create: false, edit: false, delete: false, test: false },
          users: { view: false, create: false, edit: false, delete: false },
          reports: { view: true, export: false },
          admin: { view: false, configure: false },
        };
    }
  }
}

export default User;
