import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

@Table({
  tableName: 'user_sessions',
  timestamps: true,
  underscored: true,
})
export class UserSession extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  userId!: string;

  @BelongsTo(() => User)
  user!: User;

  @AllowNull(false)
  @Column(DataType.STRING(500))
  token!: string;

  @AllowNull(false)
  @Column(DataType.STRING(500))
  refreshToken!: string;

  @Column(DataType.DATE)
  expiresAt!: Date;

  @Column(DataType.DATE)
  refreshExpiresAt!: Date;

  @Column(DataType.STRING(255))
  ipAddress?: string;

  @Column(DataType.STRING(500))
  userAgent?: string;

  @Column(DataType.STRING(100))
  deviceType?: string;

  @Column(DataType.STRING(100))
  browser?: string;

  @Column(DataType.STRING(100))
  os?: string;

  @Column(DataType.STRING(100))
  location?: string;

  @Default(false)
  @Column(DataType.BOOLEAN)
  isRevoked!: boolean;

  @Column(DataType.DATE)
  revokedAt?: Date;

  @Column(DataType.DATE)
  lastActivityAt?: Date;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  isExpired(): boolean {
    return new Date() > this.expiresAt;
  }

  isRefreshExpired(): boolean {
    return new Date() > this.refreshExpiresAt;
  }

  isValid(): boolean {
    return !this.isRevoked && !this.isExpired();
  }

  revoke(): Promise<UserSession> {
    this.isRevoked = true;
    this.revokedAt = new Date();
    return this.save();
  }

  updateActivity(): Promise<UserSession> {
    this.lastActivityAt = new Date();
    return this.save();
  }
}

export default UserSession;
