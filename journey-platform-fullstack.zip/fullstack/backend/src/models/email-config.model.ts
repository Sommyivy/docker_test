import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';

export enum EmailProvider {
  SMTP = 'smtp',
  SENDGRID = 'sendgrid',
  MAILGUN = 'mailgun',
  AWS_SES = 'aws_ses',
}

@Table({
  tableName: 'email_configs',
  timestamps: true,
  underscored: true,
})
export class EmailConfig extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @Column(DataType.TEXT)
  description?: string;

  @AllowNull(false)
  @Default(EmailProvider.SMTP)
  @Column(DataType.ENUM(...Object.values(EmailProvider)))
  provider!: EmailProvider;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  host!: string;

  @AllowNull(false)
  @Column(DataType.INTEGER)
  port!: number;

  @Default(false)
  @Column(DataType.BOOLEAN)
  secure!: boolean;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  username!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  password!: string;

  @Column(DataType.STRING(255))
  fromName?: string;

  @Column(DataType.STRING(255))
  fromEmail?: string;

  @Default(10000)
  @Column(DataType.INTEGER)
  dailyLimit!: number;

  @Default(0)
  @Column(DataType.INTEGER)
  dailySent!: number;

  @Column(DataType.DATE)
  lastResetAt?: Date;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @Default(false)
  @Column(DataType.BOOLEAN)
  isDefault!: boolean;

  @Column(DataType.DATE)
  lastTestedAt?: Date;

  @Column(DataType.BOOLEAN)
  lastTestSuccess?: boolean;

  @Column(DataType.STRING(500))
  lastTestResult?: string;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  maskPassword(): Partial<EmailConfig> {
    const data = this.toJSON();
    data.password = '********';
    return data;
  }

  canSendEmail(): boolean {
    return this.isActive && this.dailySent < this.dailyLimit;
  }

  incrementDailySent(): Promise<EmailConfig> {
    this.dailySent += 1;
    return this.save();
  }

  resetDailyCount(): Promise<EmailConfig> {
    this.dailySent = 0;
    this.lastResetAt = new Date();
    return this.save();
  }
}

export default EmailConfig;
