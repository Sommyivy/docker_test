import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';

export enum RotationStrategy {
  ROUND_ROBIN = 'round_robin',
  RANDOM = 'random',
  LEAST_USED = 'least_used',
  WEIGHTED = 'weighted',
}

@Table({
  tableName: 'email_aliases',
  timestamps: true,
  underscored: true,
})
export class EmailAlias extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  email!: string;

  @Column(DataType.TEXT)
  description?: string;

  @Default(10000)
  @Column(DataType.INTEGER)
  dailyLimit!: number;

  @Default(0)
  @Column(DataType.INTEGER)
  dailySent!: number;

  @Default(0)
  @Column(DataType.INTEGER)
  totalSent!: number;

  @Column(DataType.DATE)
  lastResetAt?: Date;

  @Column(DataType.DATE)
  lastUsedAt?: Date;

  @Default(1)
  @Column(DataType.INTEGER)
  weight!: number;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  canSend(): boolean {
    return this.isActive && this.dailySent < this.dailyLimit;
  }

  recordUsage(): Promise<EmailAlias> {
    this.dailySent += 1;
    this.totalSent += 1;
    this.lastUsedAt = new Date();
    return this.save();
  }

  resetDailyCount(): Promise<EmailAlias> {
    this.dailySent = 0;
    this.lastResetAt = new Date();
    return this.save();
  }

  getUsagePercentage(): number {
    return (this.dailySent / this.dailyLimit) * 100;
  }
}

export default EmailAlias;
