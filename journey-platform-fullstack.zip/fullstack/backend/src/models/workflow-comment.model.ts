import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';
import { Journey } from './journey.model';

export enum CommentType {
  GENERAL = 'general',
  APPROVAL = 'approval',
  REJECTION = 'rejection',
  REQUEST_CHANGE = 'request_change',
  NOTE = 'note',
}

@Table({
  tableName: 'workflow_comments',
  timestamps: true,
  underscored: true,
})
export class WorkflowComment extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @ForeignKey(() => Journey)
  @AllowNull(false)
  @Column(DataType.UUID)
  journeyId!: string;

  @BelongsTo(() => Journey)
  journey!: Journey;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  userId!: string;

  @BelongsTo(() => User)
  user!: User;

  @AllowNull(false)
  @Column(DataType.TEXT)
  content!: string;

  @AllowNull(false)
  @Default(CommentType.GENERAL)
  @Column(DataType.ENUM(...Object.values(CommentType)))
  type!: CommentType;

  @Column(DataType.STRING(50))
  stage?: string;

  @Column(DataType.UUID)
  parentId?: string;

  @Default(false)
  @Column(DataType.BOOLEAN)
  isEdited!: boolean;

  @Column(DataType.DATE)
  editedAt?: Date;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;
}

export default WorkflowComment;
