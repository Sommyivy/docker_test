import {
  Table,
  Column,
  Model,
  DataType,
  PrimaryKey,
  Default,
  AllowNull,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
} from 'sequelize-typescript';
import { v4 as uuidv4 } from 'uuid';
import { User } from './user.model';

export enum RuleType {
  SEGMENTATION = 'segmentation',
  TRIGGER = 'trigger',
  FILTER = 'filter',
  SCORING = 'scoring',
  CUSTOM = 'custom',
}

export enum RuleStatus {
  DRAFT = 'draft',
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  ARCHIVED = 'archived',
}

export interface IRuleCondition {
  field: string;
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains' | 'in' | 'between' | 'exists';
  value: any;
  connector?: 'AND' | 'OR';
}

export interface IRuleAction {
  type: 'include' | 'exclude' | 'tag' | 'score' | 'notify';
  config: Record<string, any>;
}

@Table({
  tableName: 'rules',
  timestamps: true,
  underscored: true,
})
export class Rule extends Model {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id!: string;

  @AllowNull(false)
  @Column(DataType.STRING(255))
  name!: string;

  @Column(DataType.TEXT)
  description?: string;

  @AllowNull(false)
  @Default(RuleType.SEGMENTATION)
  @Column(DataType.ENUM(...Object.values(RuleType)))
  type!: RuleType;

  @AllowNull(false)
  @Default(RuleStatus.DRAFT)
  @Column(DataType.ENUM(...Object.values(RuleStatus)))
  status!: RuleStatus;

  @Column(DataType.JSONB)
  conditions?: IRuleCondition[];

  @Column(DataType.JSONB)
  actions?: IRuleAction[];

  @Column(DataType.TEXT)
  sqlQuery?: string;

  @Column(DataType.JSONB)
  dataSourceConfig?: {
    sourceId: string;
    tableName: string;
    fields: string[];
  };

  @Column(DataType.INTEGER)
  estimatedAudienceSize?: number;

  @Column(DataType.INTEGER)
  lastExecutionCount?: number;

  @Column(DataType.DATE)
  lastExecutedAt?: Date;

  @ForeignKey(() => User)
  @AllowNull(false)
  @Column(DataType.UUID)
  createdBy!: string;

  @BelongsTo(() => User, 'createdBy')
  creator!: User;

  @ForeignKey(() => User)
  @Column(DataType.UUID)
  approvedBy?: string;

  @Column(DataType.DATE)
  approvedAt?: Date;

  @Default(1)
  @Column(DataType.INTEGER)
  version!: number;

  @Column(DataType.JSONB)
  metadata?: Record<string, any>;

  @Default(true)
  @Column(DataType.BOOLEAN)
  isActive!: boolean;

  @CreatedAt
  createdAt!: Date;

  @UpdatedAt
  updatedAt!: Date;

  // Instance methods
  isEditable(): boolean {
    return this.status === RuleStatus.DRAFT || this.status === RuleStatus.INACTIVE;
  }

  canActivate(): boolean {
    return this.status === RuleStatus.DRAFT || this.status === RuleStatus.INACTIVE;
  }

  async activate(userId: string): Promise<void> {
    if (!this.canActivate()) {
      throw new Error(`Cannot activate rule in ${this.status} status`);
    }
    this.status = RuleStatus.ACTIVE;
    await this.save();
  }

  async deactivate(): Promise<void> {
    if (this.status !== RuleStatus.ACTIVE) {
      throw new Error('Can only deactivate active rules');
    }
    this.status = RuleStatus.INACTIVE;
    await this.save();
  }
}

export default Rule;
