import { Request, Response, NextFunction } from 'express';
import { Journey, JourneyStatus } from '../models/journey.model';
import { WorkflowComment } from '../models/workflow-comment.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { User } from '../models/user.model';
import { AppError } from '../middleware/error.middleware';
import { EmailService } from '../services/email.service';
import { logger } from '../utils/logger';

const WORKFLOW_STAGES = [
  { stage: 'draft', label: 'Draft', description: 'Journey is being prepared', role: 'business_user' },
  { stage: 'intake', label: 'Intake', description: 'Journey submitted for review', role: 'dmo_team' },
  { stage: 'dmo_review', label: 'DMO Review', description: 'Data & analytics team review', role: 'dmo_team' },
  { stage: 'cx_review', label: 'CX Review', description: 'Customer experience team review', role: 'cx_team' },
  { stage: 'control_review', label: 'Control Review', description: 'Compliance & control team review', role: 'control_team' },
  { stage: 'approved', label: 'Approved', description: 'Journey approved and ready to launch', role: 'system' },
  { stage: 'scheduled', label: 'Scheduled', description: 'Journey scheduled for launch', role: 'system' },
  { stage: 'running', label: 'Running', description: 'Journey is live and running', role: 'system' },
  { stage: 'paused', label: 'Paused', description: 'Journey temporarily paused', role: 'system' },
  { stage: 'completed', label: 'Completed', description: 'Journey completed', role: 'system' },
  { stage: 'archived', label: 'Archived', description: 'Journey archived', role: 'system' },
];

export class WorkflowController {
  private emailService = EmailService.getInstance();

  getStages = async (req: Request, res: Response, next: NextFunction) => {
    try {
      res.json({ success: true, data: WORKFLOW_STAGES });
    } catch (error) {
      next(error);
    }
  };

  getHistory = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const [comments, auditLogs] = await Promise.all([
        WorkflowComment.findAll({
          where: { journeyId: req.params.id },
          include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
          order: [['createdAt', 'ASC']],
        }),
        AuditLog.findAll({
          where: { entityType: 'journey', entityId: req.params.id },
          include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
          order: [['createdAt', 'ASC']],
        }),
      ]);

      res.json({ success: true, data: { journey, comments, auditLogs } });
    } catch (error) {
      next(error);
    }
  };

  submit = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);
      if (journey.status !== JourneyStatus.DRAFT) throw new AppError('Only draft journeys can be submitted', 400);

      await journey.transitionTo(JourneyStatus.INTAKE, req.user!.id, req.body.notes);
      await this.addSystemComment(journey.id, req.user!.id, 'Journey submitted for review', 'intake');

      res.json({ success: true, data: journey, message: 'Journey submitted for review' });
    } catch (error) {
      next(error);
    }
  };

  approve = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const approvalFlow: Record<string, JourneyStatus> = {
        [JourneyStatus.INTAKE]: JourneyStatus.DMO_REVIEW,
        [JourneyStatus.DMO_REVIEW]: JourneyStatus.CX_REVIEW,
        [JourneyStatus.CX_REVIEW]: JourneyStatus.CONTROL_REVIEW,
        [JourneyStatus.CONTROL_REVIEW]: JourneyStatus.APPROVED,
      };

      const nextStatus = approvalFlow[journey.status];
      if (!nextStatus) throw new AppError(`Journey cannot be approved from ${journey.status} status`, 400);

      const { notes } = req.body;
      await journey.transitionTo(nextStatus, req.user!.id, notes);

      if (notes) {
        await WorkflowComment.create({
          journeyId: journey.id, userId: req.user!.id,
          content: notes, type: 'approval', stage: nextStatus,
        });
      }

      logger.info('Journey approved:', { journeyId: journey.id, by: req.user!.id, newStatus: nextStatus });
      res.json({ success: true, data: journey, message: `Journey moved to ${nextStatus}` });
    } catch (error) {
      next(error);
    }
  };

  reject = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const rejectableStatuses = [JourneyStatus.INTAKE, JourneyStatus.DMO_REVIEW, JourneyStatus.CX_REVIEW, JourneyStatus.CONTROL_REVIEW];
      if (!rejectableStatuses.includes(journey.status)) {
        throw new AppError(`Journey cannot be rejected from ${journey.status} status`, 400);
      }

      await journey.transitionTo(JourneyStatus.REJECTED, req.user!.id, req.body.reason);
      await WorkflowComment.create({
        journeyId: journey.id, userId: req.user!.id,
        content: req.body.reason || 'Journey rejected', type: 'rejection', stage: journey.status,
      });

      res.json({ success: true, data: journey, message: 'Journey rejected' });
    } catch (error) {
      next(error);
    }
  };

  requestChanges = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      await WorkflowComment.create({
        journeyId: journey.id, userId: req.user!.id,
        content: req.body.comment || 'Changes requested', type: 'request_change', stage: journey.status,
      });

      res.json({ success: true, message: 'Change request submitted' });
    } catch (error) {
      next(error);
    }
  };

  addComment = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const comment = await WorkflowComment.create({
        journeyId: req.params.id, userId: req.user!.id,
        content: req.body.content, type: req.body.type || 'general',
        stage: journey.status, parentId: req.body.parentId,
      });

      const withUser = await WorkflowComment.findByPk(comment.id, {
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
      });

      res.status(201).json({ success: true, data: withUser });
    } catch (error) {
      next(error);
    }
  };

  getComments = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const comments = await WorkflowComment.findAll({
        where: { journeyId: req.params.id },
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
        order: [['createdAt', 'ASC']],
      });
      res.json({ success: true, data: comments });
    } catch (error) {
      next(error);
    }
  };

  private async addSystemComment(journeyId: string, userId: string, content: string, stage: string): Promise<void> {
    try {
      await WorkflowComment.create({ journeyId, userId, content, type: 'general', stage });
    } catch (error) {
      logger.warn('Failed to add system comment:', error);
    }
  }
}

export default WorkflowController;
