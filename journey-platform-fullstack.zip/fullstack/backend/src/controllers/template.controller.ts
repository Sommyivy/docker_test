import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { Template, TemplateStatus } from '../models/template.model';
import { User } from '../models/user.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';

export class TemplateController {
  getAll = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, search, type, status, sortBy = 'createdAt', sortOrder = 'desc' } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);

      const where: any = {};
      if (search) where[Op.or] = [
        { name: { [Op.iLike]: `%${search}%` } },
        { subject: { [Op.iLike]: `%${search}%` } },
      ];
      if (type) where.type = type;
      if (status) where.status = status;

      const { count, rows } = await Template.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [[sortBy, sortOrder.toUpperCase()]],
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      res.json({
        success: true,
        data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.findByPk(req.params.id, {
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });
      if (!template) throw new AppError('Template not found', 404);
      res.json({ success: true, data: template });
    } catch (error) {
      next(error);
    }
  };

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.create({ ...req.body, createdBy: req.user!.id, version: 1 });
      await AuditLog.create({
        entityType: 'template', entityId: template.id,
        action: AuditAction.CREATE, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });
      logger.info('Template created:', { templateId: template.id, createdBy: req.user!.id });
      res.status(201).json({ success: true, data: template });
    } catch (error) {
      next(error);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.findByPk(req.params.id);
      if (!template) throw new AppError('Template not found', 404);
      if (!template.isEditable()) throw new AppError('Template cannot be edited in its current status', 400);

      const oldValue = template.toJSON();
      await template.update({ ...req.body, version: template.version + 1 });
      await AuditLog.create({
        entityType: 'template', entityId: template.id,
        action: AuditAction.UPDATE, oldValue, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, data: template });
    } catch (error) {
      next(error);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.findByPk(req.params.id);
      if (!template) throw new AppError('Template not found', 404);
      await template.update({ status: TemplateStatus.ARCHIVED, isActive: false });
      await AuditLog.create({
        entityType: 'template', entityId: template.id,
        action: AuditAction.DELETE, performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, message: 'Template archived successfully' });
    } catch (error) {
      next(error);
    }
  };

  review = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.findByPk(req.params.id);
      if (!template) throw new AppError('Template not found', 404);

      const { approved, reason } = req.body;
      await template.update({
        status: approved ? TemplateStatus.APPROVED : TemplateStatus.REJECTED,
        reviewedBy: req.user!.id,
        reviewedAt: new Date(),
        approvedBy: approved ? req.user!.id : undefined,
        approvedAt: approved ? new Date() : undefined,
        rejectionReason: !approved ? reason : undefined,
      });

      await AuditLog.create({
        entityType: 'template', entityId: template.id,
        action: approved ? AuditAction.APPROVE : AuditAction.REJECT,
        performedBy: req.user!.id, ipAddress: req.ip,
        notes: reason,
      });

      res.json({ success: true, data: template, message: approved ? 'Template approved' : 'Template rejected' });
    } catch (error) {
      next(error);
    }
  };

  preview = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const template = await Template.findByPk(req.params.id);
      if (!template) throw new AppError('Template not found', 404);
      const variables = req.body.variables || {};
      const rendered = template.render(variables);
      res.json({ success: true, data: rendered });
    } catch (error) {
      next(error);
    }
  };

  duplicate = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const original = await Template.findByPk(req.params.id);
      if (!original) throw new AppError('Template not found', 404);
      const { id, createdAt, updatedAt, status, approvedAt, approvedBy, reviewedAt, reviewedBy, ...data } = original.toJSON();
      const copy = await Template.create({
        ...data,
        name: `${original.name} (Copy)`,
        status: TemplateStatus.DRAFT,
        version: 1,
        createdBy: req.user!.id,
      });
      res.status(201).json({ success: true, data: copy });
    } catch (error) {
      next(error);
    }
  };
}

export default TemplateController;
