import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { Rule, RuleStatus } from '../models/rule.model';
import { User } from '../models/user.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';

export class RuleController {
  getAll = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, search, type, status, sortBy = 'createdAt', sortOrder = 'desc' } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);

      const where: any = {};
      if (search) where.name = { [Op.iLike]: `%${search}%` };
      if (type) where.type = type;
      if (status) where.status = status;

      const { count, rows } = await Rule.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [[sortBy, sortOrder.toUpperCase()]],
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      res.json({
        success: true,
        data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id, {
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });
      if (!rule) throw new AppError('Rule not found', 404);
      res.json({ success: true, data: rule });
    } catch (error) {
      next(error);
    }
  };

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.create({ ...req.body, createdBy: req.user!.id, version: 1 });
      await AuditLog.create({
        entityType: 'rule', entityId: rule.id,
        action: AuditAction.CREATE, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });
      logger.info('Rule created:', { ruleId: rule.id, createdBy: req.user!.id });
      res.status(201).json({ success: true, data: rule });
    } catch (error) {
      next(error);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id);
      if (!rule) throw new AppError('Rule not found', 404);
      if (!rule.isEditable()) throw new AppError('Rule cannot be edited in its current status', 400);

      const oldValue = rule.toJSON();
      await rule.update({ ...req.body, version: rule.version + 1 });
      await AuditLog.create({
        entityType: 'rule', entityId: rule.id,
        action: AuditAction.UPDATE, oldValue, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, data: rule });
    } catch (error) {
      next(error);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id);
      if (!rule) throw new AppError('Rule not found', 404);
      await rule.update({ status: RuleStatus.ARCHIVED, isActive: false });
      await AuditLog.create({
        entityType: 'rule', entityId: rule.id,
        action: AuditAction.DELETE, performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, message: 'Rule archived successfully' });
    } catch (error) {
      next(error);
    }
  };

  activate = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id);
      if (!rule) throw new AppError('Rule not found', 404);
      await rule.activate(req.user!.id);
      res.json({ success: true, data: rule, message: 'Rule activated' });
    } catch (error) {
      next(error);
    }
  };

  deactivate = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id);
      if (!rule) throw new AppError('Rule not found', 404);
      await rule.deactivate();
      res.json({ success: true, data: rule, message: 'Rule deactivated' });
    } catch (error) {
      next(error);
    }
  };

  test = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const rule = await Rule.findByPk(req.params.id);
      if (!rule) throw new AppError('Rule not found', 404);
      // Simulate rule test — real implementation would query the data source
      const estimatedCount = Math.floor(Math.random() * 50000) + 1000;
      await rule.update({ estimatedAudienceSize: estimatedCount, lastExecutedAt: new Date() });
      res.json({ success: true, data: { estimatedAudienceSize: estimatedCount, executedAt: new Date() } });
    } catch (error) {
      next(error);
    }
  };
}

export default RuleController;
