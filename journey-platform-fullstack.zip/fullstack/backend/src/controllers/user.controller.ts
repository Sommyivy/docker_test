import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { User, UserRole, UserStatus } from '../models/user.model';
import { UserSession } from '../models/user-session.model';
import { AppError } from '../middleware/error.middleware';
import { EmailService } from '../services/email.service';
import { logger } from '../utils/logger';
import { v4 as uuidv4 } from 'uuid';

export class UserController {
  private emailService = EmailService.getInstance();

  getAll = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, search, role, status, sortBy = 'createdAt', sortOrder = 'desc' } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);

      const where: any = {};
      if (search) {
        where[Op.or] = [
          { firstName: { [Op.iLike]: `%${search}%` } },
          { lastName: { [Op.iLike]: `%${search}%` } },
          { email: { [Op.iLike]: `%${search}%` } },
        ];
      }
      if (role) where.role = role;
      if (status) where.status = status;

      const { count, rows } = await User.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [[sortBy, sortOrder.toUpperCase()]],
        attributes: { exclude: ['password'] },
      });

      res.json({
        success: true,
        data: rows,
        pagination: {
          total: count,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(count / Number(limit)),
        },
      });
    } catch (error) {
      next(error);
    }
  };

  getMe = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = req.user!;
      res.json({
        success: true,
        data: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          fullName: user.fullName,
          role: user.role,
          status: user.status,
          department: user.department,
          jobTitle: user.jobTitle,
          phone: user.phone,
          avatarUrl: user.avatarUrl,
          permissions: user.permissions || User.getDefaultPermissions(user.role),
          isTemporaryPassword: user.isTemporaryPassword,
          emailNotifications: user.emailNotifications,
          pushNotifications: user.pushNotifications,
          lastLoginAt: user.lastLoginAt,
          createdAt: user.createdAt,
        },
      });
    } catch (error) {
      next(error);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await User.findByPk(req.params.id, {
        attributes: { exclude: ['password'] },
      });
      if (!user) throw new AppError('User not found', 404);
      res.json({ success: true, data: user });
    } catch (error) {
      next(error);
    }
  };

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const existing = await User.findOne({ where: { email: req.body.email } });
      if (existing) throw new AppError('A user with this email already exists', 409);

      // Generate temporary password
      const tempPassword = this.generateTempPassword();

      const user = await User.create({
        ...req.body,
        password: tempPassword,
        isTemporaryPassword: true,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        permissions: User.getDefaultPermissions(req.body.role),
        createdBy: req.user!.id,
      });

      // Send welcome email
      try {
        await this.emailService.sendWelcomeEmail(user.email, user.fullName, tempPassword);
      } catch (emailError) {
        logger.warn('Failed to send welcome email:', emailError);
      }

      logger.info('User created:', { userId: user.id, createdBy: req.user!.id });

      const { password, ...userWithoutPassword } = user.toJSON();
      res.status(201).json({ success: true, data: userWithoutPassword, message: 'User created successfully. A welcome email has been sent.' });
    } catch (error) {
      next(error);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await User.findByPk(req.params.id);
      if (!user) throw new AppError('User not found', 404);

      // Prevent self-demotion from super_admin
      if (req.user!.id === user.id && req.body.role && req.body.role !== user.role) {
        if (user.role === UserRole.SUPER_ADMIN) {
          throw new AppError('Cannot change your own super admin role', 400);
        }
      }

      if (req.body.email && req.body.email !== user.email) {
        const existing = await User.findOne({ where: { email: req.body.email } });
        if (existing) throw new AppError('Email already in use', 409);
      }

      // Update permissions if role changed
      if (req.body.role && req.body.role !== user.role) {
        req.body.permissions = User.getDefaultPermissions(req.body.role);
      }

      await user.update(req.body);
      logger.info('User updated:', { userId: user.id, updatedBy: req.user!.id });

      const { password, ...userWithoutPassword } = user.toJSON();
      res.json({ success: true, data: userWithoutPassword });
    } catch (error) {
      next(error);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await User.findByPk(req.params.id);
      if (!user) throw new AppError('User not found', 404);
      if (req.user!.id === user.id) throw new AppError('Cannot delete your own account', 400);

      await user.update({ status: UserStatus.INACTIVE });
      logger.info('User deactivated:', { userId: user.id, deletedBy: req.user!.id });
      res.json({ success: true, message: 'User deactivated successfully' });
    } catch (error) {
      next(error);
    }
  };

  unlock = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await User.findByPk(req.params.id);
      if (!user) throw new AppError('User not found', 404);
      await user.update({ status: UserStatus.ACTIVE, lockedUntil: undefined, loginAttempts: 0 });
      logger.info('User unlocked:', { userId: user.id, unlockedBy: req.user!.id });
      res.json({ success: true, message: 'User account unlocked successfully' });
    } catch (error) {
      next(error);
    }
  };

  resetPassword = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await User.findByPk(req.params.id);
      if (!user) throw new AppError('User not found', 404);

      const tempPassword = this.generateTempPassword();
      await user.update({
        password: tempPassword,
        isTemporaryPassword: true,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
      });

      try {
        await this.emailService.sendPasswordResetEmail(user.email, tempPassword, user.fullName);
      } catch (emailError) {
        logger.warn('Failed to send password reset email:', emailError);
      }

      logger.info('Password reset by admin:', { userId: user.id, resetBy: req.user!.id });
      res.json({ success: true, message: 'Password reset successfully. A temporary password has been sent to the user.' });
    } catch (error) {
      next(error);
    }
  };

  getSessions = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const sessions = await UserSession.findAll({
        where: { userId: req.params.id, isRevoked: false },
        order: [['createdAt', 'DESC']],
      });
      res.json({ success: true, data: sessions });
    } catch (error) {
      next(error);
    }
  };

  revokeSessions = async (req: Request, res: Response, next: NextFunction) => {
    try {
      await UserSession.update(
        { isRevoked: true, revokedAt: new Date() },
        { where: { userId: req.params.id } }
      );
      logger.info('Sessions revoked:', { userId: req.params.id, revokedBy: req.user!.id });
      res.json({ success: true, message: 'All sessions revoked' });
    } catch (error) {
      next(error);
    }
  };

  private generateTempPassword(): string {
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
    let password = '';
    password += 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random() * 22)];
    password += 'abcdefghjkmnpqrstuvwxyz'[Math.floor(Math.random() * 22)];
    password += '23456789'[Math.floor(Math.random() * 8)];
    password += '!@#$%'[Math.floor(Math.random() * 5)];
    for (let i = 4; i < 12; i++) {
      password += chars[Math.floor(Math.random() * chars.length)];
    }
    return password.split('').sort(() => Math.random() - 0.5).join('');
  }
}

export default UserController;
