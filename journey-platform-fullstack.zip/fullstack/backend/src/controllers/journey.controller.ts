import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { Journey, JourneyStatus } from '../models/journey.model';
import { JourneyRun } from '../models/journey-run.model';
import { WorkflowComment } from '../models/workflow-comment.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { User } from '../models/user.model';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';

export class JourneyController {
  getAll = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, search, status, lifecycleStage, priority, assignedTo, sortBy = 'createdAt', sortOrder = 'desc' } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);

      const where: any = {};
      if (search) where.name = { [Op.iLike]: `%${search}%` };
      if (status) where.status = status;
      if (lifecycleStage) where.lifecycleStage = lifecycleStage;
      if (priority) where.priority = priority;
      if (assignedTo) where.assignedTo = assignedTo;

      const { count, rows } = await Journey.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [[sortBy, sortOrder.toUpperCase()]],
        include: [
          { model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] },
          { model: User, as: 'assignee', attributes: ['id', 'firstName', 'lastName', 'email'] },
        ],
      });

      res.json({
        success: true,
        data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getStats = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const total = await Journey.count();
      const byStatus: any = {};
      for (const status of Object.values(JourneyStatus)) {
        byStatus[status] = await Journey.count({ where: { status } });
      }
      res.json({ success: true, data: { total, byStatus } });
    } catch (error) {
      next(error);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id, {
        include: [
          { model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] },
          { model: User, as: 'assignee', attributes: ['id', 'firstName', 'lastName', 'email'] },
          { model: User, as: 'approver', attributes: ['id', 'firstName', 'lastName', 'email'] },
        ],
      });
      if (!journey) throw new AppError('Journey not found', 404);
      res.json({ success: true, data: journey });
    } catch (error) {
      next(error);
    }
  };

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.create({
        ...req.body,
        createdBy: req.user!.id,
        status: JourneyStatus.DRAFT,
        version: 1,
      });

      await AuditLog.create({
        entityType: 'journey', entityId: journey.id,
        action: AuditAction.CREATE, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });

      logger.info('Journey created:', { journeyId: journey.id, createdBy: req.user!.id });
      res.status(201).json({ success: true, data: journey });
    } catch (error) {
      next(error);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);
      if (!journey.isEditable()) throw new AppError(`Journey cannot be edited in ${journey.status} status`, 400);

      const oldValue = journey.toJSON();
      await journey.update({ ...req.body, version: journey.version + 1 });

      await AuditLog.create({
        entityType: 'journey', entityId: journey.id,
        action: AuditAction.UPDATE, oldValue, newValue: req.body,
        performedBy: req.user!.id, ipAddress: req.ip,
      });

      res.json({ success: true, data: journey });
    } catch (error) {
      next(error);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);
      if (journey.status === JourneyStatus.RUNNING) throw new AppError('Cannot delete a running journey', 400);

      await journey.update({ status: JourneyStatus.ARCHIVED, isActive: false });
      await AuditLog.create({
        entityType: 'journey', entityId: journey.id,
        action: AuditAction.DELETE, performedBy: req.user!.id, ipAddress: req.ip,
      });

      res.json({ success: true, message: 'Journey archived successfully' });
    } catch (error) {
      next(error);
    }
  };

  transition = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const { status, notes, comment } = req.body;
      await journey.transitionTo(status as JourneyStatus, req.user!.id, notes);

      if (comment) {
        await WorkflowComment.create({
          journeyId: journey.id, userId: req.user!.id,
          content: comment, type: 'general', stage: status,
        });
      }

      res.json({ success: true, data: journey, message: `Journey transitioned to ${status}` });
    } catch (error) {
      next(error);
    }
  };

  schedule = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);
      if (journey.status !== JourneyStatus.APPROVED) throw new AppError('Journey must be approved before scheduling', 400);

      const scheduledAt = new Date(req.body.scheduledAt);
      if (scheduledAt <= new Date()) throw new AppError('Schedule date must be in the future', 400);

      await journey.update({ status: JourneyStatus.SCHEDULED, scheduledAt });
      res.json({ success: true, data: journey, message: 'Journey scheduled successfully' });
    } catch (error) {
      next(error);
    }
  };

  duplicate = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const original = await Journey.findByPk(req.params.id);
      if (!original) throw new AppError('Journey not found', 404);

      const { id, createdAt, updatedAt, status, approvedAt, approvedBy, startedAt, completedAt, ...data } = original.toJSON();
      const copy = await Journey.create({
        ...data,
        name: `${original.name} (Copy)`,
        status: JourneyStatus.DRAFT,
        version: 1,
        createdBy: req.user!.id,
        metrics: undefined,
      });

      res.status(201).json({ success: true, data: copy });
    } catch (error) {
      next(error);
    }
  };

  getComments = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const comments = await WorkflowComment.findAll({
        where: { journeyId: req.params.id },
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
        order: [['createdAt', 'DESC']],
      });
      res.json({ success: true, data: comments });
    } catch (error) {
      next(error);
    }
  };

  addComment = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journey = await Journey.findByPk(req.params.id);
      if (!journey) throw new AppError('Journey not found', 404);

      const comment = await WorkflowComment.create({
        journeyId: req.params.id,
        userId: req.user!.id,
        content: req.body.content,
        type: req.body.type || 'general',
        stage: journey.status,
        parentId: req.body.parentId,
      });

      const withUser = await WorkflowComment.findByPk(comment.id, {
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
      });

      res.status(201).json({ success: true, data: withUser });
    } catch (error) {
      next(error);
    }
  };

  getRuns = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const runs = await JourneyRun.findAll({
        where: { journeyId: req.params.id },
        order: [['createdAt', 'DESC']],
      });
      res.json({ success: true, data: runs });
    } catch (error) {
      next(error);
    }
  };

  getAuditLog = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const logs = await AuditLog.findAll({
        where: { entityType: 'journey', entityId: req.params.id },
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
        order: [['createdAt', 'DESC']],
      });
      res.json({ success: true, data: logs });
    } catch (error) {
      next(error);
    }
  };
}

export default JourneyController;
