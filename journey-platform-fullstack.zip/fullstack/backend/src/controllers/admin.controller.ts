import { Request, Response, NextFunction } from 'express';
import { Journey } from '../models/journey.model';
import { User, UserStatus } from '../models/user.model';
import { UserSession } from '../models/user-session.model';
import { ActivityLog } from '../models/activity-log.model';
import { AuditLog } from '../models/audit-log.model';
import { EmailConfig } from '../models/email-config.model';
import { EmailAlias } from '../models/email-alias.model';
import { EmailService } from '../services/email.service';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';

export class AdminController {
  private emailService = EmailService.getInstance();

  getStats = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const [totalUsers, activeUsers, totalJourneys, activeSessions, totalEmailsSent] = await Promise.all([
        User.count(),
        User.count({ where: { status: UserStatus.ACTIVE } }),
        Journey.count(),
        UserSession.count({ where: { isRevoked: false } }),
        EmailAlias.sum('totalSent') as Promise<number>,
      ]);

      res.json({
        success: true,
        data: { totalUsers, activeUsers, totalJourneys, activeSessions, totalEmailsSent: totalEmailsSent || 0 },
      });
    } catch (error) {
      next(error);
    }
  };

  getHealth = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const dbOk = await User.count().then(() => true).catch(() => false);
      res.json({
        success: true,
        data: {
          status: dbOk ? 'healthy' : 'degraded',
          database: dbOk ? 'connected' : 'error',
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  };

  // Email configs
  getEmailConfigs = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const configs = await EmailConfig.findAll({ order: [['createdAt', 'DESC']] });
      res.json({ success: true, data: configs.map(c => c.maskPassword()) });
    } catch (error) {
      next(error);
    }
  };

  getEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const config = await EmailConfig.findByPk(req.params.id);
      if (!config) throw new AppError('Email config not found', 404);
      res.json({ success: true, data: config.maskPassword() });
    } catch (error) {
      next(error);
    }
  };

  createEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      // If this is set as default, unset others
      if (req.body.isDefault) {
        await EmailConfig.update({ isDefault: false }, { where: {} });
      }
      const config = await EmailConfig.create(req.body);
      logger.info('Email config created:', { configId: config.id, by: req.user!.id });
      res.status(201).json({ success: true, data: config.maskPassword() });
    } catch (error) {
      next(error);
    }
  };

  updateEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const config = await EmailConfig.findByPk(req.params.id);
      if (!config) throw new AppError('Email config not found', 404);
      if (req.body.isDefault) {
        await EmailConfig.update({ isDefault: false }, { where: {} });
      }
      await config.update(req.body);
      res.json({ success: true, data: config.maskPassword() });
    } catch (error) {
      next(error);
    }
  };

  deleteEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const config = await EmailConfig.findByPk(req.params.id);
      if (!config) throw new AppError('Email config not found', 404);
      await config.update({ isActive: false });
      res.json({ success: true, message: 'Email config deactivated' });
    } catch (error) {
      next(error);
    }
  };

  testEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await this.emailService.testConfig(req.params.id);
      res.json({ success: result.success, data: result });
    } catch (error) {
      next(error);
    }
  };

  setDefaultEmailConfig = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const config = await EmailConfig.findByPk(req.params.id);
      if (!config) throw new AppError('Email config not found', 404);
      await EmailConfig.update({ isDefault: false }, { where: {} });
      await config.update({ isDefault: true });
      res.json({ success: true, message: 'Default email config updated' });
    } catch (error) {
      next(error);
    }
  };

  // Email aliases
  getEmailAliases = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const aliases = await EmailAlias.findAll({ order: [['createdAt', 'DESC']] });
      res.json({ success: true, data: aliases });
    } catch (error) {
      next(error);
    }
  };

  createEmailAlias = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const alias = await EmailAlias.create(req.body);
      logger.info('Email alias created:', { aliasId: alias.id, by: req.user!.id });
      res.status(201).json({ success: true, data: alias });
    } catch (error) {
      next(error);
    }
  };

  updateEmailAlias = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const alias = await EmailAlias.findByPk(req.params.id);
      if (!alias) throw new AppError('Email alias not found', 404);
      await alias.update(req.body);
      res.json({ success: true, data: alias });
    } catch (error) {
      next(error);
    }
  };

  deleteEmailAlias = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const alias = await EmailAlias.findByPk(req.params.id);
      if (!alias) throw new AppError('Email alias not found', 404);
      await alias.update({ isActive: false });
      res.json({ success: true, message: 'Email alias deactivated' });
    } catch (error) {
      next(error);
    }
  };

  toggleEmailAlias = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const alias = await EmailAlias.findByPk(req.params.id);
      if (!alias) throw new AppError('Email alias not found', 404);
      await alias.update({ isActive: !alias.isActive });
      res.json({ success: true, data: alias });
    } catch (error) {
      next(error);
    }
  };

  // Sessions
  getActiveSessions = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const sessions = await UserSession.findAll({
        where: { isRevoked: false },
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'role'] }],
        order: [['createdAt', 'DESC']],
        limit: 100,
      });
      res.json({ success: true, data: sessions });
    } catch (error) {
      next(error);
    }
  };

  revokeSession = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const session = await UserSession.findByPk(req.params.id);
      if (!session) throw new AppError('Session not found', 404);
      await session.revoke();
      logger.info('Session revoked by admin:', { sessionId: session.id, by: req.user!.id });
      res.json({ success: true, message: 'Session revoked' });
    } catch (error) {
      next(error);
    }
  };

  // Logs
  getActivity = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50 } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);
      const { count, rows } = await ActivityLog.findAndCountAll({
        limit: Number(limit), offset,
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });
      res.json({
        success: true, data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getAudit = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50 } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);
      const { count, rows } = await AuditLog.findAndCountAll({
        limit: Number(limit), offset,
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });
      res.json({
        success: true, data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };
}

export default AdminController;
