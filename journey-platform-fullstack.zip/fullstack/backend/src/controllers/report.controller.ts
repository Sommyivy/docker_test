import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { Journey, JourneyStatus } from '../models/journey.model';
import { JourneyRun } from '../models/journey-run.model';
import { User, UserStatus } from '../models/user.model';
import { ActivityLog } from '../models/activity-log.model';
import { AuditLog } from '../models/audit-log.model';
import { EmailConfig } from '../models/email-config.model';
import { logger } from '../utils/logger';

export class ReportController {
  getOverview = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const [totalJourneys, totalUsers, activeJourneys, totalRuns] = await Promise.all([
        Journey.count(),
        User.count({ where: { status: UserStatus.ACTIVE } }),
        Journey.count({ where: { status: JourneyStatus.RUNNING } }),
        JourneyRun.count(),
      ]);

      const journeysByStatus: Record<string, number> = {};
      for (const status of Object.values(JourneyStatus)) {
        journeysByStatus[status] = await Journey.count({ where: { status } });
      }

      const recentActivity = await ActivityLog.findAll({
        limit: 10,
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      res.json({
        success: true,
        data: {
          summary: { totalJourneys, totalUsers, activeJourneys, totalRuns },
          journeysByStatus,
          recentActivity,
        },
      });
    } catch (error) {
      next(error);
    }
  };

  getJourneyReport = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { from, to, status, lifecycleStage } = req.query as any;
      const where: any = {};
      if (status) where.status = status;
      if (lifecycleStage) where.lifecycleStage = lifecycleStage;
      if (from || to) {
        where.createdAt = {};
        if (from) where.createdAt[Op.gte] = new Date(from);
        if (to) where.createdAt[Op.lte] = new Date(to);
      }

      const journeys = await Journey.findAll({
        where,
        include: [
          { model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] },
          { model: JourneyRun, as: 'runs' },
        ],
        order: [['createdAt', 'DESC']],
      });

      res.json({ success: true, data: journeys, total: journeys.length });
    } catch (error) {
      next(error);
    }
  };

  getUserReport = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const users = await User.findAll({
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
      });
      res.json({ success: true, data: users, total: users.length });
    } catch (error) {
      next(error);
    }
  };

  getActivityLog = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, userId, type, from, to } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);
      const where: any = {};
      if (userId) where.userId = userId;
      if (type) where.type = type;
      if (from || to) {
        where.createdAt = {};
        if (from) where.createdAt[Op.gte] = new Date(from);
        if (to) where.createdAt[Op.lte] = new Date(to);
      }

      const { count, rows } = await ActivityLog.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      res.json({
        success: true,
        data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getAuditLog = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, entityType, action, from, to } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);
      const where: any = {};
      if (entityType) where.entityType = entityType;
      if (action) where.action = action;
      if (from || to) {
        where.createdAt = {};
        if (from) where.createdAt[Op.gte] = new Date(from);
        if (to) where.createdAt[Op.lte] = new Date(to);
      }

      const { count, rows } = await AuditLog.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      res.json({
        success: true,
        data: rows,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getEmailReport = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const configs = await EmailConfig.findAll({ order: [['createdAt', 'DESC']] });
      const masked = configs.map(c => c.maskPassword());
      res.json({ success: true, data: masked });
    } catch (error) {
      next(error);
    }
  };

  exportJourneys = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const journeys = await Journey.findAll({
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
        order: [['createdAt', 'DESC']],
      });

      const csv = [
        'ID,Name,Status,Lifecycle Stage,Priority,Created By,Created At,Updated At',
        ...journeys.map(j => {
          const jj = j.toJSON() as any;
          return `${jj.id},"${jj.name}",${jj.status},${jj.lifecycleStage},${jj.priority},"${jj.creator?.email || ''}",${jj.createdAt},${jj.updatedAt}`;
        }),
      ].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=journeys.csv');
      res.send(csv);
    } catch (error) {
      next(error);
    }
  };

  exportUsers = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const users = await User.findAll({
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
      });

      const csv = [
        'ID,Email,First Name,Last Name,Role,Department,Status,Created At',
        ...users.map(u => `${u.id},${u.email},"${u.firstName}","${u.lastName}",${u.role},${u.department || ''},${u.status},${u.createdAt}`),
      ].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=users.csv');
      res.send(csv);
    } catch (error) {
      next(error);
    }
  };

  exportActivity = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const logs = await ActivityLog.findAll({
        order: [['createdAt', 'DESC']],
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      const csv = [
        'ID,Type,User,Entity Type,Entity ID,Description,Created At',
        ...logs.map(l => {
          const ll = l.toJSON() as any;
          return `${ll.id},${ll.type},"${ll.user?.email || ''}",${ll.entityType || ''},${ll.entityId || ''},"${ll.description || ''}",${ll.createdAt}`;
        }),
      ].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=activity.csv');
      res.send(csv);
    } catch (error) {
      next(error);
    }
  };
}

export default ReportController;
