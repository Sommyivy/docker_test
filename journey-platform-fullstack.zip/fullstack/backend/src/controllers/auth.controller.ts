import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User, UserStatus } from '../models/user.model';
import { UserSession } from '../models/user-session.model';
import { PasswordHistory } from '../models/password-history.model';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';
import { EmailService } from '../services/email.service';

// JWT Payload interface
interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  sessionId: string;
}

export class AuthController {
  private emailService: EmailService;

  constructor() {
    this.emailService = EmailService.getInstance();
  }

  // Login
  login = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password } = req.body;

      // Find user by email
      const user = await User.findOne({ where: { email } });

      if (!user) {
        throw new AppError('Invalid email or password.', 401);
      }

      // Check if account is locked
      if (user.isLocked()) {
        throw new AppError('Account is locked. Please try again later.', 403);
      }

      // Check if account is inactive
      if (user.status === UserStatus.INACTIVE) {
        throw new AppError('Account is inactive. Please contact administrator.', 403);
      }

      // Verify password
      const isPasswordValid = await user.comparePassword(password);

      if (!isPasswordValid) {
        await user.incrementLoginAttempts();
        throw new AppError('Invalid email or password.', 401);
      }

      // Reset login attempts on successful login
      await user.resetLoginAttempts();

      // Update last login
      await user.updateLastLogin();

      // Create session
      const session = await this.createSession(user, req);

      // Generate tokens
      const tokens = this.generateTokens(user, session.id);

      // Update session with tokens
      await session.update({
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        refreshExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      });

      logger.info('User logged in:', { userId: user.id, email: user.email });

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          user: {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            fullName: user.fullName,
            role: user.role,
            status: user.status,
            permissions: user.permissions || User.getDefaultPermissions(user.role),
            isTemporaryPassword: user.isTemporaryPassword,
          },
          tokens,
        },
      });
    } catch (error) {
      next(error);
    }
  };

  // Logout
  logout = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const session = req.session;

      if (session) {
        await session.revoke();
      }

      logger.info('User logged out:', { userId: req.user?.id });

      res.json({
        success: true,
        message: 'Logout successful',
      });
    } catch (error) {
      next(error);
    }
  };

  // Refresh token
  refreshToken = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const session = req.session;

      if (!session) {
        throw new AppError('Invalid session.', 401);
      }

      const user = await User.findByPk(session.userId);

      if (!user || user.status !== UserStatus.ACTIVE) {
        throw new AppError('User not found or inactive.', 401);
      }

      // Generate new tokens
      const tokens = this.generateTokens(user, session.id);

      // Update session
      await session.update({
        token: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        refreshExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      });

      res.json({
        success: true,
        message: 'Token refreshed successfully',
        data: { tokens },
      });
    } catch (error) {
      next(error);
    }
  };

  // Change password
  changePassword = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { oldPassword, newPassword } = req.body;
      const user = req.user!;

      // Verify old password
      const isOldPasswordValid = await user.comparePassword(oldPassword);

      if (!isOldPasswordValid) {
        throw new AppError('Current password is incorrect.', 400);
      }

      // Check if new password was used before
      const wasUsed = await PasswordHistory.wasPasswordUsed(user.id, newPassword);

      if (wasUsed) {
        throw new AppError('Cannot reuse a previous password.', 400);
      }

      // Save old password to history
      await PasswordHistory.addToHistory(user.id, user.password);

      // Update password
      await user.update({
        password: newPassword,
        isTemporaryPassword: false,
        passwordChangedAt: new Date(),
        status: UserStatus.ACTIVE,
      });

      // Revoke all sessions except current
      await UserSession.update(
        { isRevoked: true, revokedAt: new Date() },
        { where: { userId: user.id, id: { $ne: req.session?.id } } }
      );

      logger.info('Password changed:', { userId: user.id });

      res.json({
        success: true,
        message: 'Password changed successfully',
      });
    } catch (error) {
      next(error);
    }
  };

  // Forgot password
  forgotPassword = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email } = req.body;

      const user = await User.findOne({ where: { email } });

      // Always return success to prevent email enumeration
      if (!user) {
        return res.json({
          success: true,
          message: 'If an account exists with this email, you will receive password reset instructions.',
        });
      }

      // Generate reset token
      const resetToken = jwt.sign(
        { userId: user.id, type: 'password_reset' },
        process.env.JWT_SECRET!,
        { expiresIn: '1h' }
      );

      // Send reset email
      await this.emailService.sendPasswordResetEmail(user.email, resetToken, user.fullName);

      logger.info('Password reset requested:', { userId: user.id, email: user.email });

      res.json({
        success: true,
        message: 'If an account exists with this email, you will receive password reset instructions.',
      });
    } catch (error) {
      next(error);
    }
  };

  // Reset password
  resetPassword = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token, newPassword } = req.body;

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;

      if (decoded.type !== 'password_reset') {
        throw new AppError('Invalid token.', 400);
      }

      const user = await User.findByPk(decoded.userId);

      if (!user) {
        throw new AppError('User not found.', 404);
      }

      // Check if password was used before
      const wasUsed = await PasswordHistory.wasPasswordUsed(user.id, newPassword);

      if (wasUsed) {
        throw new AppError('Cannot reuse a previous password.', 400);
      }

      // Save old password to history
      await PasswordHistory.addToHistory(user.id, user.password);

      // Update password
      await user.update({
        password: newPassword,
        isTemporaryPassword: false,
        passwordChangedAt: new Date(),
        status: UserStatus.ACTIVE,
      });

      // Revoke all sessions
      await UserSession.update(
        { isRevoked: true, revokedAt: new Date() },
        { where: { userId: user.id } }
      );

      logger.info('Password reset completed:', { userId: user.id });

      res.json({
        success: true,
        message: 'Password reset successfully. Please log in with your new password.',
      });
    } catch (error) {
      if (error instanceof jwt.JsonWebTokenError) {
        return next(new AppError('Invalid or expired token.', 400));
      }
      next(error);
    }
  };

  // Get current user
  getCurrentUser = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = req.user!;

      res.json({
        success: true,
        data: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          fullName: user.fullName,
          role: user.role,
          status: user.status,
          department: user.department,
          jobTitle: user.jobTitle,
          phone: user.phone,
          avatarUrl: user.avatarUrl,
          permissions: user.permissions || User.getDefaultPermissions(user.role),
          isTemporaryPassword: user.isTemporaryPassword,
          lastLoginAt: user.lastLoginAt,
          createdAt: user.createdAt,
        },
      });
    } catch (error) {
      next(error);
    }
  };

  // Verify token
  verifyToken = async (req: Request, res: Response, next: NextFunction) => {
    try {
      res.json({
        success: true,
        message: 'Token is valid',
        data: {
          user: {
            id: req.user!.id,
            email: req.user!.email,
            role: req.user!.role,
          },
        },
      });
    } catch (error) {
      next(error);
    }
  };

  // Helper methods
  private async createSession(user: User, req: Request): Promise<UserSession> {
    const userAgent = req.get('user-agent') || '';
    const deviceType = this.detectDeviceType(userAgent);
    const browser = this.detectBrowser(userAgent);
    const os = this.detectOS(userAgent);

    return UserSession.create({
      userId: user.id,
      token: '', // Will be updated after generation
      refreshToken: '', // Will be updated after generation
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      refreshExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      ipAddress: req.ip,
      userAgent,
      deviceType,
      browser,
      os,
    });
  }

  private generateTokens(user: User, sessionId: string) {
    const payload: JWTPayload = {
      userId: user.id,
      email: user.email,
      role: user.role,
      sessionId,
    };

    const accessToken = jwt.sign(payload, process.env.JWT_SECRET!, {
      expiresIn: (process.env.JWT_EXPIRES_IN || '24h') as any,
    });

    const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET!, {
      expiresIn: (process.env.JWT_REFRESH_EXPIRES_IN || '7d') as any,
    });

    return { accessToken, refreshToken };
  }

  private detectDeviceType(userAgent: string): string {
    if (/mobile/i.test(userAgent)) return 'mobile';
    if (/tablet/i.test(userAgent)) return 'tablet';
    return 'desktop';
  }

  private detectBrowser(userAgent: string): string {
    if (/chrome/i.test(userAgent)) return 'Chrome';
    if (/firefox/i.test(userAgent)) return 'Firefox';
    if (/safari/i.test(userAgent)) return 'Safari';
    if (/edge/i.test(userAgent)) return 'Edge';
    if (/opera/i.test(userAgent)) return 'Opera';
    return 'Unknown';
  }

  private detectOS(userAgent: string): string {
    if (/windows/i.test(userAgent)) return 'Windows';
    if (/macintosh|mac os/i.test(userAgent)) return 'MacOS';
    if (/linux/i.test(userAgent)) return 'Linux';
    if (/android/i.test(userAgent)) return 'Android';
    if (/ios|iphone|ipad/i.test(userAgent)) return 'iOS';
    return 'Unknown';
  }
}

export default AuthController;
