import { Request, Response, NextFunction } from 'express';
import { Op } from 'sequelize';
import { DataSource, DataSourceStatus } from '../models/datasource.model';
import { User } from '../models/user.model';
import { AuditLog, AuditAction } from '../models/audit-log.model';
import { AppError } from '../middleware/error.middleware';
import { logger } from '../utils/logger';

export class DataSourceController {
  getAll = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { page = 1, limit = 50, search, type, status, sortBy = 'createdAt', sortOrder = 'desc' } = req.query as any;
      const offset = (Number(page) - 1) * Number(limit);

      const where: any = {};
      if (search) where.name = { [Op.iLike]: `%${search}%` };
      if (type) where.type = type;
      if (status) where.status = status;

      const { count, rows } = await DataSource.findAndCountAll({
        where,
        limit: Number(limit),
        offset,
        order: [[sortBy, sortOrder.toUpperCase()]],
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });

      // Mask sensitive data in config
      const masked = rows.map(ds => ds.maskSensitiveData());

      res.json({
        success: true,
        data: masked,
        pagination: { total: count, page: Number(page), limit: Number(limit), totalPages: Math.ceil(count / Number(limit)) },
      });
    } catch (error) {
      next(error);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.findByPk(req.params.id, {
        include: [{ model: User, as: 'creator', attributes: ['id', 'firstName', 'lastName', 'email'] }],
      });
      if (!ds) throw new AppError('Data source not found', 404);
      res.json({ success: true, data: ds.maskSensitiveData() });
    } catch (error) {
      next(error);
    }
  };

  create = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.create({ ...req.body, createdBy: req.user!.id });
      await AuditLog.create({
        entityType: 'datasource', entityId: ds.id,
        action: AuditAction.CREATE, performedBy: req.user!.id, ipAddress: req.ip,
      });
      logger.info('DataSource created:', { dsId: ds.id, createdBy: req.user!.id });
      res.status(201).json({ success: true, data: ds.maskSensitiveData() });
    } catch (error) {
      next(error);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.findByPk(req.params.id);
      if (!ds) throw new AppError('Data source not found', 404);
      await ds.update(req.body);
      await AuditLog.create({
        entityType: 'datasource', entityId: ds.id,
        action: AuditAction.UPDATE, performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, data: ds.maskSensitiveData() });
    } catch (error) {
      next(error);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.findByPk(req.params.id);
      if (!ds) throw new AppError('Data source not found', 404);
      await ds.update({ isActive: false, status: DataSourceStatus.INACTIVE });
      await AuditLog.create({
        entityType: 'datasource', entityId: ds.id,
        action: AuditAction.DELETE, performedBy: req.user!.id, ipAddress: req.ip,
      });
      res.json({ success: true, message: 'Data source deactivated' });
    } catch (error) {
      next(error);
    }
  };

  test = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.findByPk(req.params.id);
      if (!ds) throw new AppError('Data source not found', 404);

      // Simulate connection test — real implementation would attempt actual DB connection
      const success = ds.isActive;
      await ds.update({
        lastTestedAt: new Date(),
        lastTestSuccess: success,
        lastTestResult: success ? 'Connection successful' : 'Connection failed',
        status: success ? DataSourceStatus.ACTIVE : DataSourceStatus.ERROR,
      });

      await AuditLog.create({
        entityType: 'datasource', entityId: ds.id,
        action: AuditAction.TEST_CONNECTION, performedBy: req.user!.id, ipAddress: req.ip,
      });

      res.json({ success: true, data: { tested: true, result: success ? 'Connection successful' : 'Connection failed', success } });
    } catch (error) {
      next(error);
    }
  };

  toggle = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ds = await DataSource.findByPk(req.params.id);
      if (!ds) throw new AppError('Data source not found', 404);
      await ds.update({ isActive: !ds.isActive });
      res.json({ success: true, data: ds.maskSensitiveData(), message: `Data source ${ds.isActive ? 'enabled' : 'disabled'}` });
    } catch (error) {
      next(error);
    }
  };
}

export default DataSourceController;
