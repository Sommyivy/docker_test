import { Router } from 'express';
import authRoutes from './auth.routes';
import userRoutes from './user.routes';
import journeyRoutes from './journey.routes';
import ruleRoutes from './rule.routes';
import templateRoutes from './template.routes';
import dataSourceRoutes from './datasource.routes';
import reportRoutes from './report.routes';
import workflowRoutes from './workflow.routes';
import adminRoutes from './admin.routes';

const router = Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/journeys', journeyRoutes);
router.use('/rules', ruleRoutes);
router.use('/templates', templateRoutes);
router.use('/datasources', dataSourceRoutes);
router.use('/reports', reportRoutes);
router.use('/workflows', workflowRoutes);
router.use('/admin', adminRoutes);

export default router;
