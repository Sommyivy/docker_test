import { Router } from 'express';
import Joi from 'joi';
import { AuthController } from '../controllers/auth.controller';
import { authenticate, validateRefreshToken } from '../middleware/auth.middleware';
import { validate, commonSchemas } from '../middleware/validation.middleware';

const router = Router();
const authController = new AuthController();

// Validation schemas
const loginSchema = Joi.object({
  email: commonSchemas.email,
  password: Joi.string().required(),
});

const changePasswordSchema = Joi.object({
  oldPassword: Joi.string().required(),
  newPassword: commonSchemas.password,
});

const forgotPasswordSchema = Joi.object({
  email: commonSchemas.email,
});

const resetPasswordSchema = Joi.object({
  token: Joi.string().required(),
  newPassword: commonSchemas.password,
});

// Routes
router.post('/login', validate(loginSchema), authController.login);
router.post('/logout', authenticate, authController.logout);
router.post('/refresh', validateRefreshToken, authController.refreshToken);
router.post('/change-password', authenticate, validate(changePasswordSchema), authController.changePassword);
router.post('/forgot-password', validate(forgotPasswordSchema), authController.forgotPassword);
router.post('/reset-password', validate(resetPasswordSchema), authController.resetPassword);
router.get('/me', authenticate, authController.getCurrentUser);
router.post('/verify-token', authenticate, authController.verifyToken);

export default router;
