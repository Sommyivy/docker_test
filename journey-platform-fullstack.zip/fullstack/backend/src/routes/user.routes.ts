import { Router } from 'express';
import Joi from 'joi';
import { UserController } from '../controllers/user.controller';
import { authenticate, authorize, checkPermission } from '../middleware/auth.middleware';
import { validate, validateQuery, commonSchemas } from '../middleware/validation.middleware';
import { UserRole } from '../models/user.model';

const router = Router();
const userController = new UserController();

const createUserSchema = Joi.object({
  firstName: Joi.string().min(1).max(100).required(),
  lastName: Joi.string().min(1).max(100).required(),
  email: commonSchemas.email,
  role: Joi.string().valid(...Object.values(UserRole)).required(),
  department: Joi.string().max(100).optional(),
  jobTitle: Joi.string().max(100).optional(),
  phone: Joi.string().max(20).optional(),
});

const updateUserSchema = Joi.object({
  firstName: Joi.string().min(1).max(100).optional(),
  lastName: Joi.string().min(1).max(100).optional(),
  email: Joi.string().email().optional(),
  role: Joi.string().valid(...Object.values(UserRole)).optional(),
  department: Joi.string().max(100).optional(),
  jobTitle: Joi.string().max(100).optional(),
  phone: Joi.string().max(20).optional(),
  status: Joi.string().valid('active', 'inactive').optional(),
  emailNotifications: Joi.boolean().optional(),
  pushNotifications: Joi.boolean().optional(),
  notes: Joi.string().optional(),
});

router.use(authenticate);

router.get('/', checkPermission('users', 'view'), userController.getAll);
router.get('/me', userController.getMe);
router.get('/:id', checkPermission('users', 'view'), userController.getById);
router.post('/', checkPermission('users', 'create'), validate(createUserSchema), userController.create);
router.put('/:id', checkPermission('users', 'edit'), validate(updateUserSchema), userController.update);
router.delete('/:id', checkPermission('users', 'delete'), userController.delete);
router.post('/:id/unlock', authorize(UserRole.SUPER_ADMIN, UserRole.ADMIN), userController.unlock);
router.post('/:id/reset-password', authorize(UserRole.SUPER_ADMIN, UserRole.ADMIN), userController.resetPassword);
router.get('/:id/sessions', checkPermission('users', 'view'), userController.getSessions);
router.delete('/:id/sessions', checkPermission('users', 'edit'), userController.revokeSessions);

export default router;
