import { Router } from 'express';
import Joi from 'joi';
import { AdminController } from '../controllers/admin.controller';
import { authenticate, authorize, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';
import { UserRole } from '../models/user.model';

const router = Router();
const adminController = new AdminController();

const emailConfigSchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  description: Joi.string().optional().allow(''),
  provider: Joi.string().valid('smtp', 'sendgrid', 'mailgun', 'aws_ses').default('smtp'),
  host: Joi.string().required(),
  port: Joi.number().integer().required(),
  secure: Joi.boolean().default(false),
  username: Joi.string().required(),
  password: Joi.string().required(),
  fromName: Joi.string().optional(),
  fromEmail: Joi.string().email().optional(),
  dailyLimit: Joi.number().integer().min(1).default(10000),
  isDefault: Joi.boolean().default(false),
});

const emailAliasSchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  email: Joi.string().email().required(),
  description: Joi.string().optional().allow(''),
  dailyLimit: Joi.number().integer().min(1).default(10000),
  weight: Joi.number().integer().min(1).default(1),
});

router.use(authenticate);
router.use(authorize(UserRole.SUPER_ADMIN, UserRole.ADMIN));

// Dashboard stats
router.get('/stats', adminController.getStats);
router.get('/health', adminController.getHealth);

// Email configs
router.get('/email-configs', adminController.getEmailConfigs);
router.get('/email-configs/:id', adminController.getEmailConfig);
router.post('/email-configs', checkPermission('admin', 'configure'), validate(emailConfigSchema), adminController.createEmailConfig);
router.put('/email-configs/:id', checkPermission('admin', 'configure'), adminController.updateEmailConfig);
router.delete('/email-configs/:id', checkPermission('admin', 'configure'), adminController.deleteEmailConfig);
router.post('/email-configs/:id/test', checkPermission('admin', 'configure'), adminController.testEmailConfig);
router.post('/email-configs/:id/set-default', checkPermission('admin', 'configure'), adminController.setDefaultEmailConfig);

// Email aliases
router.get('/email-aliases', adminController.getEmailAliases);
router.post('/email-aliases', checkPermission('admin', 'configure'), validate(emailAliasSchema), adminController.createEmailAlias);
router.put('/email-aliases/:id', checkPermission('admin', 'configure'), adminController.updateEmailAlias);
router.delete('/email-aliases/:id', checkPermission('admin', 'configure'), adminController.deleteEmailAlias);
router.post('/email-aliases/:id/toggle', checkPermission('admin', 'configure'), adminController.toggleEmailAlias);

// Sessions management
router.get('/sessions', adminController.getActiveSessions);
router.delete('/sessions/:id', adminController.revokeSession);

// Activity & audit
router.get('/activity', adminController.getActivity);
router.get('/audit', adminController.getAudit);

export default router;
