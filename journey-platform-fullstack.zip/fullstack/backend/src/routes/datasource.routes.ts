import { Router } from 'express';
import Joi from 'joi';
import { DataSourceController } from '../controllers/datasource.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';
import { DataSourceType } from '../models/datasource.model';

const router = Router();
const dataSourceController = new DataSourceController();

const createDataSourceSchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  description: Joi.string().optional().allow(''),
  type: Joi.string().valid(...Object.values(DataSourceType)).required(),
  config: Joi.object({
    host: Joi.string().optional(),
    port: Joi.number().optional(),
    database: Joi.string().optional(),
    username: Joi.string().optional(),
    password: Joi.string().optional(),
    ssl: Joi.boolean().optional(),
    connectionString: Joi.string().optional(),
    apiUrl: Joi.string().optional(),
    apiKey: Joi.string().optional(),
    apiHeaders: Joi.object().optional(),
    filePath: Joi.string().optional(),
    fileFormat: Joi.string().valid('csv', 'json', 'xml', 'parquet').optional(),
    additionalOptions: Joi.object().optional(),
  }).required(),
  testQuery: Joi.string().optional().allow(''),
});

const updateDataSourceSchema = Joi.object({
  name: Joi.string().min(1).max(255).optional(),
  description: Joi.string().optional().allow(''),
  config: Joi.object().optional(),
  testQuery: Joi.string().optional().allow(''),
});

router.use(authenticate);

router.get('/', checkPermission('datasources', 'view'), dataSourceController.getAll);
router.get('/:id', checkPermission('datasources', 'view'), dataSourceController.getById);
router.post('/', checkPermission('datasources', 'create'), validate(createDataSourceSchema), dataSourceController.create);
router.put('/:id', checkPermission('datasources', 'edit'), validate(updateDataSourceSchema), dataSourceController.update);
router.delete('/:id', checkPermission('datasources', 'delete'), dataSourceController.delete);
router.post('/:id/test', checkPermission('datasources', 'test'), dataSourceController.test);
router.post('/:id/toggle', checkPermission('datasources', 'edit'), dataSourceController.toggle);

export default router;
