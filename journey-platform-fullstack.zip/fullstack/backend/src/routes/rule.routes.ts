import { Router } from 'express';
import Joi from 'joi';
import { RuleController } from '../controllers/rule.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';
import { RuleType, RuleStatus } from '../models/rule.model';

const router = Router();
const ruleController = new RuleController();

const createRuleSchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  description: Joi.string().optional().allow(''),
  type: Joi.string().valid(...Object.values(RuleType)).required(),
  conditions: Joi.array().optional(),
  actions: Joi.array().optional(),
  sqlQuery: Joi.string().optional().allow(''),
  dataSourceConfig: Joi.object().optional(),
  metadata: Joi.object().optional(),
});

const updateRuleSchema = Joi.object({
  name: Joi.string().min(1).max(255).optional(),
  description: Joi.string().optional().allow(''),
  type: Joi.string().valid(...Object.values(RuleType)).optional(),
  conditions: Joi.array().optional(),
  actions: Joi.array().optional(),
  sqlQuery: Joi.string().optional().allow(''),
  dataSourceConfig: Joi.object().optional(),
  metadata: Joi.object().optional(),
});

router.use(authenticate);

router.get('/', checkPermission('rules', 'view'), ruleController.getAll);
router.get('/:id', checkPermission('rules', 'view'), ruleController.getById);
router.post('/', checkPermission('rules', 'create'), validate(createRuleSchema), ruleController.create);
router.put('/:id', checkPermission('rules', 'edit'), validate(updateRuleSchema), ruleController.update);
router.delete('/:id', checkPermission('rules', 'delete'), ruleController.delete);
router.post('/:id/activate', checkPermission('rules', 'edit'), ruleController.activate);
router.post('/:id/deactivate', checkPermission('rules', 'edit'), ruleController.deactivate);
router.post('/:id/test', checkPermission('rules', 'view'), ruleController.test);

export default router;
