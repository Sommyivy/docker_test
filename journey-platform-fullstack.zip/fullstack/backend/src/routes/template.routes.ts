import { Router } from 'express';
import Joi from 'joi';
import { TemplateController } from '../controllers/template.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';
import { TemplateType } from '../models/template.model';

const router = Router();
const templateController = new TemplateController();

const createTemplateSchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  description: Joi.string().optional().allow(''),
  type: Joi.string().valid(...Object.values(TemplateType)).required(),
  subject: Joi.string().min(1).max(255).required(),
  content: Joi.string().min(1).required(),
  htmlContent: Joi.string().optional().allow(''),
  plainTextContent: Joi.string().optional().allow(''),
  variables: Joi.array().optional(),
  metadata: Joi.object().optional(),
});

const updateTemplateSchema = Joi.object({
  name: Joi.string().min(1).max(255).optional(),
  description: Joi.string().optional().allow(''),
  type: Joi.string().valid(...Object.values(TemplateType)).optional(),
  subject: Joi.string().min(1).max(255).optional(),
  content: Joi.string().min(1).optional(),
  htmlContent: Joi.string().optional().allow(''),
  plainTextContent: Joi.string().optional().allow(''),
  variables: Joi.array().optional(),
  metadata: Joi.object().optional(),
});

const reviewSchema = Joi.object({
  approved: Joi.boolean().required(),
  reason: Joi.string().optional().allow(''),
});

router.use(authenticate);

router.get('/', checkPermission('templates', 'view'), templateController.getAll);
router.get('/:id', checkPermission('templates', 'view'), templateController.getById);
router.post('/', checkPermission('templates', 'create'), validate(createTemplateSchema), templateController.create);
router.put('/:id', checkPermission('templates', 'edit'), validate(updateTemplateSchema), templateController.update);
router.delete('/:id', checkPermission('templates', 'delete'), templateController.delete);
router.post('/:id/review', checkPermission('templates', 'approve'), validate(reviewSchema), templateController.review);
router.post('/:id/preview', checkPermission('templates', 'view'), templateController.preview);
router.post('/:id/duplicate', checkPermission('templates', 'create'), templateController.duplicate);

export default router;
