import { Router } from 'express';
import Joi from 'joi';
import { WorkflowController } from '../controllers/workflow.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';

const router = Router();
const workflowController = new WorkflowController();

const commentSchema = Joi.object({
  content: Joi.string().min(1).required(),
  type: Joi.string().valid('general', 'approval', 'rejection', 'request_change', 'note').default('general'),
  stage: Joi.string().optional(),
  parentId: Joi.string().uuid().optional(),
});

router.use(authenticate);

router.get('/stages', workflowController.getStages);
router.get('/journeys/:id/history', checkPermission('journeys', 'view'), workflowController.getHistory);
router.post('/journeys/:id/submit', checkPermission('journeys', 'edit'), workflowController.submit);
router.post('/journeys/:id/approve', checkPermission('journeys', 'approve'), workflowController.approve);
router.post('/journeys/:id/reject', checkPermission('journeys', 'approve'), workflowController.reject);
router.post('/journeys/:id/request-changes', checkPermission('journeys', 'edit'), workflowController.requestChanges);
router.post('/journeys/:id/comments', checkPermission('journeys', 'edit'), validate(commentSchema), workflowController.addComment);
router.get('/journeys/:id/comments', checkPermission('journeys', 'view'), workflowController.getComments);

export default router;
