import { Router } from 'express';
import { ReportController } from '../controllers/report.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';

const router = Router();
const reportController = new ReportController();

router.use(authenticate);

router.get('/overview', checkPermission('reports', 'view'), reportController.getOverview);
router.get('/journeys', checkPermission('reports', 'view'), reportController.getJourneyReport);
router.get('/users', checkPermission('reports', 'view'), reportController.getUserReport);
router.get('/activity', checkPermission('reports', 'view'), reportController.getActivityLog);
router.get('/audit', checkPermission('reports', 'view'), reportController.getAuditLog);
router.get('/email', checkPermission('reports', 'view'), reportController.getEmailReport);
router.get('/export/journeys', checkPermission('reports', 'export'), reportController.exportJourneys);
router.get('/export/users', checkPermission('reports', 'export'), reportController.exportUsers);
router.get('/export/activity', checkPermission('reports', 'export'), reportController.exportActivity);

export default router;
