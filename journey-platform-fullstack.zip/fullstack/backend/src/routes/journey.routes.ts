import { Router } from 'express';
import Joi from 'joi';
import { JourneyController } from '../controllers/journey.controller';
import { authenticate, checkPermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validation.middleware';
import { LifecycleStage, JourneyPriority, JourneyStatus } from '../models/journey.model';

const router = Router();
const journeyController = new JourneyController();

const createJourneySchema = Joi.object({
  name: Joi.string().min(1).max(255).required(),
  description: Joi.string().optional().allow(''),
  lifecycleStage: Joi.string().valid(...Object.values(LifecycleStage)).required(),
  priority: Joi.string().valid(...Object.values(JourneyPriority)).default('medium'),
  estimatedReach: Joi.number().integer().min(0).optional(),
  steps: Joi.array().optional(),
  controlGroup: Joi.object({
    enabled: Joi.boolean(),
    percentage: Joi.number().min(0).max(100),
    description: Joi.string().optional(),
  }).optional(),
  metadata: Joi.object().optional(),
});

const updateJourneySchema = Joi.object({
  name: Joi.string().min(1).max(255).optional(),
  description: Joi.string().optional().allow(''),
  lifecycleStage: Joi.string().valid(...Object.values(LifecycleStage)).optional(),
  priority: Joi.string().valid(...Object.values(JourneyPriority)).optional(),
  estimatedReach: Joi.number().integer().min(0).optional(),
  steps: Joi.array().optional(),
  controlGroup: Joi.object().optional(),
  metadata: Joi.object().optional(),
  assignedTo: Joi.string().uuid().optional(),
});

const transitionSchema = Joi.object({
  status: Joi.string().valid(...Object.values(JourneyStatus)).required(),
  notes: Joi.string().optional().allow(''),
  comment: Joi.string().optional().allow(''),
});

const scheduleSchema = Joi.object({
  scheduledAt: Joi.date().iso().min('now').required(),
});

router.use(authenticate);

router.get('/', checkPermission('journeys', 'view'), journeyController.getAll);
router.get('/stats', checkPermission('journeys', 'view'), journeyController.getStats);
router.get('/:id', checkPermission('journeys', 'view'), journeyController.getById);
router.post('/', checkPermission('journeys', 'create'), validate(createJourneySchema), journeyController.create);
router.put('/:id', checkPermission('journeys', 'edit'), validate(updateJourneySchema), journeyController.update);
router.delete('/:id', checkPermission('journeys', 'delete'), journeyController.delete);
router.post('/:id/transition', checkPermission('journeys', 'edit'), validate(transitionSchema), journeyController.transition);
router.post('/:id/schedule', checkPermission('journeys', 'edit'), validate(scheduleSchema), journeyController.schedule);
router.post('/:id/duplicate', checkPermission('journeys', 'create'), journeyController.duplicate);
router.get('/:id/comments', checkPermission('journeys', 'view'), journeyController.getComments);
router.post('/:id/comments', checkPermission('journeys', 'edit'), journeyController.addComment);
router.get('/:id/runs', checkPermission('journeys', 'view'), journeyController.getRuns);
router.get('/:id/audit', checkPermission('journeys', 'view'), journeyController.getAuditLog);

export default router;
