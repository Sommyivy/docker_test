import { User, UserRole, UserStatus } from '../../src/models/user.model';
import { logger } from '../../src/utils/logger';

export const seedUsers = async (): Promise<void> => {
  try {
    logger.info('Seeding users...');

    const users = [
      {
        firstName: 'System',
        lastName: 'Administrator',
        email: 'admin@accessbankplc.com',
        password: 'Admin@123',
        role: UserRole.SUPER_ADMIN,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'IT',
        jobTitle: 'System Administrator',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.SUPER_ADMIN),
      },
      {
        firstName: 'Business',
        lastName: 'User',
        email: 'business@accessbankplc.com',
        password: 'Business@123',
        role: UserRole.BUSINESS_USER,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Marketing',
        jobTitle: 'Marketing Manager',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.BUSINESS_USER),
      },
      {
        firstName: 'DMO',
        lastName: 'Team',
        email: 'dmo@accessbankplc.com',
        password: 'Dmo@123',
        role: UserRole.DMO_TEAM,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Data Management',
        jobTitle: 'Data Analyst',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.DMO_TEAM),
      },
      {
        firstName: 'CX',
        lastName: 'Team',
        email: 'cx@accessbankplc.com',
        password: 'Cx@123',
        role: UserRole.CX_TEAM,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Customer Experience',
        jobTitle: 'CX Manager',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.CX_TEAM),
      },
      {
        firstName: 'Control',
        lastName: 'Team',
        email: 'control@accessbankplc.com',
        password: 'Control@123',
        role: UserRole.CONTROL_TEAM,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Compliance',
        jobTitle: 'Compliance Officer',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.CONTROL_TEAM),
      },
      {
        firstName: 'Journey',
        lastName: 'Developer',
        email: 'developer@accessbankplc.com',
        password: 'Developer@123',
        role: UserRole.JOURNEY_DEVELOPER,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'IT',
        jobTitle: 'Journey Developer',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.JOURNEY_DEVELOPER),
      },
      {
        firstName: 'Communications',
        lastName: 'Reviewer',
        email: 'communications@accessbankplc.com',
        password: 'Communications@123',
        role: UserRole.COMMUNICATIONS_REVIEWER,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Communications',
        jobTitle: 'Content Reviewer',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.COMMUNICATIONS_REVIEWER),
      },
      {
        firstName: 'Compliance',
        lastName: 'Officer',
        email: 'compliance@accessbankplc.com',
        password: 'Compliance@123',
        role: UserRole.COMPLIANCE_OFFICER,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Compliance',
        jobTitle: 'Compliance Officer',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.COMPLIANCE_OFFICER),
      },
      {
        firstName: 'Viewer',
        lastName: 'User',
        email: 'viewer@accessbankplc.com',
        password: 'Viewer@123',
        role: UserRole.VIEWER,
        status: UserStatus.PENDING_PASSWORD_CHANGE,
        department: 'Operations',
        jobTitle: 'Analyst',
        isTemporaryPassword: true,
        permissions: User.getDefaultPermissions(UserRole.VIEWER),
      },
    ];

    for (const userData of users) {
      const [user, created] = await User.findOrCreate({
        where: { email: userData.email },
        defaults: userData,
      });

      if (created) {
        logger.info(`Created user: ${user.email}`);
      } else {
        logger.info(`User already exists: ${user.email}`);
      }
    }

    logger.info('User seeding completed');
  } catch (error) {
    logger.error('Failed to seed users:', error);
    throw error;
  }
};

export default seedUsers;
