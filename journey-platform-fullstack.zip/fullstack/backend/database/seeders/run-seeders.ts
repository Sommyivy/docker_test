import 'reflect-metadata';
import dotenv from 'dotenv';
dotenv.config();

import { sequelize } from '../../src/config/database';
import { seedUsers } from './01-users';
import { logger } from '../../src/utils/logger';

const runSeeders = async (): Promise<void> => {
  try {
    logger.info('Starting database seeding...');

    // Test database connection
    await sequelize.authenticate();
    logger.info('Database connection established.');

    // Sync models
    await sequelize.sync({ alter: true });
    logger.info('Database models synchronized.');

    // Run seeders
    await seedUsers();

    logger.info('Database seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    logger.error('Database seeding failed:', error);
    process.exit(1);
  }
};

runSeeders();
